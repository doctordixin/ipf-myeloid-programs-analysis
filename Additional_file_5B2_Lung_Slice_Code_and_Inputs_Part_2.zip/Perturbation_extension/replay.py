"""Portable, offline replay of the locked lung-slice analysis. No data download."""
import argparse
import hashlib
import importlib.util
import json
import shutil
from pathlib import Path
import pandas as pd
import numpy as np

BASE = Path(__file__).resolve().parent


def verify_inputs():
    rows = json.loads((BASE/'input_hashes.json').read_text(encoding='utf-8'))
    for row in rows:
        p=(BASE/row['file']).resolve()
        assert p.is_relative_to(BASE),row['file']
        assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'],row['file']
    return len(rows)


def main(output):
    verify_inputs()
    assert not output.exists(), 'Choose a new output directory; old results are never overwritten.'
    output.mkdir(parents=True)
    shutil.copy2(BASE/'analysis_plan.json',output/'analysis_plan.json')
    spec=importlib.util.spec_from_file_location('locked_lung_slice_engine',BASE/'analysis_engine.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    module.SRC=BASE/'inputs';module.OUT=output;module.check_inputs=verify_inputs
    module.run()
    checks=[]
    # Compare every numerical result table, not just selected favorable endpoints.
    for p in sorted((BASE/'results').glob('*.csv')):
        got=pd.read_csv(output/p.name);ref=pd.read_csv(p)
        pd.testing.assert_frame_equal(got,ref,check_exact=False,atol=1e-10,rtol=1e-10)
        checks.append({'file':p.name,'rows':len(ref),'match':True})
    ca=json.loads((output/'calibration.json').read_text(encoding='utf-8'))
    cb=json.loads((BASE/'results/calibration.json').read_text(encoding='utf-8'))
    assert ca.keys()==cb.keys()
    for key in ['gene_means','gene_SDs']:
        np.testing.assert_allclose(ca[key],cb[key],atol=1e-10,rtol=1e-10)
    assert ca['module_columns']==cb['module_columns']
    (output/'portable_replay_receipt.json').write_text(json.dumps({'status':'PASS_SCOPED_REPLAY',
      'CSV_checks':checks,'calibration_checked':True,'tolerance':1e-10,
      'scope':'Computational reproduction from prepared counts with complete endogenous RNA denominators; not clinical validation.'},indent=2),encoding='utf-8')
    print('PASS: all result CSVs reproduced from counts; old files unchanged.')


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True)
    args=ap.parse_args();main(args.output.resolve())
