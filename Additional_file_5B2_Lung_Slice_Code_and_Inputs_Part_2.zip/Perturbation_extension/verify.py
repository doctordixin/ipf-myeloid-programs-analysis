"""Independent formula replay; does not import the effect-computation runner."""
import sys
import gzip
import hashlib
import io
import itertools
import json
import tarfile
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

R = Path(__file__).resolve().parent
S = R / 'inputs'
O = Path(sys.argv[1]).resolve() if len(sys.argv)>1 else R / 'results'
checks = []


def ok(label, condition):
    assert condition, label
    checks.append(label)


def close(label, a, b):
    np.testing.assert_allclose(a, b, atol=1e-10, rtol=1e-10)
    checks.append(label)


q = pd.read_csv(S / 'GSE305464_sample_QC.csv', dtype={'sample_token': str, 'donor_token': str})
npz = np.load(S / 'GSE305464_target_counts_full_denominator.npz', allow_pickle=False)
genes = json.loads((S / 'GSE305464_target_gene_order.json').read_text())
lookup = json.loads((S / 'Ensembl_symbol_lookup.json').read_text())
ids = [g if g.startswith('ENSG') else lookup[g]['id'] for g in genes]
with tarfile.open(S / 'GSE305464_RAW.tar') as archive:
    for i, member in enumerate(archive.getmembers()):
        gsm = member.name.split('_')[0]
        ok(f'raw_row_identity_{i}', hashlib.sha256(gsm.encode()).hexdigest()[:12] == q.iloc[i].sample_token)
        with gzip.GzipFile(fileobj=archive.extractfile(member)) as f:
            raw = f.read(8 * 1024 * 1024 + 1)
        ok(f'bounded_raw_{i}', len(raw) <= 8 * 1024 * 1024)
        frame = pd.read_csv(io.BytesIO(raw), sep='\t', index_col=0)
        endo = int(frame.loc[frame.index.str.startswith('ENSG')].iloc[:, 0].sum())
        close(f'raw_all_endogenous_denominator_{i}', endo, npz['full_RNA'][i])
        close(f'raw_target_counts_{i}', frame.loc[ids].iloc[:, 0], npz['counts'][i])

modules = json.loads((S / 'unchanged_candidate_modules.json').read_text())
counts = pd.DataFrame(npz['counts'], columns=genes)
full = pd.Series(npz['full_RNA'])
groups = q.groupby(['donor_token', 'time', 'treatment']).groups
meta, logs = [], []
for key, ix in sorted(groups.items()):
    meta.append(dict(zip(['donor_token', 'time', 'treatment'], key)))
    logs.append(np.log1p(counts.loc[ix].sum().to_numpy() * 1e6 / full.loc[ix].sum()))
m = pd.DataFrame(meta)
logs = np.array(logs)
ut = (m.time == 'd2') & (m.treatment == 'UT')
mean, sd = logs[ut].mean(0), logs[ut].std(0, ddof=1)
used, params = {}, {}
for name, labels in modules.items():
    ix = [genes.index(g) for g in labels if g in genes and sd[genes.index(g)] > 1e-8]
    used[name] = ix
    z = ((logs[:, ix] - mean[ix]) / sd[ix]).mean(1)
    params[name] = (z[ut].mean(), z[ut].std(ddof=1))
    m[name] = (z - params[name][0]) / params[name][1]
b = m.SPP1hi - m.CXCL10hi
params['balance'] = (b[ut].mean(), b[ut].std(ddof=1))
m['SPP1_CXCL10_balance'] = (b - params['balance'][0]) / params['balance'][1]
endpoints = list(modules) + ['SPP1_CXCL10_balance']
saved = pd.read_csv(O / 'all_donor_condition_scores.csv', dtype={'donor_token': str})
close('all_42_donor_condition_scores_independent', m[endpoints], saved[endpoints])
close('UT_means_zero', m.loc[ut, endpoints].mean(), np.zeros(9))
close('UT_SD_one', m.loc[ut, endpoints].std(), np.ones(9))
summary = pd.read_csv(O / 'primary_summary.csv')
diff = pd.read_csv(O / 'primary_individual_differences.csv', dtype={'donor_token': str})
ok('18_primary_tests_four_donors_each', len(summary) == 18 and (summary.n_donors == 4).all())
for row in summary.itertuples():
    tr, ctrl = row.contrast.split('_minus_')
    a = m[(m.time == 'd2') & (m.treatment == tr)].set_index('donor_token')[row.endpoint]
    c = m[(m.time == 'd2') & (m.treatment == ctrl)].set_index('donor_token')[row.endpoint]
    delta = (a - c).sort_index()
    output = diff[(diff.contrast == row.contrast) & (diff.endpoint == row.endpoint)].set_index('donor_token').delta.sort_index()
    close(f'donor_differences_{row.contrast}_{row.endpoint}', delta, output)
    close(f'mean_{row.contrast}_{row.endpoint}', delta.mean(), row.mean_delta)
    bound = stats.t.ppf(.975, 3) * delta.std() / 2
    close(f'CI_{row.contrast}_{row.endpoint}', [delta.mean()-bound, delta.mean()+bound], [row.t_CI95_low, row.t_CI95_high])
    perm = [abs(sum(delta.to_numpy() * signs) / 4) for signs in itertools.product([-1, 1], repeat=4)]
    p = sum(v >= abs(delta.mean()) - 1e-12 for v in perm) / 16
    close(f'exact_signflip_{row.contrast}_{row.endpoint}', p, row.signflip_p)
order = np.argsort(summary.signflip_p.to_numpy())
holm_sorted = np.minimum(1, np.maximum.accumulate(summary.signflip_p.to_numpy()[order] * np.arange(18, 0, -1)))
close('Holm18_independent_formula', summary.Holm_p_18.to_numpy()[order], holm_sorted)
sens = pd.read_csv(O / 'sensitivity_summary.csv')
ok('all_three_sensitivity_schemes_retained', len(sens) == 54 and (sens.n_donors == 4).all())
rare = pd.read_csv(O / 'depth_matching_200_repeats.csv')
ok('200_depth_repeats_not_patients', len(rare) == 3600 and rare.computational_repeat.nunique() == 200 and (rare.n_donors == 4).all())
rng = np.random.default_rng(305464)
rl = []
for key, ix in sorted(groups.items()):
    d = int(full.loc[ix].sum())
    if d < 100000:
        continue
    v = counts.loc[ix].sum().to_numpy(dtype=np.int64)
    draw = rng.multivariate_hypergeometric(np.r_[v, d-v.sum()], 100000)[:-1]
    rl.append(np.log1p(draw * 10))
rm = pd.DataFrame([dict(zip(['donor_token', 'time', 'treatment'], key)) for key, ix in sorted(groups.items()) if full.loc[ix].sum() >= 100000])
rl = np.array(rl)
for name, ix in used.items():
    z = ((rl[:, ix] - mean[ix]) / sd[ix]).mean(1)
    rm[name] = (z - params[name][0]) / params[name][1]
rm['SPP1_CXCL10_balance'] = (rm.SPP1hi-rm.CXCL10hi-params['balance'][0])/params['balance'][1]
for row in rare[rare.computational_repeat == 0].itertuples():
    a, b = row.contrast.split('_minus_')
    aa = rm[(rm.time == 'd2') & (rm.treatment == a)].set_index('donor_token')[row.endpoint]
    bb = rm[(rm.time == 'd2') & (rm.treatment == b)].set_index('donor_token')[row.endpoint]
    close(f'first_depth_repeat_{row.contrast}_{row.endpoint}', (aa-bb).mean(), row.mean_delta)
for row in json.loads((R/'input_hashes.json').read_text(encoding='utf-8')):
    ok('input_hash_' + row['file'], hashlib.sha256((R/row['file']).read_bytes()).hexdigest() == row['sha256'])
receipt = {'status': 'PASS_SCOPED_INDEPENDENT_REPLAY', 'checks_passed': len(checks),
           'checks': checks, 'scope': 'all 94 raw target vectors and full RNA denominators; all primary scores, paired differences, CIs, sign-flip and Holm18; first stochastic repeat; output completeness and protected files. Not a biological validation.',
           'scripts_sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__), R/'analysis_engine.py']}}
(O / 'verification_receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding='utf-8')
print(receipt['status'], receipt['checks_passed'])
