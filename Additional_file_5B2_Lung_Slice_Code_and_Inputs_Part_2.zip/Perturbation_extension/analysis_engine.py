"""Bounded donor-level analysis. Run freeze, then run, then verify separately."""
import argparse
import hashlib
import itertools
import json
import platform
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
import scipy
from scipy import stats
from statsmodels.stats.multitest import multipletests

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'outputs/GSE305464_perturbation_20261025'
SRC = ROOT / 'outputs/upgrade_gate_20261025'


def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def jsave(name, obj):
    (OUT / name).write_text(json.dumps(obj, indent=2, ensure_ascii=False, allow_nan=False), encoding='utf-8')


def freeze():
    assert not (OUT / 'frozen_inputs.json').exists(), 'Never overwrite a freeze receipt'
    protected = list(SRC.glob('*')) + [OUT / 'analysis_plan.json']
    protected += list((ROOT / 'outputs/Revision_20261025_v3/01_Upload_Files').rglob('*'))
    rows = [{'file': p.relative_to(ROOT).as_posix(), 'sha256': digest(p)}
            for p in protected if p.is_file()]
    jsave('frozen_inputs.json', {'utc': datetime.now(timezone.utc).isoformat(), 'files': rows})
    print('FROZEN', len(rows), 'files; no treatment effects calculated')


def check_inputs():
    obj = json.loads((OUT / 'frozen_inputs.json').read_text(encoding='utf-8'))
    for row in obj['files']:
        assert digest(ROOT / row['file']) == row['sha256'], row['file']
    return len(obj['files'])


def load():
    q = pd.read_csv(SRC / 'GSE305464_sample_QC.csv', dtype={'donor_token': str, 'sample_token': str})
    z = np.load(SRC / 'GSE305464_target_counts_full_denominator.npz', allow_pickle=False)
    genes = json.loads((SRC / 'GSE305464_target_gene_order.json').read_text())
    modules = json.loads((SRC / 'unchanged_candidate_modules.json').read_text())
    assert len(q) == len(z['counts']) == 94 and q.donor_token.nunique() == 4
    np.testing.assert_array_equal(q.full_RNA_sum, z['full_RNA'])
    return q, z['counts'].astype(np.int64), z['full_RNA'].astype(np.int64), genes, modules


def aggregate(q, counts, full, keep=None, equal=False):
    if keep is None:
        keep = np.ones(len(q), dtype=bool)
    rows, arr, den = [], [], []
    for (donor, time, tr), group in q[keep].groupby(['donor_token', 'time', 'treatment'], sort=True):
        ix = group.index.to_numpy()
        d = int(full[ix].sum())
        arr.append(np.log1p(counts[ix] / full[ix, None] * 1e6).mean(axis=0) if equal else counts[ix].sum(axis=0))
        rows.append({'donor_token': donor, 'time': time, 'treatment': tr, 'libraries': len(ix), 'full_RNA_sum': d})
        den.append(d)
    a = np.array(arr)
    return pd.DataFrame(rows), a, np.array(den)


def fit_calibration(logs, meta, genes, modules):
    ix = ((meta.time == 'd2') & (meta.treatment == 'UT')).to_numpy()
    assert ix.sum() == 4
    mu, sd = logs[ix].mean(axis=0), logs[ix].std(axis=0, ddof=1)
    good = sd > 1e-8
    audit, mod_ix, params = [], {}, {}
    for module, labels in modules.items():
        cols = []
        for gene in labels:
            j = genes.index(gene) if gene in genes else None
            usable = j is not None and good[j]
            audit.append({'module': module, 'gene': gene, 'usable': bool(usable),
                          'reason': 'used' if usable else ('absent' if j is None else 'constant_UT'),
                          'UT_logCPM_mean': float(mu[j]) if j is not None else None,
                          'UT_logCPM_SD': float(sd[j]) if j is not None else None})
            if usable:
                cols.append(j)
        assert len(cols) / len(labels) >= .8, (module, len(cols))
        mod_ix[module] = cols
        r = ((logs[:, cols] - mu[cols]) / sd[cols]).mean(axis=1)
        params[module] = {'mean': float(r[ix].mean()), 'sd': float(r[ix].std(ddof=1))}
        assert params[module]['sd'] > 1e-8
    def mz(m):
        r = ((logs[:, mod_ix[m]] - mu[mod_ix[m]]) / sd[mod_ix[m]]).mean(axis=1)
        return (r - params[m]['mean']) / params[m]['sd']
    b = mz('SPP1hi') - mz('CXCL10hi')
    params['SPP1_CXCL10_balance'] = {'mean': float(b[ix].mean()), 'sd': float(b[ix].std(ddof=1))}
    assert params['SPP1_CXCL10_balance']['sd'] > 1e-8
    pd.DataFrame(audit).to_csv(OUT / 'scoring_gene_audit.csv', index=False)
    jsave('calibration.json', {'genes': genes, 'gene_means': mu.tolist(), 'gene_SDs': sd.tolist(),
                             'module_columns': mod_ix, 'parameters': params})
    return mu, sd, mod_ix, params


def score(logs, meta, cal, raw=False):
    mu, sd, mi, par = cal
    f = meta.copy()
    for module, cols in mi.items():
        if raw:
            f[module] = logs[:, cols].mean(axis=1)
        else:
            v = ((logs[:, cols] - mu[cols]) / sd[cols]).mean(axis=1)
            f[module] = (v - par[module]['mean']) / par[module]['sd']
    f['SPP1_CXCL10_balance'] = f.SPP1hi - f.CXCL10hi
    if not raw:
        p = par['SPP1_CXCL10_balance']
        f['SPP1_CXCL10_balance'] = (f.SPP1_CXCL10_balance - p['mean']) / p['sd']
    return f


def pair_table(scores, endpoints, primary=False):
    rows = []
    for time in (['d2'] if primary else ['d2', 'd5']):
        s = scores[scores.time == time]
        contrasts = [('N', 'UT'), ('LTI10', 'CP')] if primary else (
            [(t, 'UT') for t in sorted(s.treatment.unique()) if t != 'UT'] +
            [(t, 'CP') for t in sorted(s.treatment.unique()) if t.startswith('LTI')])
        for tr, ref in contrasts:
            a = s[s.treatment == tr].set_index('donor_token')
            b = s[s.treatment == ref].set_index('donor_token')
            for donor in sorted(set(a.index) & set(b.index)):
                for endpoint in endpoints:
                    rows.append({'time': time, 'contrast': f'{tr}_minus_{ref}', 'donor_token': donor,
                                 'endpoint': endpoint, 'treated': float(a.loc[donor, endpoint]),
                                 'control': float(b.loc[donor, endpoint]),
                                 'delta': float(a.loc[donor, endpoint] - b.loc[donor, endpoint])})
    return pd.DataFrame(rows)


def summarize(pairs, infer=False):
    rows = []
    for (time, contrast, endpoint), g in pairs.groupby(['time', 'contrast', 'endpoint']):
        x = g.delta.to_numpy()
        n, m = len(x), float(x.mean())
        sd = float(x.std(ddof=1)) if n > 1 else np.nan
        half = float(stats.t.ppf(.975, n - 1) * sd / np.sqrt(n)) if n > 1 else np.nan
        loo = [(x.sum() - v) / (n - 1) for v in x] if n > 1 else [np.nan]
        row = {'time': time, 'contrast': contrast, 'endpoint': endpoint, 'n_donors': n,
               'mean_delta': m, 'median_delta': float(np.median(x)), 'SD_delta': sd,
               't_CI95_low': m - half, 't_CI95_high': m + half,
               'n_negative': int((x < 0).sum()), 'n_positive': int((x > 0).sum()),
               'LOO_mean_min': min(loo), 'LOO_mean_max': max(loo),
               'treated_mean': float(g.treated.mean()), 'control_mean': float(g.control.mean()),
               'treated_SD': float(g.treated.std()), 'control_SD': float(g.control.std())}
        if infer:
            null = [abs(np.mean(x * z)) for z in itertools.product([-1, 1], repeat=n)]
            row['signflip_p'] = float(np.mean(np.array(null) >= abs(m) - 1e-12))
            row['Shapiro_delta_p_diagnostic_only'] = float(stats.shapiro(x).pvalue) if n >= 3 else np.nan
        rows.append(row)
    f = pd.DataFrame(rows)
    if infer:
        assert len(f) == 18 and set(f.n_donors) == {4}
        f['Holm_p_18'] = multipletests(f.signflip_p, method='holm')[1]
    return f


def run():
    protected_n = check_inputs()
    assert not (OUT / 'primary_summary.csv').exists(), 'Use a new directory for any changed analysis'
    plan = json.loads((OUT / 'analysis_plan.json').read_text())
    endpoints = plan['endpoints']
    q, counts, full, genes, modules = load()
    meta, pooled, den = aggregate(q, counts, full)
    logs = np.log1p(pooled / den[:, None] * 1e6)
    cal = fit_calibration(logs, meta, genes, modules)
    primary = score(logs, meta, cal)
    primary.to_csv(OUT / 'all_donor_condition_scores.csv', index=False)
    pairs = pair_table(primary, endpoints, primary=True)
    pairs.to_csv(OUT / 'primary_individual_differences.csv', index=False)
    summary = summarize(pairs, infer=True)
    summary.to_csv(OUT / 'primary_summary.csv', index=False)
    exploratory = pair_table(primary, endpoints)
    exploratory.to_csv(OUT / 'exploratory_individual_differences.csv', index=False)
    summarize(exploratory).to_csv(OUT / 'exploratory_summary_no_tests.csv', index=False)
    sensitivity = []
    for name, keep, equal, raw in [
        ('exclude_library_below_100k', full >= 100000, False, False),
        ('equal_library_weight', None, True, False),
        ('unstandardized_module_mean_logCPM', None, False, True)]:
        mm, aa, dd = aggregate(q, counts, full, keep=keep, equal=equal)
        ll = aa if equal else np.log1p(aa / dd[:, None] * 1e6)
        ss = score(ll, mm, cal, raw=raw)
        pp = pair_table(ss, endpoints, primary=True)
        pp.insert(0, 'sensitivity', name)
        sensitivity.append(pp)
    ps = pd.concat(sensitivity, ignore_index=True)
    ps.to_csv(OUT / 'sensitivity_individual_differences.csv', index=False)
    results = []
    for name, g in ps.groupby('sensitivity'):
        f = summarize(g)
        f.insert(0, 'sensitivity', name)
        results.append(f)
    pd.concat(results).to_csv(OUT / 'sensitivity_summary.csv', index=False)
    rng = np.random.default_rng(305464)
    eligible = den >= 100000
    rm = meta[eligible].reset_index(drop=True)
    pc, dd = pooled[eligible], den[eligible]
    assert np.all(pc.sum(axis=1) <= dd)
    rr = []
    for rep in range(200):
        # Target genes plus every other endogenous count; no replacement.
        rc = np.array([rng.multivariate_hypergeometric(np.r_[v, d - v.sum()], 100000)[:-1]
                       for v, d in zip(pc, dd)])
        sc = score(np.log1p(rc / 100000 * 1e6), rm, cal)
        pr = pair_table(sc, endpoints, primary=True)
        r = pr.groupby(['contrast', 'endpoint']).agg(n_donors=('delta', 'size'), mean_delta=('delta', 'mean')).reset_index()
        r.insert(0, 'computational_repeat', rep)
        rr.append(r)
    rare = pd.concat(rr, ignore_index=True)
    rare.to_csv(OUT / 'depth_matching_200_repeats.csv', index=False)
    rsum = rare.groupby(['contrast', 'endpoint']).agg(
        n_donors=('n_donors', 'min'), mean_of_repeat_means=('mean_delta', 'mean'),
        computational_q025=('mean_delta', lambda a: a.quantile(.025)),
        computational_q975=('mean_delta', lambda a: a.quantile(.975)),
        fraction_repeat_means_negative=('mean_delta', lambda a: (a < 0).mean())).reset_index()
    rsum.to_csv(OUT / 'depth_matching_summary_NOT_CI.csv', index=False)
    jsave('run_receipt.json', {'status': 'COMPLETED_NOT_YET_INDEPENDENTLY_VERIFIED',
          'utc': datetime.now(timezone.utc).isoformat(), 'protected_files': protected_n,
          'libraries': len(q), 'donors': int(q.donor_token.nunique()), 'primary_tests': len(summary),
          'Holm_below_005': int((summary.Holm_p_18 < .05).sum()),
          'low_depth_libraries': int((full < 100000).sum()),
          'environment': {'python': platform.python_version(), 'numpy': np.__version__, 'pandas': pd.__version__, 'scipy': scipy.__version__}})
    assert check_inputs() == protected_n
    print(summary.to_string(index=False))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=['freeze', 'run'])
    args = parser.parse_args()
    freeze() if args.mode == 'freeze' else run()
