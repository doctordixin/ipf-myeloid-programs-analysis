Exploratory GSE305464 lung-slice module

From the extracted Analysis_Code directory (or any working directory):
  python Perturbation_extension/replay.py --output NEW_OUTPUT_DIRECTORY
  python Perturbation_extension/verify.py NEW_OUTPUT_DIRECTORY
  python Perturbation_extension/plot_S11.py --input NEW_OUTPUT_DIRECTORY --output NEW_FIGURE_DIRECTORY
Use absolute paths to scripts when outside the extracted directory. Output must be new. No network is used.

Inputs include all 94 original compressed count members (17.44 MB tar), public metadata, exact symbol mapping, prepared target counts, and all-endogenous RNA denominators. verify.py independently reads all raw count members; replay.py reconstructs all scores and ALL main, null, opposite-direction, sensitivity and descriptive tables. Raw feature denominator: 60,107 endogenous genes, not target genes only.

The analysis_engine.py is the preserved locked numerical engine; invoke replay.py rather than its historical workspace entry point. The historical local plan is retained as provenance, not executable paths or prospective preregistration. Local freeze: 2026-10-25T08:43:54.914883+00:00; original run: 2026-10-25T08:44:11.672234+00:00.

Four donors, 94 libraries, 42 donor/time/treatment pools. Main day-2 comparisons: N-UT and LTI10-CP, each n=4. Nine endpoints x two comparisons; Holm family=18, all adjusted P=1. Results are exploratory. No independent BAL prognosis, cell-intrinsic mechanism, target engagement or clinical efficacy is established. Fixed 200 depth repeats are computational draws, not participants.

Python 3.12.14, numpy 2.3.5, pandas 3.0.1, scipy 1.16.2, statsmodels 0.14.6; matplotlib for figures. See input_hashes.json for exact required files. Comparison tolerance=1e-10; different versions may change floating-point or random-generator results and must be documented rather than hidden.
Human authors remain responsible for analytical choices and interpretation.
