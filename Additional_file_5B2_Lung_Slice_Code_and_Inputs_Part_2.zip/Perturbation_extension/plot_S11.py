"""All donor-level observations; Figure S11 is exploratory, not efficacy validation."""
import argparse
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.colors import ListedColormap

def main(source, out):
    out.mkdir(parents=True, exist_ok=True)
    p = pd.read_csv(source/'primary_individual_differences.csv', dtype={'donor_token':str})
    s = pd.read_csv(source/'primary_summary.csv')
    sens = pd.read_csv(source/'sensitivity_summary.csv')
    endpoints=['MLM0','CCL2hi','MLM1','IL1Bhi','SPP1hi','CXCL10hi','SPP1_CXCL10_balance','ECM_structure','ECM_activation_remodeling']
    labels=['MLM0','CCL2hi','MLM1','IL1Bhi','SPP1hi','CXCL10hi','SPP1/CXCL10 balance','ECM structure','ECM activation/remodelling']
    contrasts=['N_minus_UT','LTI10_minus_CP']
    donors=sorted(p.donor_token.unique()); assert len(p)==72 and len(donors)==4
    colors=['#4477AA','#AA3377','#228833','#CCBB44']; markers=['o','s','^','v']
    mpl.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','DejaVu Sans'],
      'font.size':7,'axes.labelsize':7,'xtick.labelsize':6,'ytick.labelsize':6.5,
      'pdf.fonttype':42,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,
      'axes.linewidth':.6,'legend.frameon':False})
    fig=plt.figure(figsize=(7.09,6.4), facecolor='white')
    # Panel a/b answer two different treatment-control questions; c exposes method dependence.
    axa=fig.add_axes([.24,.52,.31,.39]); axb=fig.add_axes([.64,.52,.31,.39])
    limits=(np.floor(p.delta.min()/5)*5-2,np.ceil(p.delta.max()/5)*5+2)
    for k,(ax,contrast) in enumerate(zip([axa,axb],contrasts)):
        for j,endpoint in enumerate(endpoints):
            for di,donor in enumerate(donors):
                x=p[(p.contrast==contrast)&(p.endpoint==endpoint)&(p.donor_token==donor)]
                assert len(x)==1
                ax.scatter(float(x.delta.iloc[0]),j+(di-1.5)*.12,s=16,marker=markers[di],
                           c=colors[di],edgecolors='white',linewidths=.25,zorder=3)
            m=float(s[(s.contrast==contrast)&(s.endpoint==endpoint)].mean_delta.iloc[0])
            ax.scatter(m,j,marker='D',s=14,c='black',zorder=4)
        ax.axvline(0,color='#777777',lw=.65,ls='--',zorder=1)
        ax.set_xlim(limits); ax.set_ylim(8.6,-.6); ax.set_yticks(range(9))
        ax.set_yticklabels(labels if k==0 else ['']*9)
        ax.tick_params(axis='y',length=0); ax.grid(axis='x',lw=.3,color='#E3E3E3')
        ax.set_xlabel('Paired score difference (reference SD)')
        ax.set_title(['N − UT','LTI10 − CP'][k],fontsize=8,pad=8)
        ax.text(-.08,1.07,['a','b'][k],transform=ax.transAxes,fontweight='bold',fontsize=9)
    fig.text(.24,.955,'Day 2 · 4 paired donors per contrast · all 18 Holm-adjusted P = 1.000',fontsize=7)
    handles=[Line2D([],[],ls='',marker=markers[i],color=colors[i],markersize=4,label=f'Donor {i+1}') for i in range(4)]
    handles.append(Line2D([],[],ls='',marker='D',color='black',markersize=3.5,label='Mean'))
    fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.59,.455),ncol=5,fontsize=6.5,columnspacing=1.0,handletextpad=.3)
    ax=fig.add_axes([.48,.09,.47,.27])
    focus=['CCL2hi','SPP1_CXCL10_balance','ECM_structure','ECM_activation_remodeling']
    method=['Primary','Exclude <100k','Equal libraries','Unstandardized']
    names=['exclude_library_below_100k','equal_library_weight','unstandardized_module_mean_logCPM']
    rows=[]; desc=[]
    for contrast in contrasts:
        for endpoint in focus:
            v=[float(s[(s.contrast==contrast)&(s.endpoint==endpoint)].mean_delta.iloc[0])]
            v.extend(float(sens[(sens.contrast==contrast)&(sens.endpoint==endpoint)&(sens.sensitivity==name)].mean_delta.iloc[0]) for name in names)
            rows.append(np.sign(v)); desc.append(contrast.replace('_minus_','−')+' · '+labels[endpoints.index(endpoint)])
    arr=np.array(rows)
    ax.imshow(arr,aspect='auto',vmin=-1,vmax=1,cmap=ListedColormap(['#D9E5EF','#F2F2F2','#EBDDE8']))
    for y in range(8):
        for x in range(4):
            ax.text(x,y,'↓' if arr[y,x]<0 else ('↑' if arr[y,x]>0 else '0'),ha='center',va='center',fontsize=8)
    ax.set_yticks(range(8),desc,fontsize=6.2); ax.set_xticks(range(4),method,fontsize=6.2)
    ax.xaxis.tick_top(); ax.tick_params(length=0,pad=5)
    for spine in ax.spines.values():spine.set_visible(False)
    ax.axhline(3.5,color='white',lw=2)
    fig.text(.065,.39,'c',fontweight='bold',fontsize=9)
    fig.text(.065,.365,'Mean direction across fixed sensitivity analyses',fontsize=7)
    fig.text(.48,.045,'Arrows show direction only; unstandardized magnitudes use different units.',fontsize=6.2)
    # Export contract: editable vectors, 600-dpi lossless raster, all observations retained.
    stem=out/'Supplementary_Figure_S11_lung_slice'
    fig.savefig(str(stem)+'.pdf');fig.savefig(str(stem)+'.svg')
    fig.savefig(str(stem)+'.tiff',dpi=600,pil_kwargs={'compression':'tiff_lzw'})
    fig.savefig(str(stem)+'.png',dpi=300)
    fig.canvas.draw()
    renderer=fig.canvas.get_renderer(); bbox=fig.bbox
    overflow=[]
    for t in fig.findobj(mpl.text.Text):
        if t.get_visible() and t.get_text():
            bb=t.get_window_extent(renderer)
            if bb.x0 < -1 or bb.y0 < -1 or bb.x1 > bbox.x1+1 or bb.y1 > bbox.y1+1:
                overflow.append(t.get_text())
    assert not overflow,overflow
    (out/'S11_plot_QA.json').write_text(json.dumps({'points':72,'primary_endpoints':18,'donors':4,
       'all_Holm_1':bool((s.Holm_p_18==1).all()),'overflow':overflow,
       'panels':{'a':'all N-UT paired donor effects; mean diamond; raw donor spread, no CI drawn',
                 'b':'all LTI10-CP paired donor effects; same uncertainty display and scale',
                 'c':'four fixed scoring/weighting schemes; direction only; no inference'},
       'archetype':'quantitative grid','dimensions_inches':[7.09,6.4],
       'conclusion':'No uniform reversal; treatment contrasts and methods are not interchangeable.'},indent=2),encoding='utf-8')
    plt.close(fig)
    print('S11 exported; all 72 observations; no out-of-canvas text')

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--input',type=Path,required=True);ap.add_argument('--output',type=Path,required=True)
    a=ap.parse_args();main(a.input,a.output)
