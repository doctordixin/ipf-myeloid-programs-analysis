"""Frozen-program whole-BAL sarcoidosis progression boundary, portable scoped replay."""
from pathlib import Path
import sys,json,re,hashlib,platform,importlib.metadata,warnings
import numpy as np
import pandas as pd
from scipy import stats
import statsmodels.api as sm
from statsmodels.stats.multitest import multipletests
from statsmodels.stats.diagnostic import het_breuschpagan

HERE=Path(__file__).resolve().parent
BASE=Path(sys.argv[sys.argv.index('--base')+1]).resolve() if '--base' in sys.argv else HERE
IN=BASE/'inputs';OUT=Path(sys.argv[sys.argv.index('--out')+1]).resolve() if '--out' in sys.argv else BASE/'results'
OUT.mkdir(parents=True,exist_ok=True)
STATES=json.loads((IN/'mlm_six_state_signatures_frozen.json').read_text(encoding='utf-8'))['states']
BAL='SPP1hi_CXCL10hi_balance';EPS=list(STATES)+[BAL]
def save(d,n):d.to_csv(OUT/(n+'.tsv'),sep='\t',index=False,float_format='%.15g')
def z(v):return (v-v.mean())/v.std(ddof=1) if v.std(ddof=1)>0 else v*np.nan
def metadata():
    rows=[]
    for b in (IN/'GSE263448_metadata.soft').read_text(encoding='utf-8').split('^SAMPLE = ')[1:]:
        row={'GSM':b.splitlines()[0].strip()};description=[]
        for l in b.splitlines():
            if l.startswith('!Sample_characteristics_ch1 = '):
                k,v=l.split(' = ',1)[1].split(': ',1);row[k]=v
            if l.startswith('!Sample_description = '):description.append(l.split(' = ',1)[1])
        assert len(description)==1
        row['sample']=description[0];rows.append(row)
    d=pd.DataFrame(rows).set_index('sample');assert d.index.is_unique
    d['progressive']=d.diagnosis.map({'sarcoidosis (progressive)':1,'sarcoidosis (non-progressive)':0})
    d['age']=pd.to_numeric(d.age,errors='coerce');d['male']=d.Sex.map({'male':1,'female':0})
    d['former_smoker']=d['smoking status'].map({'former':1,'never':0})
    for i in range(1,6):d['pc'+str(i)]=pd.to_numeric(d[f'pc{i} (mrna)'],errors='coerce')
    return d
def holm(d,cols):
    d['p_holm_family']=np.nan
    for _,idx in d.groupby(cols,dropna=False).groups.items():
        d.loc[idx,'p_holm_family']=multipletests(d.loc[idx,'p'].fillna(1),method='holm')[1]
    d.loc[d.p.isna(),'p_holm_family']=np.nan
    return d
def fit(score,cov,ep,model,scoring='logCPM',**labels):
    d=pd.concat([score.rename('score'),cov],axis=1).dropna();r={'endpoint':ep,'model':model,'scoring':scoring,'n':len(d),'n_progressive':int(d.progressive.sum()),'n_nonprogressive':int((d.progressive==0).sum()),'status':'unavailable','beta':np.nan,'ci_low':np.nan,'ci_high':np.nan,'p':np.nan,**labels}
    if len(d)<6 or d.score.std()==0:return r
    y=d.pop('score');X=sm.add_constant(d.astype(float),has_constant='add')
    r.update({'parameters':X.shape[1],'residual_df':len(d)-X.shape[1],'condition_number':float(np.linalg.cond(X))})
    if np.linalg.matrix_rank(X)<X.shape[1] or len(d)<=X.shape[1]+1:r['status']='rank_or_df_gate_failed';return r
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter('always');m=sm.OLS(y,X).fit(cov_type='HC3',use_t=True)
    ci=m.conf_int().loc['progressive'];idx=list(X.columns).index('progressive')
    # Independent numpy reconstruction of OLS and HC3, including t-based inference.
    xx=np.asarray(X);yy=np.asarray(y);inv=np.linalg.inv(xx.T@xx);beta=np.linalg.lstsq(xx,yy,rcond=None)[0]
    residual=yy-xx@beta;hat=np.einsum('ij,jk,ik->i',xx,inv,xx)
    vc=inv@(xx.T@((residual/(1-hat))[:,None]**2*xx))@inv
    p2=2*stats.t.sf(abs(beta[idx])/np.sqrt(vc[idx,idx]),len(yy)-xx.shape[1])
    assert np.isclose(beta[idx],m.params['progressive'],atol=1e-8,rtol=1e-8)
    assert np.isclose(p2,m.pvalues['progressive'],atol=1e-9,rtol=1e-7)
    r.update({'status':'OK','beta':float(m.params['progressive']),'ci_low':float(ci.iloc[0]),'ci_high':float(ci.iloc[1]),'p':float(m.pvalues['progressive']),
              'numpy_beta_absdiff':float(abs(beta[idx]-m.params['progressive'])),'numpy_p_absdiff':float(abs(p2-m.pvalues['progressive'])),'max_leverage':float(hat.max()),'residual_Shapiro_p':float(stats.shapiro(residual).pvalue),'Breusch_Pagan_p':float(het_breuschpagan(residual,xx)[1]),'warnings':' | '.join(str(x.message) for x in w)})
    return r
def main():
    data=pd.read_csv(IN/'GSE263448_RawCounts_mRNA.txt.gz',sep=r'\s+')
    assert data.columns[0]=='Gene';ids=data.pop('Gene').str.replace(r'\.\d+$','',regex=True)
    x=data.to_numpy();assert np.isfinite(x).all() and (x>=0).all() and (x==np.rint(x)).all()
    assert data.columns.is_unique and not data.T.duplicated().any() and (data.sum()>0).all()
    assert len(data)==59856 and data.shape[1]==46
    meta=metadata();assert set(data.columns)==set(meta.index) and len(meta)==46
    save(meta.reset_index(),'all_sample_mapping')
    m=meta[meta.progressive.notna()].copy();assert len(m)==31 and m.progressive.sum()==12
    counts=data[m.index];totals=counts.sum(axis=0)
    annotation=pd.read_csv(IN/'hg38_provided_identifier_map.tsv',sep='\t').dropna()
    ref=dict(zip(annotation.ensembl,annotation.symbol_exact_hg38_annotation))
    symbols=ids.map(ref);lookup={}
    for i,(ens,sym) in enumerate(zip(ids,symbols)):
        for name in [ens,sym]:
            if pd.notna(name):lookup.setdefault(name,set()).add(i)
    expression={}
    for g in dict.fromkeys(g for v in STATES.values() for g in v):
        rows=sorted(lookup.get(g,set()))
        if rows:expression[g]=np.log2(counts.iloc[rows].sum(axis=0)/totals*1e6+1)
    expr=pd.DataFrame(expression,index=m.index).T
    genez=expr.sub(expr.mean(axis=1),axis=0).div(expr.std(axis=1,ddof=1).replace(0,np.nan),axis=0)
    rank=expr.rank(axis=1,pct=True);scores=pd.DataFrame(index=m.index);ranks=scores.copy();coverage=[];found_by={}
    for ep,genes in STATES.items():
        found=[g for g in genes if g in genez.index and np.isfinite(genez.loc[g]).all()];found_by[ep]=found
        gate=len(found)>=16
        coverage.append({'endpoint':ep,'requested':20,'present_variable':len(found),'passed':gate,'available':';'.join(found),'missing':';'.join(g for g in genes if g not in found)})
        scores[ep]=z(genez.loc[found].mean(axis=0)) if gate else np.nan
        ranks[ep]=z(rank.loc[found].mean(axis=0)) if gate else np.nan
    scores[BAL]=z(scores.SPP1hi-scores.CXCL10hi);ranks[BAL]=z(ranks.SPP1hi-ranks.CXCL10hi)
    save(pd.DataFrame(coverage),'signature_coverage')
    m['library_sum']=totals;m['detected_genes']=(counts>0).sum(axis=0);m['log_library_sum']=np.log(totals)
    save(pd.concat([m,scores],axis=1).reset_index(),'patient_scores_and_clinical')
    save(scores.reset_index(),'scores');save(ranks.reset_index(),'rank_scores')
    save(expr.reset_index(names='gene'),'marker_logCPM');save(genez.reset_index(names='gene'),'marker_gene_z')
    qc={'rna_rows':len(data),'total_profiles':data.shape[1],'progression_profiles':len(m),'progressive':int(m.progressive.sum()),'nonprogressive':int((m.progressive==0).sum()),'denominator':'all 59856 supplied RNA rows before marker selection','finite_nonnegative_integer':True,'duplicate_columns':0,'controls_excluded_from_calibration':15,'identifier_mapping':'Exact provided hg38 Ensembl-to-symbol annotation copied from preceding extension; frozen Ensembl IDs matched directly. No expression/outcome transferred.'}
    (OUT/'matrix_QC.json').write_text(json.dumps(qc,indent=2),encoding='utf-8')
    desc=[]
    for ep in EPS:
        for group,d in m.groupby('progressive'):
            v=scores.loc[d.index,ep];desc.append({'endpoint':ep,'progressive':int(group),'n':int(v.notna().sum()),'mean':v.mean(),'sd':v.std(ddof=1),'median':v.median(),'minimum':v.min(),'maximum':v.max()})
    save(pd.DataFrame(desc),'pre_model_group_descriptives')
    save(m.groupby('progressive')[['age','male','former_smoker','library_sum','detected_genes']].agg(['count','mean','min','max']).reset_index(),'group_covariate_distributions')
    # Raw distribution/QQ inspection is internal QA, not a new manuscript figure.
    if '--no-qa-plot' not in sys.argv:
        import matplotlib;matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        fig,axes=plt.subplots(2,4,figsize=(12,6))
        for ax,ep in zip(axes.flat,EPS):
            for group,col in [(0,'#446688'),(1,'#b56b4a')]:
                v=scores.loc[m.progressive.eq(group),ep];ax.scatter(np.arange(len(v))*.015+group,v,color=col,s=18)
            ax.set_title(ep,fontsize=8);ax.set_xticks([0,1],['Nonprogressive','Progressive'],fontsize=7)
        axes.flat[-1].axis('off');fig.tight_layout();fig.savefig(OUT/'pre_model_raw_distributions.png',dpi=120);plt.close(fig)
    covs={'primary_age_sex_smoking':['progressive','age','male','former_smoker'],'unadjusted':['progressive'],
          'add_log_library':['progressive','age','male','former_smoker','log_library_sum'],
          'add_source_PC1_PC3':['progressive','age','male','former_smoker','pc1','pc2','pc3']}
    records=[]
    for model,cols in covs.items():
        for ep in EPS:records.append(fit(scores[ep],m[cols],ep,model))
    for ep in EPS:records.append(fit(ranks[ep],m[covs['primary_age_sex_smoking']],ep,'primary_age_sex_smoking','rank'))
    models=holm(pd.DataFrame(records),['model','scoring']);save(models,'all_models')
    deletions=[]
    for person in m.index:
        for ep in EPS:deletions.append(fit(scores[ep].drop(person),m[covs['primary_age_sex_smoking']].drop(person),ep,'leave_one_patient_out',excluded_sample=person))
    save(holm(pd.DataFrame(deletions),['excluded_sample']),'leave_one_patient_out')
    omits=[]
    for ep in ['CCL2hi','MLM0']:
        for gene in found_by[ep]:
            remain=[g for g in found_by[ep] if g!=gene]
            sc=z(genez.loc[remain].mean(axis=0)) if len(remain)>=16 else pd.Series(np.nan,index=m.index)
            omits.append(fit(sc,m[covs['primary_age_sex_smoking']],ep,'leave_one_gene_out',excluded_gene=gene,genes_retained=len(remain)))
    save(holm(pd.DataFrame(omits),['model']),'leave_one_gene_out')
    depth=[]
    for ep in EPS:
        for metric in ['library_sum','detected_genes','age','male']:
            v=scores[ep];r,p=stats.spearmanr(v,m[metric],nan_policy='omit');depth.append({'endpoint':ep,'metric':metric,'rho':r,'p':p})
    save(pd.DataFrame(depth),'score_covariate_correlations')
    env={'python':platform.python_version(),'packages':{k:importlib.metadata.version(k) for k in ['numpy','pandas','scipy','statsmodels']},'input_hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in IN.iterdir() if p.is_file()}}
    (OUT/'environment_and_input_hashes.json').write_text(json.dumps(env,indent=2),encoding='utf-8')
    print(models[(models.model=='primary_age_sex_smoking')&(models.scoring=='logCPM')][['endpoint','n','beta','ci_low','ci_high','p','p_holm_family']].to_string(index=False),flush=True)
if __name__=='__main__':main()
