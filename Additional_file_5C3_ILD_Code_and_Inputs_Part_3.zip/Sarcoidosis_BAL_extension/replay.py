"""Replay the included public-count sarcoidosis extension from an extracted archive."""
from pathlib import Path
import subprocess,sys,os,json,hashlib,math
import pandas as pd
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'replay_results';OUT.mkdir(exist_ok=True)
subprocess.run([sys.executable,str(ROOT/'analyze.py'),'--base',str(ROOT),'--out',str(OUT),'--no-qa-plot'],check=True,creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
checks=[]
def same(a,b):
    if pd.isna(a):return pd.isna(b)
    if isinstance(a,(float,int)) and isinstance(b,(float,int)):return math.isclose(a,b,rel_tol=1e-7,abs_tol=1e-10)
    return a==b
refs=sorted((ROOT/'results').glob('*.tsv'));assert len(refs)==13,len(refs)
for p in refs:
    a=pd.read_csv(p,sep='\t');b=pd.read_csv(OUT/p.name,sep='\t')
    assert list(a.columns)==list(b.columns) and a.shape==b.shape,p.name
    assert all(same(x,y) for ra,rb in zip(a.itertuples(index=False,name=None),b.itertuples(index=False,name=None)) for x,y in zip(ra,rb)),p.name
    checks.append({'file':p.name,'rows':len(a),'columns':len(a.columns),'passed':True})
ref=json.loads((ROOT/'results/environment_and_input_hashes.json').read_text(encoding='utf-8'))
for name,digest in ref['input_hashes'].items():assert hashlib.sha256((ROOT/'inputs'/name).read_bytes()).hexdigest()==digest,name
report={'all_passed':True,'result_tables':len(refs),'checks':checks,'input_hashes_checked':len(ref['input_hashes']),
        'scope':'Reconstruction from all supplied public count rows and sample metadata; no parent-project input data required. Raw FASTQ processing, global donor identity and independent biological validation are outside scope.'}
(OUT/'replay_verification.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print('SARCOIDOSIS_ARCHIVE_REPLAY_PASS',len(refs),'tables',len(ref['input_hashes']),'input hashes')
