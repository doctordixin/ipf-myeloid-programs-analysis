"""Explicitly post-result diagnostics, not new confirmatory analyses."""
from pathlib import Path
import json, shutil
import numpy as np
import pandas as pd
from scipy import stats
from analyze import HERE, RAW, OUT, ROOT, STATES, ENDPOINTS, z, cox_fit, save, adjust_family

def main():
    d=pd.read_csv(OUT/'GSE318816_patient_analysis_table.tsv',sep='\t',dtype={'sample':str,'center':str}).set_index('sample')
    rows=[]
    d['detected_z']=z(d.detected_genes)
    for ep in ENDPOINTS:
        r,_=cox_fit(d,ep,['age10','male','fvc10','detected_z'],'posthoc_detected_genes_adjustment')
        rows.append(r)
    save(adjust_family(pd.DataFrame(rows),['model','scoring']),'GSE318816_posthoc_detected_genes')
    # Fixed intersection with prior BAL platform-common gene sets, not new gene selection.
    cp=ROOT/'data/derived/stage39_common_gene_coverage.csv'
    dst=RAW/cp.name
    if not dst.exists(): shutil.copy2(cp,dst)
    old=pd.read_csv(dst).drop_duplicates('state').set_index('state')
    tab=pd.read_csv(RAW/'GSE318816_counts.csv.gz')
    counts=tab.iloc[:,8:]; counts.columns=counts.columns.astype(str)
    total=counts.sum(axis=0)
    expr=np.log2(counts.div(total,axis=1)*1e6+1)
    expr.index=tab.gene_name.astype(str)
    expr=expr.groupby(level=0).mean()
    used=[]; fits=[]
    for ep in ['CCL2hi','MLM0']:
        requested=old.loc[ep,'common_genes'].split(';')
        found=[g for g in requested if g in expr.index]
        x=expr.loc[found]
        g=x.sub(x.mean(axis=1),axis=0).div(x.std(axis=1,ddof=1),axis=0)
        sc=z(g.mean(axis=0)); frame=d.drop(columns=[ep]).join(sc.rename(ep))
        r,_=cox_fit(frame,ep,['age10','male','fvc10'],'posthoc_fixed_BAL_common_gene_intersection')
        fits.append(r)
        used.append({'endpoint':ep,'BAL_fixed_gene_n':len(requested),'blood_available_n':len(found),'genes':';'.join(found),
          'caution':'MLM0 14-gene harmonization is below the new 80% primary gate; diagnostic only, no upgraded validation claim.'})
    save(pd.DataFrame(used),'GSE318816_posthoc_BAL_common_gene_coverage')
    save(adjust_family(pd.DataFrame(fits),['model','scoring']),'GSE318816_posthoc_BAL_common_gene_cox')
    save(d[ENDPOINTS].corr().reset_index(names='endpoint'),'GSE318816_module_correlations')
    (OUT/'posthoc_disclosure.txt').write_text(
      '这些检查在看到主要结果之后提出，仅用于诊断，不能冒充预设验证。\n'
      '1. 六状态均与较低风险关联，部分分数与检出基因数相关，因此额外调整检出基因数；该变量也可能代表生物学复杂度，不是纯技术混杂。\n'
      '2. 与既有BAL平台共同基因集的固定交集检验，用于排查基因覆盖差异；不改变原主要评分。MLM0的14基因交集低于新队列80%主评分门槛，不能提升为主要分析。\n'
      '3. 模块相关性用于提示不能把六个显著模块当成六次独立复制。\n',encoding='utf-8')
    print('POSTHOC_DIAGNOSTICS_DONE')

if __name__=='__main__': main()
