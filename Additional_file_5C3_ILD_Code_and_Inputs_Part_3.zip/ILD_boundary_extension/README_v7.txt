Scope: exploratory cross-disease/cross-compartment boundary extension only.
Install requirements.txt in a Python 3.12 environment, then run:
python replay_ild_boundary_extension.py
The included small public count matrices and clinical/SOFT files are sufficient. No parent-project data are required for this entry point.
The script regenerates 38 result tables in replay_results and compares every field with the included reference results. The public GEO-to-clinical relink audit remains a provenance check, not an association endpoint.
Table S17 has 49 planned Cox slots, 203 centre-deletion fits and 9 explicitly post hoc diagnostic fits. Table S18 has 168 tissue comparison slots, including 32 unavailable coverage slots. Table S19 distinguishes source, measurement and inferential gates.
GSE318816 has 38 death-or-transplant events, not 38 deaths. CCL2hi reverses direction relative to IPF BAL. Centre and detected-gene sensitivities are not consistently significant. GSE150910 CXCL10hi and contrast are untested. No independent IPF BAL mortality replication was added.
Primary intervals condition on estimated cohort-relative calibration. The 80% gate applies to this extension; historical BAL platform-common diagnostic sets do not replace its main scores.
Numerical agreement is not proof of global donor independence, biological mechanism or source-data correctness. Author verification remains necessary.
