"""Frozen, outcome-agnostic scoring and exploratory ILD extension analyses.
Run from any directory. Public small inputs only; never modifies manuscript.
"""
from pathlib import Path
import sys, json, hashlib, warnings, re, platform, importlib.metadata
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'python_deps'))
import numpy as np
import pandas as pd
from scipy import stats
import statsmodels.api as sm
from statsmodels.duration.hazard_regression import PHReg
from statsmodels.stats.multitest import multipletests
from statsmodels.stats.diagnostic import het_breuschpagan
from lifelines import CoxPHFitter
from lifelines.statistics import proportional_hazard_test

RAW = HERE / 'inputs'
OUT = Path(sys.argv[sys.argv.index('--out')+1]).resolve() if '--out' in sys.argv else HERE / 'results'
OUT.mkdir(exist_ok=True)
ROOT = HERE.parents[1]
FROZEN = RAW / 'mlm_six_state_signatures_frozen.json'
if not FROZEN.exists(): FROZEN = ROOT / 'data/derived/mlm_six_state_signatures_frozen.json'
STATES = json.loads(FROZEN.read_text(encoding='utf-8'))['states']
BALANCE = 'SPP1hi_CXCL10hi_balance'
ENDPOINTS = list(STATES) + [BALANCE]
QC, COVERAGE, DEPTH, ERRORS, DETAILS = [], [], [], [], {}

def save(df, name):
    df.to_csv(OUT / (name + '.tsv'), sep='\t', index=False, float_format='%.12g')

def z(v):
    sd = v.std(ddof=1)
    return (v-v.mean())/sd if np.isfinite(sd) and sd > 0 else v*np.nan

def adjust_family(frame, group_cols):
    if frame.empty: return frame
    frame['p_holm_family'] = np.nan
    for _, inds in frame.groupby(group_cols, dropna=False).groups.items():
        vals = frame.loc[inds, 'p'].fillna(1).to_numpy()
        frame.loc[inds, 'p_holm_family'] = multipletests(vals, method='holm')[1]
    frame.loc[frame.p.isna(),'p_holm_family']=np.nan
    return frame

def score_counts(counts, symbols, ids, acc):
    values = counts.to_numpy(dtype=float)
    assert np.isfinite(values).all() and (values >= 0).all()
    assert counts.columns.is_unique and (counts.sum(axis=0) > 0).all()
    duplicates = counts.T.duplicated(keep=False)
    QC.append({'accession':acc, 'rna_features':len(counts), 'samples':len(counts.columns),
               'nonnegative_finite':True, 'integer_entries':bool(np.allclose(values, np.rint(values), atol=1e-8, rtol=0)),
               'exact_duplicate_expression_columns':int(duplicates.sum()),
               'library_min':float(counts.sum().min()), 'library_max':float(counts.sum().max())})
    assert not duplicates.any(), 'Duplicate expression columns need donor adjudication'
    totals = counts.sum(axis=0)
    # Exact source-provided ID/symbol mapping only. Resolve requested genes, not denominator.
    lookup = {}
    for i, (symbol, ens) in enumerate(zip(symbols, ids)):
        for name in [str(symbol), str(ens).split('.')[0]]:
            if name and name not in ['nan','None','']:
                lookup.setdefault(name, set()).add(i)
    expr = {}
    for g in dict.fromkeys(g for gl in STATES.values() for g in gl):
        inds = sorted(lookup.get(g, set()))
        if inds:
            expr[g] = np.log2(counts.iloc[inds].sum(axis=0)/totals*1e6 + 1)
    expression = pd.DataFrame(expr, index=counts.columns).T
    genez = expression.sub(expression.mean(axis=1), axis=0).div(expression.std(axis=1,ddof=1).replace(0,np.nan),axis=0)
    ranks = expression.rank(axis=1,pct=True)
    scores, rank_scores = pd.DataFrame(index=counts.columns), pd.DataFrame(index=counts.columns)
    for state, genes in STATES.items():
        found = [g for g in genes if g in expression.index and np.isfinite(genez.loc[g]).all()]
        gate = len(found) >= 16
        COVERAGE.append({'accession':acc,'endpoint':state,'n_requested':20,'n_present_variable':len(found),
                         'passes_80pct':gate,'available':';'.join(found),'missing':';'.join(g for g in genes if g not in found)})
        scores[state] = z(genez.loc[found].mean(axis=0)) if gate else np.nan
        rank_scores[state] = z(ranks.loc[found].mean(axis=0)) if gate else np.nan
    scores[BALANCE] = z(scores['SPP1hi']-scores['CXCL10hi'])
    rank_scores[BALANCE] = z(rank_scores['SPP1hi']-rank_scores['CXCL10hi'])
    depth = pd.DataFrame({'library_sum':totals,'detected_genes':(counts>0).sum(axis=0)})
    depth.index.name='sample'
    save(depth.reset_index(), acc+'_depth')
    for ep in ENDPOINTS:
        for metric in depth:
            valid = scores[ep].notna()
            r,p = stats.spearmanr(scores.loc[valid,ep],depth.loc[valid,metric]) if valid.sum()>3 else (np.nan,np.nan)
            DEPTH.append({'accession':acc,'endpoint':ep,'metric':metric,'rho':r,'p':p,'n':int(valid.sum())})
    scores.index.name=rank_scores.index.name='sample'
    save(scores.reset_index(),acc+'_scores')
    save(rank_scores.reset_index(),acc+'_rank_scores')
    return scores, rank_scores, depth

def load_metadata(acc):
    records=json.loads((RAW/(acc+'_family_metadata.json')).read_text())
    rows=[]
    for rec in records:
        row={'gsm':rec['gsm'],'title':rec.get('title',[''])[0]}
        for item in rec.get('characteristics_ch1',[]):
            if ': ' in item:
                key,value=item.split(': ',1); row[key]=value
        for key in ['description','source_name_ch1','relation']:
            row[key]=' | '.join(rec.get(key,[]))
        rows.append(row)
    return pd.DataFrame(rows)

def cox_fit(data, ep, covs, spec, method='logCPM', strata=False, ph=False):
    columns=['time','event',ep]+covs+(['center'] if strata else [])
    d=data[columns].dropna().copy()
    row={'endpoint':ep,'model':spec,'scoring':method,'n':len(d),'events':int(d.event.sum()),'status':'OK'}
    if len(d)<30 or d.event.sum()<10 or d[ep].std()==0:
        return row|{'status':'INSUFFICIENT_DATA','p':np.nan}, None
    try:
        with warnings.catch_warnings(record=True) as ws:
            warnings.simplefilter('always')
            c=CoxPHFitter().fit(d,'time','event',strata=['center'] if strata else None)
            coeff=c.summary.loc[ep]
            row |= {'hr':float(coeff['exp(coef)']),'ci_low':float(coeff['exp(coef) lower 95%']),
                    'ci_high':float(coeff['exp(coef) upper 95%']),'beta':float(coeff['coef']),
                    'se':float(coeff['se(coef)']),'p':float(coeff['p']),'warnings':' | '.join(str(w.message) for w in ws)}
        if ph:
            pr=proportional_hazard_test(c,d,time_transform='rank').summary
            save(pr.reset_index(names='covariate'),'GSE318816_PH_'+ep)
            row['PH_score_p']=float(pr.loc[ep,'p'])
            row['PH_min_covariate_p']=float(pr.p.min())
            # Cross-check independent library, same Efron ties and design.
            other=PHReg(d.time,d[[ep]+covs],status=d.event,ties='efron').fit()
            row['statsmodels_beta']=float(other.params[0])
            row['cross_library_beta_absdiff']=abs(float(other.params[0])-row['beta'])
        return row,c
    except Exception as exc:
        ERRORS.append({'stage':'cox','endpoint':ep,'model':spec,'error':repr(exc)})
        return row|{'status':'FAILED','error':repr(exc),'p':np.nan},None

def analyze_blood():
    acc='GSE318816'
    tab=pd.read_csv(RAW/(acc+'_counts.csv.gz'))
    counts=tab.iloc[:,8:]; counts.columns=counts.columns.astype(str)
    scores,ranks,depth=score_counts(counts,tab.gene_name,tab.ENSid,acc)
    clinical=RAW/(acc+'_clinical_info.txt.gz')
    if not clinical.exists(): clinical=ROOT/'outputs/Clinical_gap_rescreen_20261026'/clinical.name
    d=pd.read_csv(clinical,sep='\t',dtype={'Sample name':str}).set_index('Sample name')
    assert d.index.is_unique and set(d.index)==set(scores.index)
    d=d.join(scores).join(depth)
    assert set(d.Transplant_Free_Survival.dropna())=={'alive','deadtx'}
    d['event']=d.Transplant_Free_Survival.map({'alive':0,'deadtx':1})
    d['time']=pd.to_numeric(d.Surv_months,errors='coerce')
    d['age10']=pd.to_numeric(d.Age_blood_draw)/10
    assert set(d.Sex)=={'Female','Male'}
    d['male']=d.Sex.map({'Female':0,'Male':1})
    d['fvc10']=pd.to_numeric(d['FVC+pred_pct'])/10
    d['dlco10']=pd.to_numeric(d.pctDLCOuncorr,errors='coerce')/10
    d['center']=d.Medical_center.astype(str)
    assert (d.loc[d.event.notna(),'time']>0).all()
    assert d.age10.between(1.8,11).all() and d.fvc10.between(.5,20).all()
    # Source column unit cross-check: measured/predicted DLCO should equal percentage.
    dc=100*d.DLCO_Uncorrected/d.DLCO_pred
    dlco_diff=(dc-d.pctDLCOuncorr).abs().max()
    assert dlco_diff<1e-4
    save(d.reset_index(names='sample'),acc+'_patient_analysis_table')
    miss=d.isna().sum().rename_axis('variable').reset_index(name='n_missing'); save(miss,acc+'_missingness')
    save(d.groupby(['center','Transplant_Free_Survival'],dropna=False).size().reset_index(name='n'),acc+'_center_events')
    summaries=[]
    for label,sub in [('all',d),('outcome_observed',d[d.event.notna()]),('outcome_missing',d[d.event.isna()])]:
        for col in ['Age_blood_draw','FVC+pred_pct','pctDLCOuncorr','time']+ENDPOINTS:
            v=pd.to_numeric(sub[col],errors='coerce').dropna()
            summaries.append({'group':label,'variable':col,'n':len(v),'mean':v.mean(),'sd':v.std(),'median':v.median(),'min':v.min(),'max':v.max()})
    save(pd.DataFrame(summaries),acc+'_descriptives')
    fits=[]; loco=[]
    for method,sc in [('logCPM',scores),('rank',ranks)]:
        data=d.drop(columns=ENDPOINTS).join(sc)
        specs={'primary_age_sex_FVC':['age10','male','fvc10']}
        if method=='logCPM':
            specs |= {'unadjusted':[],'age_sex':['age10','male'],'plus_DLCO':['age10','male','fvc10','dlco10'],
                      'center_stratified':['age10','male','fvc10'],
                      'plus_log_library':['age10','male','fvc10','log_library']}
        data['log_library']=z(np.log(data.library_sum))
        for spec,covs in specs.items():
            for ep in ENDPOINTS:
                row,c=cox_fit(data,ep,covs,spec,method,strata=(spec=='center_stratified'),ph=(method=='logCPM' and spec=='primary_age_sex_FVC'))
                fits.append(row)
        if method=='logCPM':
            for center in sorted(data.center.unique()):
                subset=data[data.center!=center]
                for ep in ENDPOINTS:
                    row,_=cox_fit(subset,ep,['age10','male','fvc10'],'leave_one_center_out')
                    loco.append(row|{'excluded_center':center})
            print('BLOOD_MODELS',len(fits),'LOCO',len(loco),flush=True)
    fitdf=adjust_family(pd.DataFrame(fits),['model','scoring'])
    save(fitdf,acc+'_cox_all_models')
    locodf=pd.DataFrame(loco); save(locodf,acc+'_leave_one_center_out')
    DETAILS[acc]={'n':len(d),'outcome_n':int(d.event.notna().sum()),'events':int(d.event.sum()),
        'missing_outcomes':int(d.event.isna().sum()),'unique_centers':int(d.center.nunique()),
        'max_DLCO_percent_recalculation_difference':float(dlco_diff),
        'endpoint':'blood sampling to first death or transplant; months; source paper definition',
        'gene_type_counts':tab.GeneType.value_counts().to_dict(),
        'composition_note':'Whole blood program association cannot distinguish cell proportion from intracellular effects.'}
    print(fitdf[fitdf.model.eq('primary_age_sex_FVC')].to_string(index=False),flush=True)

def self_check():
    a=pd.Series([1.,2.,3.]); assert np.isclose(z(a).std(ddof=1),1)
    assert np.isclose(z(a).mean(),0)
    p=multipletests([.01,.03,.2],method='holm')[1]
    assert np.allclose(p,[.03,.06,.2])
    print('SCORING_AND_HOLM_SELF_CHECK_PASS',flush=True)

def ols_comparison(data, ep, group1, group0, covs, spec, acc, method):
    d=data[data.group.isin([group1,group0])].copy()
    d['IPF_indicator']=(d.group==group1).astype(float)
    use=d[[ep,'IPF_indicator']+covs].dropna()
    n1=int(use.IPF_indicator.sum()); n0=int(len(use)-n1)
    row={'accession':acc,'endpoint':ep,'contrast':group1+'_minus_'+group0,'group1':group1,'group0':group0,
         'model':spec,'scoring':method,'n':len(use),'n_group1':n1,'n_group0':n0}
    if min(n1,n0)<5 or use[ep].isna().all():
        return row|{'status':'COVERAGE_OR_N_GATE','p':np.nan}
    try:
        x=sm.add_constant(use[['IPF_indicator']+covs].astype(float))
        if np.linalg.matrix_rank(x)<x.shape[1]:
            return row|{'status':'RANK_DEFICIENT','p':np.nan}
        fit=sm.OLS(use[ep].astype(float),x).fit(cov_type='HC3',use_t=True)
        ci=fit.conf_int().loc['IPF_indicator']
        y1=use.loc[use.IPF_indicator==1,ep]; y0=use.loc[use.IPF_indicator==0,ep]
        residual=fit.resid
        sw=np.sqrt(((n1-1)*y1.var()+(n0-1)*y0.var())/(n1+n0-2))
        diff=float(y1.mean()-y0.mean())
        return row|{'status':'OK','score_difference':float(fit.params['IPF_indicator']),
          'ci_low':float(ci.iloc[0]),'ci_high':float(ci.iloc[1]),'p':float(fit.pvalues['IPF_indicator']),
          'unadjusted_difference':diff,'Hedges_g':diff/sw*(1-3/(4*(n1+n0)-9)),
          'residual_df':float(fit.df_resid),'condition_number':float(fit.condition_number),
          'residual_Shapiro_p':float(stats.shapiro(residual).pvalue),
          'Breusch_Pagan_p':float(het_breuschpagan(residual,x)[1]),
          'Levene_median_p':float(stats.levene(y1,y0,center='median').pvalue),
          'max_abs_studentized_residual':float(np.max(np.abs(sm.OLS(use[ep],x).fit().get_influence().resid_studentized_internal))),
          'mean_IPF':float(y1.mean()),'mean_other':float(y0.mean()),'sd_IPF':float(y1.std()),'sd_other':float(y0.std())}
    except Exception as exc:
        ERRORS.append({'stage':'ols','accession':acc,'endpoint':ep,'model':spec,'error':repr(exc)})
        return row|{'status':'FAILED','error':repr(exc),'p':np.nan}

def analyze_lung(acc):
    meta=load_metadata(acc).set_index('title')
    assert meta.index.is_unique
    if acc=='GSE150910':
        tab=pd.read_csv(RAW/(acc+'_gene-level_count_file.csv.gz'))
        counts=tab.iloc[:,1:]; counts.columns=counts.columns.astype(str)
        symbols=tab.symbol.astype(str); ids=symbols
        meta['group']=meta.diagnosis.str.upper().replace({'CONTROL':'control'})
        meta['age10']=pd.to_numeric(meta.age,errors='coerce')/10
        meta['male']=meta.Sex.map({'male':1,'female':0})
        meta['explant']=(meta['sample type']=='explant').astype(float)
        other='CHP'
    else:
        counts=pd.read_csv(RAW/(acc+'_count.tsv.gz'),sep='\t')
        assert counts.index.to_series().str.startswith('ENSG').all()
        ids=counts.index.astype(str)
        # Borrow only the explicit hg38 Ensembl-to-symbol annotation of the already
        # retrieved GSE318816 file; never use its expression values or outcomes.
        annotation=pd.read_csv(RAW/'GSE318816_counts.csv.gz',usecols=['ENSid','gene_name'])
        ambiguous=annotation.groupby('ENSid').gene_name.nunique()
        assert ambiguous.max()==1
        mapping=annotation.drop_duplicates('ENSid').set_index('ENSid').gene_name
        symbols=[mapping.get(e,e) for e in ids]
        meta['group']=meta['disease state'].map({'idiopathic pulmonary fibrosis':'IPF','systemic sclerosis':'SSc-ILD','normal':'control'})
        assert meta.group.notna().all()
        other='SSc-ILD'
        save(pd.DataFrame({'ensembl':ids,'symbol_exact_hg38_annotation':symbols}),acc+'_annotation_used')
    assert set(counts.columns)==set(meta.index)
    assert meta.gsm.is_unique
    scores,ranks,depth=score_counts(counts,symbols,ids,acc)
    joined=meta.join(scores).join(depth)
    save(joined.reset_index(names='sample'),acc+'_sample_mapping_and_scores')
    save(joined.groupby(['group']+(['sample type'] if acc=='GSE150910' else [])).size().reset_index(name='n'),acc+'_group_counts')
    desc=[]
    for group,sub in joined.groupby('group'):
        for ep in ENDPOINTS:
            v=sub[ep].dropna()
            desc.append({'group':group,'endpoint':ep,'n':len(v),'mean':v.mean(),'sd':v.std(),'median':v.median(),'min':v.min(),'max':v.max()})
    save(pd.DataFrame(desc),acc+'_descriptives')
    results=[]
    for method,sc in [('logCPM',scores),('rank',ranks)]:
        d=meta.join(sc).join(depth)
        d['log_library']=z(np.log(d.library_sum))
        specs=[('unadjusted',d,[])]
        if acc=='GSE150910':
            specs += [('primary_age_sex_sampling',d,['age10','male','explant']),
                      ('biopsy_age_sex',d[d['sample type']=='biopsy'],['age10','male']),
                      ('explant_age_sex',d[d['sample type']=='explant'],['age10','male']),
                      ('plus_log_library',d,['age10','male','explant','log_library'])]
            # Additional source/plate adjustment, prespecified here before any lung results.
            d['ever_smoker']=d.ever_smoked.map({'yes':1,'no':0})
            for field in ['plate','institution']:
                dummy=pd.get_dummies(d[field],prefix=field,drop_first=True,dtype=float)
                d=d.join(dummy)
            extra=[c for c in d if c.startswith('plate_') or c.startswith('institution_')]
            specs += [('source_plate_smoking_sensitivity',d,['age10','male','explant','ever_smoker']+extra)]
        else:
            specs += [('plus_log_library',d,['log_library'])]
        for spec,frame,covs in specs:
            for ep in ENDPOINTS:
                results.append(ols_comparison(frame,ep,'IPF',other,covs,spec,acc,method))
        # Disease-vs-control is a background result, not clinical-outcome validation.
        for group in ['IPF',other]:
            for ep in ENDPOINTS:
                results.append(ols_comparison(d,ep,group,'control',[],'background_unadjusted',acc,method))
    resultdf=adjust_family(pd.DataFrame(results),['contrast','model','scoring'])
    save(resultdf,acc+'_disease_comparisons')
    DETAILS[acc]={'samples':len(meta),'groups':meta.group.value_counts().to_dict(),
        'matrix_sample_id_sets_equal':True,'gsm_unique':True,
        'donor_identity_limit':'Unique sample labels and BioSample records are not proof of global donor deduplication; no common donor identifiers verified.',
        'survival_validation':False,
        'annotation':'exact provided symbols' if acc=='GSE150910' else 'provided hg38 GSE318816 Ensembl-to-symbol annotation plus exact frozen Ensembl IDs; uncovered genes left missing',
        'source_caution':'Potential LTRC/UCSF tissue overlap with previous studies; do not count all samples as globally new independent patients.'}
    print('LUNG_DONE',acc,flush=True)
    print(resultdf[(resultdf.model.isin(['primary_age_sex_sampling','unadjusted']))&resultdf.scoring.eq('logCPM')].to_string(index=False),flush=True)

def finish():
    save(pd.DataFrame(QC),'matrix_QC')
    save(pd.DataFrame(COVERAGE),'signature_coverage')
    save(pd.DataFrame(DEPTH),'score_depth_correlations')
    (OUT/'analysis_details.json').write_text(json.dumps(DETAILS,indent=2,default=str),encoding='utf-8')
    (OUT/'failures_and_warnings.json').write_text(json.dumps(ERRORS,indent=2),encoding='utf-8')
    pkgs=['numpy','pandas','scipy','statsmodels','lifelines','formulaic','autograd','narwhals']
    versions={p:importlib.metadata.version(p) for p in pkgs}
    (HERE/'environment.json').write_text(json.dumps({'python':platform.python_version(),'packages':versions,
      'signature_sha256':hashlib.sha256(FROZEN.read_bytes()).hexdigest(),
      'plan_sha256':hashlib.sha256((HERE/'Analysis_Plan.txt').read_bytes()).hexdigest()},indent=2),encoding='utf-8')

if __name__=='__main__':
    self_check()
    analyze_blood()
    analyze_lung('GSE150910')
    analyze_lung('GSE231693')
    finish()
