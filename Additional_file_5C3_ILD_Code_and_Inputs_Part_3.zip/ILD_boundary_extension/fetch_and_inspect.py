"""Fetch only small processed GEO files; keep receipts and inspect before fitting."""
from pathlib import Path
import gzip, hashlib, json, urllib.request, time, shutil
import pandas as pd

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
RAW = HERE / 'inputs'
RAW.mkdir(exist_ok=True)
FILES = {
    'GSE318816_counts.csv.gz': 'https://ftp.ncbi.nlm.nih.gov/geo/series/GSE318nnn/GSE318816/suppl/GSE318816_counts.csv.gz',
    'GSE150910_gene-level_count_file.csv.gz': 'https://ftp.ncbi.nlm.nih.gov/geo/series/GSE150nnn/GSE150910/suppl/GSE150910_gene-level_count_file.csv.gz',
    'GSE231693_count.tsv.gz': 'https://ftp.ncbi.nlm.nih.gov/geo/series/GSE231nnn/GSE231693/suppl/GSE231693_count.tsv.gz',
}
for acc in ['GSE318816', 'GSE150910', 'GSE231693']:
    FILES[acc + '_family.soft.gz'] = f'https://ftp.ncbi.nlm.nih.gov/geo/series/{acc[:-3]}nnn/{acc}/soft/{acc}_family.soft.gz'

def main():
    receipts = []
    for name, url in FILES.items():
        p = RAW / name
        if not p.exists():
            for attempt in range(3):
                try:
                    req = urllib.request.Request(url, headers={'User-Agent': 'AcademicPublicDataAudit/1.0'})
                    with urllib.request.urlopen(req, timeout=60) as r:
                        blob = r.read(20_000_001)
                    assert len(blob) <= 20_000_000, 'small-file bound exceeded'
                    gzip.decompress(blob)
                    p.with_suffix(p.suffix + '.part').write_bytes(blob)
                    p.with_suffix(p.suffix + '.part').replace(p)
                    break
                except Exception as exc:
                    print('FETCH_ERROR', name, attempt + 1, repr(exc), flush=True)
                    if attempt == 2:
                        raise
                    time.sleep(2)
        blob = p.read_bytes()
        unpacked = gzip.decompress(blob)
        receipts.append({'file': name, 'url': url, 'bytes': len(blob), 'sha256': hashlib.sha256(blob).hexdigest(), 'gzip_eof_crc_pass': True})
        print('FILE', name, len(blob), flush=True)
        if 'family.soft' in name:
            text = unpacked.decode('utf-8', errors='strict')
            samples = []
            current = None
            for line in text.splitlines():
                if line.startswith('^SAMPLE = '):
                    current = {'gsm': line.split(' = ', 1)[1]}; samples.append(current)
                elif current is not None and line.startswith('!Sample_') and ' = ' in line:
                    key, value = line.split(' = ', 1)
                    current.setdefault(key.removeprefix('!Sample_'), []).append(value)
            (RAW / name.replace('.soft.gz', '_metadata.json')).write_text(json.dumps(samples, indent=2), encoding='utf-8')
            print('SAMPLE_N', len(samples), 'FIRST', json.dumps(samples[:1]), flush=True)
            keys = sorted({v.split(': ',1)[0] for x in samples for v in x.get('characteristics_ch1',[])})
            print('CHARACTERISTIC_KEYS', keys, flush=True)
        else:
            import io
            d = pd.read_csv(io.BytesIO(unpacked), sep='\t' if '.tsv' in name else ',', nrows=3)
            print('HEADER', d.columns.tolist()[:15], 'N_COLS', len(d.columns), flush=True)
            print(d.iloc[:3,:8].to_string(index=False), flush=True)
    old = ROOT / 'outputs/Clinical_gap_rescreen_20261026/GSE318816_clinical_info.txt.gz'
    dest = RAW / old.name
    if not dest.exists(): shutil.copy2(old, dest)
    frozen = ROOT / 'data/derived/mlm_six_state_signatures_frozen.json'
    dest = RAW / frozen.name
    if not dest.exists(): shutil.copy2(frozen, dest)
    for p in [RAW / old.name, RAW / frozen.name]:
        receipts.append({'file':p.name,'source':'existing project frozen input','bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
    (HERE / 'download_receipts.json').write_text(json.dumps(receipts, indent=2), encoding='utf-8')

if __name__ == '__main__': main()
