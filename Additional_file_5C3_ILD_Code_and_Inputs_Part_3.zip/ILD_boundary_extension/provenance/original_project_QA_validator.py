"""Validate frozen inputs, numerical replay, mappings and package only this run."""
from pathlib import Path
import json, gzip, hashlib, re, zipfile, sys
import numpy as np
import pandas as pd

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
RAW=HERE/'inputs'
RESULT=HERE/'results'
REPLAY=HERE/'QA_replay'

def main():
    checks=[]
    def check(name,condition,detail=''):
        checks.append({'check':name,'passed':bool(condition),'detail':detail})
        if not condition: raise AssertionError(name+' '+str(detail))
    receipts=json.loads((HERE/'download_receipts.json').read_text())
    for r in receipts:
        b=(RAW/r['file']).read_bytes()
        check('input_sha256_'+r['file'],hashlib.sha256(b).hexdigest()==r['sha256'])
        if r['file'].endswith('.gz'): gzip.decompress(b)
    env=json.loads((HERE/'environment.json').read_text())
    check('locked_plan_hash',hashlib.sha256((HERE/'Analysis_Plan.txt').read_bytes()).hexdigest()==env['plan_sha256'])
    check('frozen_signature_hash',hashlib.sha256((RAW/'mlm_six_state_signatures_frozen.json').read_bytes()).hexdigest()==env['signature_sha256'])
    replay_files=sorted(REPLAY.glob('*.tsv'))
    check('replay_file_set',{p.name for p in replay_files} <= {p.name for p in RESULT.glob('*.tsv')})
    for f in replay_files:
        a=pd.read_csv(RESULT/f.name,sep='\t'); b=pd.read_csv(f,sep='\t')
        check('replay_shape_'+f.name,a.shape==b.shape)
        check('replay_columns_'+f.name,a.columns.tolist()==b.columns.tolist())
        for col in a:
            if pd.api.types.is_numeric_dtype(a[col]) and pd.api.types.is_numeric_dtype(b[col]):
                condition=np.allclose(a[col],b[col],atol=1e-10,rtol=1e-10,equal_nan=True)
            else:
                condition=a[col].fillna('').astype(str).equals(b[col].fillna('').astype(str))
            check('replay_'+f.name+'_'+col,condition)
    d=pd.read_csv(RESULT/'GSE318816_patient_analysis_table.tsv',sep='\t',dtype={'sample':str}).set_index('sample')
    records=json.loads((RAW/'GSE318816_family_metadata.json').read_text())
    source_rows=[]
    for rec in records:
        sample=re.fullmatch(r'Library name: (\d+)',rec['description'][0]).group(1)
        chars=dict(v.split(': ',1) for v in rec['characteristics_ch1'] if ': ' in v)
        actual=d.loc[sample]
        status=chars.get('transplant free_survival','')
        expected_status=actual.Transplant_Free_Survival
        ok=(status==str(expected_status)) or (pd.isna(expected_status) and status.lower() in ['na','nan',''])
        check('GEO_clinical_status_'+sample,ok)
        check('GEO_clinical_sex_'+sample,chars['Sex']==actual.Sex)
        check('GEO_clinical_age_'+sample,abs(float(chars['age blood_draw'])-actual.Age_blood_draw)<1e-6)
        if pd.notna(actual.time): check('GEO_clinical_time_'+sample,abs(float(chars['surv months'])-actual.time)<1e-8)
        source_rows.append({'sample':sample,'gsm':rec['gsm'],'source_status':status,'status_matched':ok})
    pd.DataFrame(source_rows).to_csv(RESULT/'GSE318816_GEO_clinical_relink.tsv',sep='\t',index=False)
    check('unique_clinical_relink',len({x['sample'] for x in source_rows})==126)
    check('events_38',d.event.sum()==38)
    check('outcomes_119',d.event.notna().sum()==119)
    models=pd.read_csv(RESULT/'GSE318816_cox_all_models.tsv',sep='\t')
    primary=models[(models.model=='primary_age_sex_FVC') & (models.scoring=='logCPM')]
    check('seven_primary_models',len(primary)==7)
    check('Cox_two_libraries_agree',primary.cross_library_beta_absdiff.max()<1e-5,str(primary.cross_library_beta_absdiff.max()))
    check('no_failed_Cox_models',models.status.eq('OK').all())
    coverage=pd.read_csv(RESULT/'signature_coverage.tsv',sep='\t')
    hp=coverage[(coverage.accession=='GSE150910') & (coverage.endpoint=='CXCL10hi')].iloc[0]
    check('coverage_gate_not_relaxed',hp.n_present_variable==15 and not hp.passes_80pct)
    hpmodels=pd.read_csv(RESULT/'GSE150910_disease_comparisons.tsv',sep='\t')
    gated=hpmodels[hpmodels.endpoint.isin(['CXCL10hi','SPP1hi_CXCL10hi_balance'])]
    check('unmeasured_not_called_negative',gated.p.isna().all() and gated.p_holm_family.isna().all())
    check('all_unavailable_labeled',gated.status.eq('COVERAGE_OR_N_GATE').all())
    for acc in ['GSE150910','GSE231693']:
        table=pd.read_csv(RESULT/(acc+'_disease_comparisons.tsv'),sep='\t')
        check(acc+'_seven_endpoints_in_every_family',table.groupby(['contrast','model','scoring']).size().eq(7).all())
    # Independent implementation of blood scoring for all modules, using array operations.
    raw=pd.read_csv(RAW/'GSE318816_counts.csv.gz')
    c=raw.iloc[:,8:].to_numpy(float)
    log=np.log2(c/c.sum(axis=0)[None,:]*1e6+1)
    gz=(log-log.mean(axis=1)[:,None])/np.where(log.std(axis=1,ddof=1)>0,log.std(axis=1,ddof=1),np.nan)[:,None]
    states=json.loads((RAW/'mlm_six_state_signatures_frozen.json').read_text())['states']
    scores=pd.read_csv(RESULT/'GSE318816_scores.tsv',sep='\t',dtype={'sample':str}).set_index('sample')
    for state,genes in states.items():
        mask=raw.gene_name.isin(genes) | raw.ENSid.isin(genes)
        v=np.nanmean(gz[mask],axis=0); v=(v-v.mean())/v.std(ddof=1)
        expected=scores.loc[raw.columns[8:],state].to_numpy()
        check('independent_numpy_score_'+state,np.allclose(v,expected,atol=1e-10,rtol=1e-10))
    # Bounded source-ID overlap check; explicitly not a global human donor identity audit.
    paths=list(RAW.glob('*_family.soft.gz'))
    old_rel=['data/raw/external_bal/GSE79544_family.soft.gz','data/raw/external_bal/GSE166036_family.soft.gz',
      'outputs/resource_gate_20261023/GSE252465_family.soft.gz','outputs/resource_gate_20261023/GSE250346_family.soft.gz',
      'outputs/upgrade_gate_20261025/GSE305464_family.soft.gz']
    paths += [ROOT/r for r in old_rel if (ROOT/r).exists()]
    ids={}
    for p in paths:
        text=gzip.decompress(p.read_bytes()).decode('utf-8')
        ids[p.name]={'gsm':set(re.findall(r'^\^SAMPLE = (GSM\d+)',text,re.M)),
                     'biosample':set(re.findall(r'\bSAM[NED][A-Z]?\d+\b',text))}
    overlap=[]
    for i,a in enumerate(ids):
        for b in list(ids)[i+1:]:
            if a.startswith(('GSE318816','GSE150910','GSE231693')) or b.startswith(('GSE318816','GSE150910','GSE231693')):
                overlap.append({'a':a,'b':b,'shared_GSM':sorted(ids[a]['gsm']&ids[b]['gsm']),
                   'shared_BioSample':sorted(ids[a]['biosample']&ids[b]['biosample'])})
    (RESULT/'bounded_source_overlap_audit.json').write_text(json.dumps({'pairs':overlap,
       'scope':'Only locally available listed SOFT identifiers; different accession IDs do not establish different human donors. No global patient deduplication claimed.',
       'source_warning':'GSE150910 includes LTRC/UCSF samples; PFF whole blood may overlap prior PFF plasma layers. Do not sum all layers as independent patients.'},indent=2),encoding='utf-8')
    report={'scope':'Deterministic same-code fresh-process replay plus independent NumPy scoring and statsmodels Cox cross-check. Not independent human review.',
        'checks':checks,'n_checks':len(checks),'all_passed':all(x['passed'] for x in checks),
        'replay_tsv_files':len(replay_files),'cohort_identity_gate':'Global cross-study donor identity unresolved; only public source records and exact matrix duplicates checked.',
        'clinical_replication':'No independent IPF BAL mortality replication established.',
        'manuscript_modified':False}
    (HERE/'QA_validation.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    files=[f for f in HERE.rglob('*') if f.is_file() and f.name!='package_manifest.json' and not any(part in ['python_deps','__pycache__'] for part in f.relative_to(HERE).parts)]
    manifest=[{'file':str(f.relative_to(HERE)).replace('\\','/'),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in files if f.name!='package_manifest.json']
    (HERE/'package_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    target=HERE.parent/'ILD_extension_analysis_20261026_delivery.zip'
    with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED) as z:
        for f in files:
            z.write(f,arcname=HERE.name+'/'+str(f.relative_to(HERE)))
        z.write(HERE/'package_manifest.json',arcname=HERE.name+'/package_manifest.json')
    with zipfile.ZipFile(target) as z:
        assert z.testzip() is None
    print(json.dumps({'checks':len(checks),'all_passed':True,'replay_tsv':len(replay_files),'zip':str(target),'zip_bytes':target.stat().st_size}))

if __name__=='__main__': main()
