"""Portable numerical replay from the included small public RNA count matrices."""
from pathlib import Path
import os,sys,json,subprocess,hashlib
import numpy as np
import pandas as pd

HERE=Path(__file__).resolve().parent
OUT=HERE/'replay_results'
def main():
    OUT.mkdir(exist_ok=True)
    checks=[]
    for r in json.loads((HERE/'download_receipts.json').read_text()):
        p=HERE/'inputs'/r['file']
        ok=hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256']
        assert ok,p
        checks.append({'check':'input_hash_'+r['file'],'passed':ok})
    flags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0
    for script in ['analyze.py','posthoc_diagnostics.py']:
        run=subprocess.run([sys.executable,str(HERE/script),'--out',str(OUT)],cwd=HERE,
          capture_output=True,text=True,encoding='utf-8',errors='replace',creationflags=flags,timeout=600)
        (OUT/(script+'.stdout.txt')).write_text(run.stdout,encoding='utf-8')
        (OUT/(script+'.stderr.txt')).write_text(run.stderr,encoding='utf-8')
        assert run.returncode==0,(script,run.stderr[-2000:])
    expected=[f for f in (HERE/'results').glob('*.tsv') if f.name!='GSE318816_GEO_clinical_relink.tsv']
    assert len(expected)>=38, 'Full reference scope must not silently shrink'
    for f in expected:
        a=pd.read_csv(f,sep='\t');b=pd.read_csv(OUT/f.name,sep='\t')
        assert a.columns.tolist()==b.columns.tolist() and a.shape==b.shape,f.name
        for c in a:
            if pd.api.types.is_numeric_dtype(a[c]) and pd.api.types.is_numeric_dtype(b[c]):
                ok=np.allclose(a[c],b[c],rtol=1e-9,atol=1e-10,equal_nan=True)
            else:ok=a[c].fillna('').astype(str).equals(b[c].fillna('').astype(str))
            assert ok,(f.name,c)
            checks.append({'check':f.name+':'+c,'passed':bool(ok)})
    report={'all_passed':True,'files_compared':len(expected),'n_checks':len(checks),'checks':checks,
      'scope':'Included count files to seven frozen scores, all 261 clinical and 168 tissue model slots, post hoc diagnostics and QC. Same-code replay, not independent biological validation.',
      'cross_library_check':'Primary Cox coefficient differences from statsmodels are retained in the output tables.',
      'uncertainty':'Global donor independence and source-data truth are not certified by numerical agreement.'}
    (OUT/'portable_replay_report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k!='checks'}))

if __name__=='__main__':main()
