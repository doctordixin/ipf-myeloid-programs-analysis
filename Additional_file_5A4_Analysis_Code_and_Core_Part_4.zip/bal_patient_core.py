"""Frozen program calibration and donor-level statistics; no network or plotting."""
import itertools,math
import numpy as np
import pandas as pd
from scipy import stats

STATES=['MLM0','CCL2hi','MLM1','IL1Bhi','SPP1hi','CXCL10hi']
BALANCE='SPP1hi_minus_CXCL10hi'
ENDPOINTS=STATES+[BALANCE]

def bh(values):
    p=np.asarray(values);order=np.argsort(p);ranked=p[order]*len(p)/np.arange(1,len(p)+1)
    result=np.empty(len(p));result[order]=np.minimum(1,np.minimum.accumulate(ranked[::-1])[::-1]);return result

def logcpm(counts,full_library):
    library=np.asarray(full_library,dtype=float)
    if np.any(library<=0):raise ValueError('non-positive full RNA library')
    return np.log2(np.asarray(counts,dtype=float)/library[None,:]*1e6+0.5)

def calibrate(expression,signatures,fit_donors,omit=None):
    fit=expression.loc[:,fit_donors];scores={};calibration={'modules':{}}
    for state in STATES:
        genes=[g for g in signatures[state] if g in expression.index and (state,g)!=omit]
        variance=fit.loc[genes].std(axis=1,ddof=1)
        genes=[g for g in genes if np.isfinite(variance[g]) and variance[g]>0]
        if len(genes)<16:raise ValueError(f'{state}: fewer than 16 usable frozen genes')
        centre=fit.loc[genes].mean(axis=1);scale=fit.loc[genes].std(axis=1,ddof=1)
        gene_z=expression.loc[genes].sub(centre,axis=0).div(scale,axis=0)
        raw=gene_z.mean(axis=0);module_centre=float(raw.loc[fit_donors].mean());module_sd=float(raw.loc[fit_donors].std(ddof=1))
        if module_sd<=0:raise ValueError('constant module score')
        scores[state]=(raw-module_centre)/module_sd
        calibration['modules'][state]={'genes':genes,'gene_mean':centre.to_dict(),'gene_sd':scale.to_dict(),
          'raw_mean':module_centre,'raw_sd':module_sd}
    result=pd.DataFrame(scores,index=expression.columns)
    contrast=result['SPP1hi']-result['CXCL10hi'];mean=float(contrast.loc[fit_donors].mean());sd=float(contrast.loc[fit_donors].std(ddof=1))
    if sd<=0:raise ValueError('constant balance')
    result[BALANCE]=(contrast-mean)/sd;calibration['balance']={'mean':mean,'sd':sd,'fit_donors':fit_donors}
    return result,calibration

def exact_abs_welch(values,labels,batch=8192):
    """Enumerate all fixed-group-size allocations. Abs-tail convention is explicit."""
    y=np.asarray(values,dtype=float)
    if y.ndim==1:y=y[:,None]
    labels=np.asarray(labels,dtype=bool);a=y[labels];b=y[~labels];n1,n0=len(a),len(b)
    if min(n1,n0)<2:raise ValueError('need at least 2 donors per group')
    observed=(a.mean(0)-b.mean(0))/np.sqrt(a.var(0,ddof=1)/n1+b.var(0,ddof=1)/n0)
    total=y.sum(0);squares=(y*y).sum(0);exceed=np.zeros(y.shape[1],dtype=np.int64);tested=0
    combinations=itertools.combinations(range(len(y)),n0)
    while selection:=list(itertools.islice(combinations,batch)):
        selected=y[np.asarray(selection,dtype=np.int32)]
        sum0=selected.sum(1);sq0=(selected*selected).sum(1);sum1=total-sum0;sq1=squares-sq0
        var0=np.maximum(0,(sq0-sum0**2/n0)/(n0-1));var1=np.maximum(0,(sq1-sum1**2/n1)/(n1-1))
        statistic=(sum1/n1-sum0/n0)/np.sqrt(var0/n0+var1/n1)
        exceed+=np.sum(np.abs(statistic)>=np.abs(observed)[None,:]-1e-12,axis=0);tested+=len(selection)
    assert tested==math.comb(len(y),n0)
    return exceed/tested,observed,tested

def mean_effect(values,labels):
    y=np.asarray(values,dtype=float);labels=np.asarray(labels,dtype=bool)
    return y[labels].mean(axis=0)-y[~labels].mean(axis=0)

def effect_statistics(values,labels,rng,draws=20000):
    y=np.asarray(values,dtype=float);labels=np.asarray(labels,dtype=bool);a=y[labels];b=y[~labels];n1,n0=len(a),len(b)
    v1=a.var(0,ddof=1);v0=b.var(0,ddof=1);difference=a.mean(0)-b.mean(0)
    se=np.sqrt(v1/n1+v0/n0);df=(v1/n1+v0/n0)**2/((v1/n1)**2/(n1-1)+(v0/n0)**2/(n0-1))
    margin=stats.t.ppf(.975,df)*se;correction=1-3/(4*(n1+n0-2)-1)
    pooled=np.sqrt(((n1-1)*v1+(n0-1)*v0)/(n1+n0-2));g=correction*difference/pooled
    ba=a[rng.integers(0,n1,size=(draws,n1))];bb=b[rng.integers(0,n0,size=(draws,n0))]
    boot_g=correction*(ba.mean(1)-bb.mean(1))/np.sqrt(((n1-1)*ba.var(1,ddof=1)+(n0-1)*bb.var(1,ddof=1))/(n1+n0-2))
    lo,hi=np.quantile(boot_g,[.025,.975],axis=0)
    return dict(mean_ipf=a.mean(0),sd_ipf=a.std(0,ddof=1),median_ipf=np.median(a,axis=0),
      mean_control=b.mean(0),sd_control=b.std(0,ddof=1),median_control=np.median(b,axis=0),
      mean_difference=difference,welch_ci_low=difference-margin,welch_ci_high=difference+margin,
      welch_df=df,hedges_g=g,hedges_g_boot_ci_low=lo,hedges_g_boot_ci_high=hi)

def compare(scores,metadata,label,rng):
    selected=scores.loc[metadata.index,ENDPOINTS];y=selected.to_numpy();case=metadata['Disease'].eq('IPF').to_numpy()
    p,statistic,n=exact_abs_welch(y,case);effects=effect_statistics(y,case,rng)
    return pd.DataFrame({'analysis':label,'endpoint':ENDPOINTS,'n_ipf':int(case.sum()),'n_control':int((~case).sum()),
      **effects,'abs_welch_permutation_statistic':np.abs(statistic),'permutation_p':p,'allocations':n,'q_BH_7':bh(p)})
