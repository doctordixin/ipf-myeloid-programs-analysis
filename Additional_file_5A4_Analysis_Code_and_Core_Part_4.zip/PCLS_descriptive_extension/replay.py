"""Standalone prepared-count replay of descriptive pools; never fits patient models."""
from pathlib import Path
import argparse,json,hashlib,platform
import numpy as np
import pandas as pd

def run(root,out):
    receipt=json.loads((root/'prepared_input_receipt.json').read_text(encoding='utf-8'))
    for n,h in receipt['inputs'].items():assert hashlib.sha256((root/n).read_bytes()).hexdigest()==h,n
    out.mkdir(exist_ok=True,parents=True)
    a=np.load(root/'target_counts.npz');counts=a['counts'].astype(float);genes=a['genes'].tolist()
    meta=pd.read_csv(root/'cell_metadata_and_full_RNA_totals.csv');assert counts.shape==(127,len(meta))
    depth=meta.full_RNA_total.to_numpy();assert np.all(depth>0) and np.all(counts.sum(axis=0)<=depth)
    sets=json.loads((root/'marker_sets.json').read_text(encoding='utf-8'))
    pools={'macrophage':['MacAlv','MacSPP1','macCC'],'MacAlv':['MacAlv'],'MacSPP1':['MacSPP1'],'fibroblast':['Fibroblast']}
    libs=meta[['orig.ident','Day','Condition']].drop_duplicates();libs['hours']=libs.Day.map({'D0':0,'H12':12,'D1':24,'D2':48,'D3':72,'D4':96,'D5':120});libs=libs.sort_values(['hours','Condition'])
    qc=[];scores=[];coverage=[];genedata=[]
    for pool,labels in pools.items():
        gs={k:v for k,v in sets.items() if (k.startswith('ECM') if pool=='fibroblast' else not k.startswith('ECM'))}
        minimum=100 if pool=='fibroblast' else 200
        raw=[];norm=[];means=[];info=[]
        for lib in libs.to_dict('records'):
            use=meta['orig.ident'].eq(lib['orig.ident']).to_numpy() & meta.baseName.isin(labels).to_numpy();n=int(use.sum());z=counts[:,use];denom=float(depth[use].sum());total=z.sum(axis=1)
            row={**lib,'pool':pool,'cells':n,'full_RNA_total':denom,'median_RNA':float(np.median(depth[use])) if n else None,'eligible':n>=minimum and denom>0,'minimum':minimum,'biological_replicates':'not estimable; source describes a control donor','scope':'time-condition pool description only'}
            info.append(row);qc.append(row);raw.append(total);norm.append(np.log2(total/denom*1e6+1) if denom else np.full(len(genes),np.nan));means.append(np.log2(z/depth[use]*1e4+1).mean(axis=1) if n else np.full(len(genes),np.nan))
        raw=np.array(raw);norm=np.array(norm);means=np.array(means);elig=np.array([v['eligible'] for v in info]);used=raw[elig].sum(axis=0)>0
        for program,markers in gs.items():
            available=[g for g in markers if g in genes and used[genes.index(g)]];idx=[genes.index(g) for g in available];need=len(markers) if pool=='fibroblast' else 16
            coverage.append({'pool':pool,'program':program,'canonical':len(markers),'fixed_available':len(available),'genes':';'.join(available),'excluded':';'.join(g for g in markers if g not in available),'minimum':need})
            for j,row in enumerate(info):
                expressed=int((raw[j,idx]>0).sum());ok=row['eligible'] and len(available)>=need and expressed>=need
                scores.append({**row,'program':program,'available_genes':len(available),'expressed_genes_in_pool':expressed,'program_eligible':ok,'mean_log2_CPM_plus1':float(norm[j,idx].mean()) if ok else None,'mean_cell_log2_CP10K_plus1':float(means[j,idx].mean()) if ok else None,'reason':'' if ok else 'cell minimum or gene expression coverage failure; not tested'})
                for g in markers:
                    gi=genes.index(g) if g in genes else None
                    genedata.append({'pool':pool,'orig.ident':row['orig.ident'],'hours':row['hours'],'Condition':row['Condition'],'program':program,'gene':g,'cells':row['cells'],'pool_cell_gate':row['eligible'],'count':float(raw[j,gi]) if gi is not None else None,'log2_CPM_plus1':float(norm[j,gi]) if gi is not None else None,'scope':'QC/description, not independent observation'})
    s=pd.DataFrame(scores);contrast=[]
    for (pool,program,h),grp in s.groupby(['pool','program','hours'],sort=True):
        if h==0:continue
        c=grp[grp.Condition.eq('Control')].iloc[0];f=grp[grp.Condition.eq('Cocktail')].iloc[0];ok=bool(c.program_eligible and f.program_eligible)
        aa=f.mean_log2_CPM_plus1-c.mean_log2_CPM_plus1 if ok else None;bb=f.mean_cell_log2_CP10K_plus1-c.mean_cell_log2_CP10K_plus1 if ok else None
        contrast.append({'pool':pool,'program':program,'hours':h,'control_cells':int(c.cells),'FC_cells':int(f.cells),'both_pass_QC':ok,'FC_minus_Control_mean_log2_CPM_plus1':aa,'FC_minus_Control_mean_cell_log2_CP10K_plus1':bb,'direction_agrees_between_normalizations':bool(np.sign(aa)==np.sign(bb)) if ok else None,'inference':'NONE; single-donor model description','not_original_z_score':True})
    tables={'time_pool_QC.csv':pd.DataFrame(qc),'fixed_gene_coverage.csv':pd.DataFrame(coverage),'descriptive_program_expression.csv':s,'all_time_descriptive_contrasts.csv':pd.DataFrame(contrast),'gene_expression_QC.csv':pd.DataFrame(genedata)}
    verified=[]
    for n,new in tables.items():
        new.to_csv(out/n,index=False);got=pd.read_csv(out/n);expected=pd.read_csv(root/'expected'/n)
        pd.testing.assert_frame_equal(got,expected,check_dtype=False,check_exact=False,rtol=1e-11,atol=1e-12);verified.append({'table':n,'rows':len(new)})
    result={'tables_verified':verified,'hypothesis_tests':0,'patient_level_models':0,'Python':platform.python_version(),'numpy':np.__version__,'pandas':pd.__version__,'scope':'Rebuilt from included prepared target rows and full RNA totals, not full RDS or raw sequencing reads.'}
    (out/'replay_receipt.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result))
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,default=Path(__file__).resolve().parent);ap.add_argument('--out',type=Path);a=ap.parse_args();run(a.root,a.out or a.root/'results')
