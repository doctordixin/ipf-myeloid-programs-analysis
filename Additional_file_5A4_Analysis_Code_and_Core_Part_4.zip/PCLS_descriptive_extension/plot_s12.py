"""S12 quantitative grid: all 120 descriptive slots; missingness is visible.

Core conclusion: single-donor pool responses depend on time and normalization.
No inferential intervals, p-values or stars: biological replicate inference unavailable.
Python/matplotlib only. 183 x 150 mm; editable text; minimum glyph 6 pt.
"""
from pathlib import Path
import argparse,json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap,TwoSlopeNorm
from matplotlib.patches import Rectangle

def draw(source,prefix):
    d=pd.read_csv(source);assert len(d)==120 and d[['pool','program','hours']].duplicated().sum()==0
    programs=['MLM0','CCL2hi','MLM1','IL1Bhi','SPP1hi','CXCL10hi'];rows=[(p,g) for p in ['macrophage','MacAlv','MacSPP1'] for g in programs]+[('fibroblast',g) for g in ['ECM_structure','ECM_activation']];times=[12,24,48,72,96,120]
    labels=[({'macrophage':'Mac','MacAlv':'MacAlv','MacSPP1':'MacSPP1','fibroblast':'Fibro'}[p]+'  '+g.replace('ECM_structure','ECM structure').replace('ECM_activation','ECM activation')) for p,g in rows]
    cmap=LinearSegmentedColormap.from_list('blue_white_orange',['#31688e','#ffffff','#c97932']);cmap.set_bad('#e5e5e5')
    plt.rcParams.update({'font.family':'Arial','font.size':7,'axes.titlesize':8,'xtick.labelsize':7,'ytick.labelsize':6.5,'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none','axes.linewidth':.5})
    fig=plt.figure(figsize=(7.2047244094,5.9055118110));axes=[fig.add_axes([.20,.19,.30,.68]),fig.add_axes([.65,.19,.30,.68])]
    values=['FC_minus_Control_mean_log2_CPM_plus1','FC_minus_Control_mean_cell_log2_CP10K_plus1'];titles=['a  Pseudobulk RNA summary','b  Mean per-cell RNA summary'];units=['Difference in mean log2(CPM + 1)','Difference in mean log2(CP10K + 1)']
    disagreement=0
    for k,(ax,col) in enumerate(zip(axes,values)):
        arr=np.full((20,6),np.nan);bad=[]
        for ri,(pool,program) in enumerate(rows):
            for ci,h in enumerate(times):
                z=d[(d.pool==pool)&(d.program==program)&(d.hours==h)].iloc[0]
                if z.both_pass_QC:
                    arr[ri,ci]=z[col]
                    if not z.direction_agrees_between_normalizations:bad.append((ri,ci))
        vmax=float(np.nanmax(np.abs(arr)));im=ax.imshow(np.ma.masked_invalid(arr),cmap=cmap,norm=TwoSlopeNorm(vmin=-vmax,vcenter=0,vmax=vmax),aspect='auto',interpolation='nearest')
        for ri,ci in np.argwhere(~np.isfinite(arr)):ax.text(ci,ri,'x',ha='center',va='center',fontsize=6,color='#777777')
        for ri,ci in bad:ax.add_patch(Rectangle((ci-.44,ri-.44),.88,.88,fill=False,edgecolor='#47334f',linewidth=1.0))
        disagreement=len(bad);ax.set_yticks(np.arange(20),labels);ax.set_xticks(np.arange(6),[str(t) for t in times]);ax.set_xlabel('Culture time (h)',labelpad=4)
        ax.set_title(titles[k],loc='left',pad=10,fontweight='bold');ax.tick_params(length=0)
        for y in [5.5,11.5,17.5]:ax.axhline(y,color='#555555',lw=.7)
        for spine in ax.spines.values():spine.set_visible(False)
        cax=fig.add_axes([.20 if k==0 else .65,.10,.30,.018]);cb=fig.colorbar(im,cax=cax,orientation='horizontal');cb.set_ticks([-vmax,0,vmax]);cb.set_ticklabels([f'{-vmax:.2f}','0',f'{vmax:.2f}']);cb.ax.tick_params(labelsize=6,length=2);cb.set_label(units[k],fontsize=6,labelpad=2)
    fig.text(.20,.965,'Descriptive responses in a human PCLS time course',fontsize=9,fontweight='bold')
    fig.text(.20,.931,'Source methods describe a control donor; no biological-replicate inference',fontsize=6.5)
    fig.text(.20,.025,'x  QC failure / unavailable     Purple outline  Direction differs between summaries',fontsize=6)
    prefix.parent.mkdir(parents=True,exist_ok=True)
    for ext in ['.pdf','.svg','.png','.tiff']:
        fig.savefig(prefix.with_suffix(ext),dpi=600 if ext=='.tiff' else 180,**({'pil_kwargs':{'compression':'tiff_lzw'}} if ext=='.tiff' else {}))
    plt.close(fig)
    note={'source_rows':120,'eligible':int(d.both_pass_QC.sum()),'unavailable':int((~d.both_pass_QC).sum()),'direction_disagreements':disagreement,'panels':'Same slots under two distinct units; color magnitudes are not comparable between panels','excluded_from_plot':0,'statistics':'No tests, intervals or patient-level inference; x denotes QC missingness, not zero effect','dimensions_mm':[183,150],'backend':'python matplotlib'}
    prefix.with_suffix('.qa.json').write_text(json.dumps(note,indent=2),encoding='utf-8');print(json.dumps(note))
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--source',type=Path,default=Path(__file__).resolve().parent/'results/all_time_descriptive_contrasts.csv');ap.add_argument('--output',type=Path,default=Path(__file__).resolve().parent/'figures/Figure_S12');a=ap.parse_args();draw(a.source,a.output)
