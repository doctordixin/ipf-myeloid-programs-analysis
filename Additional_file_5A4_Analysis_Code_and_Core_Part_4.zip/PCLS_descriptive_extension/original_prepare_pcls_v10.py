"""Prepare a compact, explicitly scoped RNA-count replay without rewriting v9."""
from pathlib import Path
import json,hashlib,shutil
import numpy as np
import pandas as pd
R=Path(__file__).resolve().parents[1];OLD=R/'outputs/Revision_20261026_v9';B=R/'outputs/Revision_20261026_v10';G=R/'outputs/GSE286182_gate_20261026';S=R/'outputs/PCLS_reassessment_20261026'
assert not B.exists();Q=B/'QA';Q.mkdir(parents=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
(Q/'v9_protected_files.json').write_text(json.dumps([{'path':p.relative_to(R).as_posix(),'sha256':sha(p)} for p in OLD.rglob('*') if p.is_file()],indent=2),encoding='utf-8')
shutil.copytree(OLD/'01_Upload_Files',B/'01_Upload_Files')
shutil.copytree(OLD/'02_Author_Review',B/'02_Author_Review/Previous_v9_review')
E=B/'Reproducibility/PCLS_descriptive_extension';E.mkdir(parents=True)
md=pd.read_csv(G/'object_gate/cell_metadata.tsv',sep='\t',index_col=0)
d=json.loads((G/'object_gate/matrix_descriptors.json').read_text(encoding='utf-8'))['RNA.counts']
def arr(k):
    a=d[k];p=R/a['path'];return np.load(p,mmap_mode='r') if a.get('npy') else np.memmap(p,mode='r',dtype=a['dtype'],shape=(a['length'],))
x,i,p=arr('x'),arr('i'),arr('p');assert list(md.index)==d['cells']
sets=json.loads((R/'data/derived/mlm_six_state_signatures_frozen.json').read_text(encoding='utf-8'))['states']
sets.update(ECM_structure=['COL1A1','COL1A2','COL3A1','COL5A1','COL5A2','FN1'],ECM_activation=['POSTN','CTHRC1','LRRC15','FAP','TGFBI','LOX','MMP14'])
genes=sorted(set(g for gs in sets.values() for g in gs if g in set(d['features'])))
lookup=np.full(len(d['features']),-1);feat={g:j for j,g in enumerate(d['features'])}
for j,g in enumerate(genes):lookup[feat[g]]=j
sel=md.baseName.isin(['MacAlv','MacSPP1','macCC','Fibroblast']);cols=np.flatnonzero(sel.to_numpy());counts=np.zeros((len(genes),len(cols)),dtype=np.uint32);depth=[]
for j,c in enumerate(cols):
    a,b=int(p[c]),int(p[c+1]);ri=lookup[i[a:b]];z=x[a:b];ok=ri>=0
    assert np.all(z==np.floor(z)) and np.all(z>=0)
    counts[ri[ok],j]=z[ok];depth.append(float(z.sum()))
meta=md.loc[sel,['orig.ident','Day','Condition','baseName','nCount_RNA']].copy();meta.index.name='cell_id';meta['full_RNA_total']=depth
assert np.array_equal(meta.full_RNA_total,meta.nCount_RNA)
meta.to_csv(E/'cell_metadata_and_full_RNA_totals.csv');np.savez_compressed(E/'target_counts.npz',counts=counts,genes=np.array(genes))
(E/'marker_sets.json').write_text(json.dumps(sets,indent=2),encoding='utf-8')
for n in ['descriptive_amendment_before_program_results.json','reassessment_decision.json','source_receipts.json','supplement_receipts.json']:shutil.copy2(S/n,E/n)
for n in ['PCLS_download_integrity.json','PCLS_admission_decision.json']:shutil.copy2(G/n,E/('historical_'+n))
expected=E/'expected';expected.mkdir()
for n in ['time_pool_QC.csv','fixed_gene_coverage.csv','gene_expression_QC.csv','descriptive_program_expression.csv','all_time_descriptive_contrasts.csv','observed_macrophage_composition.csv']:shutil.copy2(S/n,expected/n)
receipt={'original_features':60651,'original_nuclei':46930,'prepared_features':len(genes),'prepared_nuclei':len(cols),'omitted_nuclei':'Other author-annotated lineages, not used by this descriptive extension','normalization':'Every included cell retains its complete provided RNA count total, computed before marker restriction','source_sha256':'02484e3acf37b49f1f4c4220001b2c099b9986a0ae7fb48c2280bd25836013e0','replay_scope':'Prepared target-count rows and full RNA denominators, not raw-read or full-Seurat reconstruction','inputs':{n:sha(E/n) for n in ['target_counts.npz','cell_metadata_and_full_RNA_totals.csv','marker_sets.json']}}
(E/'prepared_input_receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8');print(json.dumps(receipt))
