"""Reconstruct fixed scores and verify existing estimates; no data download or new hypotheses."""
from pathlib import Path
import argparse, hashlib, itertools, json, sys
import numpy as np
import pandas as pd
from scipy.stats import rankdata

ROOT=Path(__file__).resolve().parent
LINKS=['CCL2hi','balance']
def digest(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def compute(logs,genes,cal):
    out={}
    for comp,mods in cal.items():
        if not isinstance(mods,dict):continue
        for name,c in mods.items():
            v=logs[comp][:,[genes[comp].index(g) for g in c['genes']]]
            raw=((v-np.array(c['gene_mean']))/np.array(c['gene_sd'])).mean(1)
            out[name]=(raw-c['module_mean'])/c['module_sd']
    out['balance']=(out['SPP1hi']-out['CXCL10hi']-cal['balance_mean'])/cal['balance_sd']
    return pd.DataFrame(out)
def residual(v,design):
    r=rankdata(v);return r-design@np.linalg.lstsq(design,r,rcond=None)[0]
def run(folder):
    cfg=json.loads((folder/'config.json').read_text(encoding='utf-8'))
    d=pd.read_csv(folder/'cohort.csv');n=len(d);logs={};genes={};checks=[]
    for comp in ['immune','stroma']:
        with np.load(folder/f'{comp}_counts.npz',allow_pickle=False) as z:
            counts=z['counts'];umi=z['umi'];donor=z['donor']
        assert counts.shape[0]==len(umi)==len(donor) and (umi>0).all()
        a=np.zeros((n,counts.shape[1]),np.int64);np.add.at(a,donor,counts)
        den=np.bincount(donor,weights=umi,minlength=n);assert (a.sum(1)<=den).all()
        logs[comp]=np.log1p(1e6*a/den[:,None]);genes[comp]=json.loads((folder/f'{comp}_genes.json').read_text())
        checks.append({'check':comp+'_full_RNA_denominator','passed':True})
    cal=json.loads((folder/'calibration.json').read_text());sc=compute(logs,genes,cal)
    expected=pd.read_csv(folder/'scores.csv');assert np.allclose(sc[sc.columns],expected[sc.columns],rtol=1e-10,atol=1e-10)
    checks.append({'check':'all_six_states_two_ECM_and_balance_scores','passed':True})
    cols=[np.ones(n),d.diagnosis.eq('IPF').to_numpy(float)]
    if cfg['adjust_source']:cols.append(d.source.eq('NTI').to_numpy(float))
    design=np.column_stack(cols);assert np.linalg.matrix_rank(design)==design.shape[1]
    keys=['diagnosis','source'] if cfg['adjust_source'] else ['diagnosis']
    groups=[np.array(ix) for ix in d.groupby(keys,sort=True).indices.values()]
    # SCP seed generation must preserve the original 0=control,1=IPF order.
    if not cfg['adjust_source']:groups=[np.flatnonzero(d.diagnosis.eq(dx)) for dx in ['Control','IPF']]
    if cfg['exact']:
        combos=list(itertools.product(*(list(itertools.permutations(g)) for g in groups)))
        pi=np.tile(np.arange(n),(len(combos),1))
        for i,parts in enumerate(combos):
            for ix,p in zip(groups,parts):pi[i,ix]=p
    else:
        rng=np.random.default_rng(20261025);pi=np.tile(np.arange(n),(99999,1))
        for ix in groups:pi[:,ix]=rng.permuted(np.tile(ix,(len(pi),1)),axis=1)
    results=pd.read_csv(folder/'primary.csv');new=[]
    rng=np.random.default_rng(cfg['bootstrap_seed']);bi=np.tile(np.arange(n),(10000,1))
    for ix in groups:bi[:,ix]=rng.choice(ix,size=(len(bi),len(ix)),replace=True)
    def batch_residual(v):
        z=rankdata(v,axis=1)
        for ix in groups:z[:,ix]-=z[:,ix].mean(1,keepdims=True)
        return z
    y=sc.ECM_structure.to_numpy();yr=residual(y,design)
    for name in LINKS:
        x=sc[name].to_numpy();xr=residual(x,design);den=np.linalg.norm(xr)*np.linalg.norm(yr);rho=xr@yr/den
        null=yr[pi]@xr/den;exceed=int((np.abs(null)>=abs(rho)-1e-12).sum())
        p=exceed/len(pi) if cfg['exact'] else (exceed+1)/(len(pi)+1)
        bx=batch_residual(x[bi]);by=batch_residual(y[bi]);bd=np.linalg.norm(bx,axis=1)*np.linalg.norm(by,axis=1)
        b=np.divide((bx*by).sum(1),bd,out=np.full(len(bi),np.nan),where=bd>1e-12)
        ci=np.quantile(b[np.isfinite(b)],[.025,.975]);row=results[results.association.str.startswith(name)].iloc[0]
        original_p=row['p_exact'] if cfg['exact'] else row['p_raw']
        assert np.allclose([rho,p,*ci],[row.partial_Spearman,original_p,row.CI95_low,row.CI95_high],rtol=1e-10,atol=1e-10)
        new.append({'association':name,'rho':float(rho),'p':float(p),'CI95_low':float(ci[0]),'CI95_high':float(ci[1])})
        checks.append({'check':name+'_rho_p_and_recomputed_bootstrap','passed':True})
    last=0
    for k,j in enumerate(np.argsort([x['p'] for x in new])):
        last=max(last,min(1.,(2-k)*new[j]['p']));new[j]['p_Holm']=last
        assert np.isclose(last,results.iloc[j].p_Holm)
    return {'cohort':cfg['cohort'],'checks':checks,'results':new,'biological_validation':False}
def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=ROOT/'replay_run');args=p.parse_args()
    assert not args.output.exists(),'Use a NEW output directory to preserve old results.'
    manifest=json.loads((ROOT/'input_hashes.json').read_text())
    for item in manifest:assert digest(ROOT/item['file'])==item['sha256'],item['file']
    rows=[run(ROOT/'inputs'/name) for name in ['SCP2879','GSE135893']]
    args.output.mkdir(parents=True)
    (args.output/'replay_receipt.json').write_text(json.dumps({'status':'PASS','scope':'fixed score reconstruction, four primary rho/p/Holm and recomputed primary bootstrap CIs',
      'not_rerun':['raw filtering or annotation','all sensitivity fits','biological or clinical validation'],
      'cohorts':rows,'python':sys.version},indent=2),encoding='utf-8')
    print('PASS: both cohorts, all four primary estimates/p/Holm/bootstrap intervals and all saved program scores.')
if __name__=='__main__':main()
