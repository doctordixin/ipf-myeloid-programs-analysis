ECM extension 2026-10-25

Purpose: reproduce the saved exploratory same-donor cellular results, including non-replication.
No data downloading, patient re-identification, new gene selection or causal analysis occurs.

From the extracted Analysis_Code folder:
  python ECM_extension/replay.py --output ecm_replay_new
  python portable_replay.py --output core_replay_new
Each output directory must be new. Dependencies: numpy, pandas, scipy, statsmodels;
the core replay requirements are in the parent folder. Plotting also requires matplotlib.
Use the tested environment versions recorded in the receipts; do not overwrite existing results.

The ECM replay reconstructs six program scores, two ECM scores and the balance score
from the supplied small target-count matrices with independently stored COMPLETE RNA
denominators. It recalculates four primary partial correlations, specified permutation
P values, Holm adjustment and stratified donor bootstrap intervals, checking saved values.
Input hashes are checked before execution. Sampling sensitivities and complete null/opposite
results are retained in results/. They are not all re-fitted by the default replay.

Optional offline raw-count reconstruction:
  python ECM_extension/raw_reconstruct.py --raw-dir YOUR_RAW_FOLDER --output raw_check_new
Place the two SCP2879 raw_matrix.mtx.gz files and GSE135893_matrix.mtx.gz in that folder,
or provide --secondary-raw-dir SECOND_FOLDER. Source landing pages and exact SHA256 are
in raw_reconstruction_spec.json. The program streams all RNA features, checks hashes,
gzip completion/entry totals, and checks every selected cell's full-RNA denominator
and every target count. It does not redo the source authors' cell calling, annotation,
integration or donor assignment; numeric row/column maps make that provenance explicit.
This raw reconstruction was run successfully on all three actual matrices/four pools.
Large source matrices are intentionally not duplicated in the submission archive.

  python ECM_extension/plot_figures.py
This creates figure_run/Figures within ECM_extension from the saved result tables.
The scripts do not create simulated research values. Figure1 shows parallel evidence;
S10 reports both positive and negative associations. The plotting entry point uses no
private workspace paths and can be run from an unrelated working directory.

plans/ contains preanalysis specifications and the preassociation same-gene identifier
amendment; local locks were not public preregistration. GSE results followed knowledge
of SCP results. Cohort-specific calibration is not a transferable clinical threshold.
Two-test Holm families are separate by cohort. Small-stratum percentile CI coverage
is uncertain; technical sampling quantiles are not population confidence intervals.
Numerical replay and separate implementations are not independent biological validation.
AI-assisted coding is disclosed in the manuscript; authors remain responsible.
