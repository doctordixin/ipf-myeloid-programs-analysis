"""Optional offline MatrixMarket reconstruction. Source matrices stay outside the code zip."""
from pathlib import Path
import argparse,gzip,hashlib,json
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parent
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--raw-dir',type=Path,required=True);parser.add_argument('--secondary-raw-dir',type=Path);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    assert not args.output.exists(),'Preserve prior receipts: choose a new output directory.'
    cfg=json.loads((ROOT/'raw_reconstruction_spec.json').read_text());receipts=[]
    for spec in cfg:
        raw=args.raw_dir/spec['filename']
        if not raw.exists() and args.secondary_raw_dir:raw=args.secondary_raw_dir/spec['filename']
        assert raw.exists(),f'Missing {spec["filename"]}; retrieve from {spec["source"]}'
        assert sha(raw)==spec['sha256'],'Raw matrix hash mismatch'
        parts=[]
        for item in spec['targets']:
            cells=pd.read_csv(ROOT/item['cells']);gene=pd.read_csv(ROOT/item['genes'])
            with np.load(ROOT/item['expected_counts'],allow_pickle=False) as z:expected=z['counts'];expected_umi=z['umi']
            a=np.zeros_like(expected);total=np.zeros(len(cells),np.int64)
            cm=np.full(spec['matrix_cells'],-1,np.int64);cm[cells.matrix_column_1based.to_numpy()-1]=np.arange(len(cells))
            gm=np.full(spec['matrix_genes'],-1,np.int64);gm[gene.matrix_row_1based.to_numpy()-1]=np.arange(len(gene))
            parts.append((item,a,total,cm,gm,expected,expected_umi))
        seen=0
        with gzip.open(raw,'rt',encoding='ascii') as f:
            assert f.readline().lower().startswith('%%matrixmarket matrix coordinate')
            line=f.readline()
            while line.startswith('%'):line=f.readline()
            ng,nc,nnz=map(int,line.split());assert (ng,nc)==(spec['matrix_genes'],spec['matrix_cells'])
            for q in pd.read_csv(f,sep=r'\s+',header=None,names=['r','c','v'],dtype=np.int64,chunksize=1000000):
                row=q.r.to_numpy()-1;col=q.c.to_numpy()-1;v=q.v.to_numpy();assert (v>0).all()
                for item,a,total,cm,gm,expected,expected_umi in parts:
                    c=cm[col];g=gm[row];ok=c>=0;np.add.at(total,c[ok],v[ok]);ok&=g>=0;np.add.at(a,(c[ok],g[ok]),v[ok])
                seen+=len(q)
            assert seen==nnz
        for item,a,total,cm,gm,expected,expected_umi in parts:
            assert np.array_equal(a,expected) and np.array_equal(total,expected_umi)
            receipts.append({'cohort_pool':item['label'],'raw_sha256':spec['sha256'],'target_counts_exact':True,'full_cell_RNA_exact':True,'CRC_and_entry_count':True,'cells':len(total)})
        print('Raw reconstruction verified',spec['filename'],flush=True)
    args.output.mkdir(parents=True)
    (args.output/'raw_reconstruction_receipt.json').write_text(json.dumps(receipts,indent=2),encoding='utf-8')
if __name__=='__main__':main()
