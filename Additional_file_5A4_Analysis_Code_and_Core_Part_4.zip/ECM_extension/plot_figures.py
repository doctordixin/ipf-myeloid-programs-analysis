"""Scientific contract: cohort-sensitive covariation, not causal cell communication.
Figure 1: parallel architecture. S10 a/b: all eligible donors, c: four primary
estimates with donor bootstrap CIs, d: composition sensitivity point estimates only.
Python-only; existing scores/statistics are not refit or selected.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'figure_run';FIG=OUT/'Figures'
FIG.mkdir(exist_ok=True,parents=True)
mpl.rcParams.update({'font.family':'Arial','font.size':7,'axes.labelsize':8,'axes.titlesize':9,'pdf.fonttype':42,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False})
def save(fig,name):
    fig.savefig(FIG/(name+'.pdf'))
    fig.savefig(FIG/(name+'.svg'))
    fig.savefig(FIG/(name+'.png'),dpi=300)
    fig.savefig(FIG/(name+'.tiff'),dpi=600,pil_kwargs={'compression':'tiff_lzw'})
def architecture():
    fig=plt.figure(figsize=(7.09,6.2));ax=fig.add_axes([.03,.025,.94,.95]);ax.set(xlim=(0,1),ylim=(0,1));ax.axis('off')
    def box(x,y,w,h,title,lines):
        ax.add_patch(Rectangle((x,y),w,h,facecolor='#F1F3F5',edgecolor='#596773',linewidth=.8))
        ax.text(x+.014,y+h-.025,title,va='top',fontweight='bold',fontsize=8)
        ax.text(x+.014,y+h-.075,'\n'.join(lines),va='top',fontsize=7,linespacing=1.45)
    ax.text(0,.99,'a',fontweight='bold',fontsize=10)
    box(.04,.83,.92,.15,'Fixed external program definitions',[
        'MLM0 | CCL2hi | MLM1 | IL1Bhi | SPP1hi | CXCL10hi',
        '20 source genes per program; unweighted scores; standardized SPP1hi minus CXCL10hi contrast'])
    ax.text(0,.78,'b',fontweight='bold',fontsize=10)
    box(.04,.45,.285,.31,'BAL mortality',[
        'GSE70866: 176 IPF; 100 deaths','Three centres, one source study','CCL2hi higher / MLM0 lower risk',
        'Exploratory associations','Clinical increment unestablished'])
    box(.3575,.45,.285,.31,'Regional tissue',[
        'Two donor-paired bulk studies','19 and 13 paired IPF donors','Higher regional contrast',
        'Mainly lower CXCL10hi','Limited pathology concordance'])
    box(.675,.45,.285,.31,'Supporting layers',[
        'BAL: 11 IPF / 5 controls','SPP1hi main q = 0.00481','Contrast main q = 0.0601',
        'CCL2hi main q = 0.0764','Plasma: summary-level support'])
    ax.text(0,.405,'c',fontweight='bold',fontsize=10)
    box(.04,.065,.92,.325,'Interpretation boundaries',[
        'Macrophage composition: conditional effects uncertain (21 donors)',
        'Spatial qualification: no robust primary replication (4 IPF donors); depth/block sensitivity',
        'Macrophage–ECM: SCP2879 association is composition-sensitive (12 donors)',
        'GSE135893 same-donor check: association not replicated (10 donors; overlaps prior cohort)',
        'Corrected older BAL cohorts: no FDR-positive endpoint',
        'No independent BAL outcome validation; no temporal or causal chain'])
    ax.text(.5,.015,'Parallel subjects, compartments and endpoints; no cross-branch causal arrows.',ha='center',fontsize=7)
    save(fig,'Figure_1_updated_architecture');plt.close(fig)
def supplemental():
    a=pd.read_csv(ROOT/'results/SCP2879/primary_patient_scores.csv')
    b=pd.read_csv(ROOT/'results/GSE135893/patient_scores.csv')
    assert len(a)==12 and len(b)==10 and a.donor_token.is_unique and b.donor_token.is_unique
    fig=plt.figure(figsize=(7.09,7.6));grid=fig.add_gridspec(2,2,height_ratios=[1,1.22],left=.10,right=.97,top=.95,bottom=.10,hspace=.55,wspace=.35)
    axes=[fig.add_subplot(grid[i,j]) for i,j in [(0,0),(0,1),(1,0),(1,1)]]
    for j,(d,label) in enumerate([(a,'SCP2879'),(b,'GSE135893')]):
        dx='diagnosis';source='site' if j==0 else 'source'
        for (diagnosis,site),q in d.groupby([dx,source]):
            ipf=diagnosis=='IPF';axes[j].scatter(q.CCL2hi,q.ECM_structure,color='#B86B45' if ipf else '#376A8C',marker='^' if site in ['HSJ','NTI'] else 'o',s=28,label=f'{diagnosis.replace("Non-ILD Control","Control")} / {site} (n={len(q)})')
        axes[j].set(xlabel='Macrophage CCL2hi score',ylabel='Fibroblast ECM structure',title=label)
        axes[j].legend(fontsize=6,loc='lower left',bbox_to_anchor=(-.03,-.43),frameon=False)
    primary=[]
    for folder,label in [('SCP2879','SCP2879'),('GSE135893','GSE135893')]:
        for row in pd.read_csv(ROOT/'results'/folder/'primary_associations.csv').itertuples():
            primary.append((label,'CCL2hi' if row.association.startswith('CCL2') else 'Balance',row.partial_Spearman,row.CI95_low,row.CI95_high,row.p_Holm))
    ax=axes[2]
    for i,(cohort,name,r,lo,hi,p) in enumerate(primary):
        y=3-i;color='#376A8C' if cohort=='SCP2879' else '#8C6A8B'
        ax.errorbar(r,y,xerr=np.array([[r-lo],[hi-r]]),fmt='o',color=color,capsize=2)
        ax.text(-1.04,y+.16,f'{cohort}: {name}; Holm P={p:.3g}',fontsize=6.5)
    ax.axvline(0,color='#A0A0A0',ls='--',lw=.7);ax.set(xlim=(-1.05,1.05),ylim=(-.5,3.7),yticks=[],xlabel='Partial Spearman with 95% donor bootstrap CI',title='Primary associations')
    ax=axes[3]
    labels=['SCP: diagnosis','SCP: + CTHRC1 fraction','GSE: diagnosis + source','GSE: + fibroblast PC1']
    vals=[primary[0][2],.31700026992724667,primary[2][2],.18757873067878106]
    # Values are cross-checked against saved sensitivity rows before drawing.
    s=pd.read_csv(ROOT/'results/SCP2879/all_deterministic_sensitivities.csv')
    t=pd.read_csv(ROOT/'results/GSE135893/deterministic_sensitivities.csv')
    assert np.isclose(s.loc[(s.sensitivity=='adjust_disease_plus_CTHRC1_fib_fraction')&(s.association=='CCL2hi'),'rho'].iloc[0],vals[1])
    assert np.isclose(t.loc[(t.sensitivity=='adjust_stroma_composition_PC1')&(t.association=='CCL2hi'),'rho'].iloc[0],vals[3])
    for i,(label,r) in enumerate(zip(labels,vals)):
        ax.plot(r,3-i,'o',color='#376A8C' if i<2 else '#8C6A8B');ax.text(-.04,3-i+.20,label,fontsize=6.5)
    ax.axvline(0,color='#A0A0A0',ls='--',lw=.7);ax.set(xlim=(-.08,1),ylim=(-.5,3.7),yticks=[],xlabel='CCL2hi partial Spearman (point estimates only)',title='Composition sensitivity')
    for letter,ax in zip('abcd',axes):ax.text(-.17,1.09,letter,transform=ax.transAxes,fontweight='bold',fontsize=10)
    fig.text(.10,.025,'c: SCP adjusts diagnosis; GSE adjusts diagnosis and source. d: no new P values or intervals.\nAll points represent donors; the cohorts are not pooled. Complete negative and sensitivity results: Tables S11–S12.',fontsize=7)
    save(fig,'Supplementary_Figure_S10_macrophage_ECM');plt.close(fig)
if __name__=='__main__':architecture();supplemental()
