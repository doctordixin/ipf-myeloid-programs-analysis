"""Offline replay of specified numerical paths, not independent biological validation.

Run: python portable_replay.py --output replay_run
All inputs are relative to this script. Original files are read-only.
"""
import argparse,hashlib,itertools,json,platform,sys
from pathlib import Path
import numpy as np
import pandas as pd
import scipy
from scipy import stats
import statsmodels
from statsmodels.duration.hazard_regression import PHReg
from bal_patient_core import STATES,ENDPOINTS,calibrate,logcpm,compare,bh
ROOT=Path(__file__).resolve().parent
I=ROOT/'inputs';EXPECTED=ROOT/'expected'
CHECKS=[]
def check(name,ok,details=''):
    CHECKS.append({'check':name,'passed':bool(ok),'details':details})
    if not ok:raise AssertionError(name+': '+details)
def close(name,a,b,atol=1e-8,rtol=1e-8):
    check(name,np.allclose(a,b,atol=atol,rtol=rtol,equal_nan=True),f'max abs delta={float(np.max(np.abs(np.asarray(a)-np.asarray(b)))):.9g}; atol={atol}, rtol={rtol}')
def main(out):
    out.mkdir(exist_ok=False,parents=True)
    manifest=json.loads((ROOT/'input_manifest.json').read_text())
    for r in manifest:
        check('input_hash_'+r['file'],hashlib.sha256((ROOT/r['file']).read_bytes()).hexdigest()==r['sha256'])
    print('Inputs verified',flush=True)
    # Refit the mortality family with a separate Efron Cox engine.
    d=pd.read_csv(I/'gse70866_mlm_state_scores.csv');d=d[d.diagnosis.str.lower().eq('ipf')].copy()
    check('mortality_denominators',len(d)==176 and int(d.event.sum())==100)
    original=pd.read_csv(EXPECTED/'stage39_bal_global_family.csv').set_index('marker').loc[ENDPOINTS]
    cox=[]
    for marker in ENDPOINTS:
        fit=PHReg(d.time,d[['gap',marker]],status=d.event,strata=d.cohort,ties='efron').fit()
        cox.append({'marker':marker,'beta':fit.params[1],'se':fit.bse[1],'hr':np.exp(fit.params[1]),'p':fit.pvalues[1]})
    cox=pd.DataFrame(cox).set_index('marker');cox['q']=bh(cox.p)
    close('mortality_HR_cross_engine',cox.hr,original.hr,atol=2e-6,rtol=2e-5)
    close('mortality_p_cross_engine',cox.p,original.p,atol=1e-6,rtol=2e-5)
    cox.to_csv(out/'mortality_replay.csv')
    print('BAL mortality family replayed',flush=True)
    paired=pd.read_csv(I/'stage24_regional_gradient_paired_values.csv')
    region=[]
    for dataset,expected,n in [('GSE213001',.943,19),('GSE199949',1.205,13)]:
        q=paired[(paired.dataset==dataset)&(paired.diagnosis=='IPF')&(~paired.adjusted)&(paired.endpoint=='SPP1hi_CXCL10hi_balance')]
        check(dataset+'_paired_donors',q.donor.nunique()==n and len(q)==n)
        dz=q.difference.mean()/q.difference.std(ddof=1)
        check(dataset+'_published_rounded_dz',round(dz,3)==expected)
        for endpoint,g in paired[(paired.dataset==dataset)&(paired.diagnosis=='IPF')&(~paired.adjusted)].groupby('endpoint'):
            test=stats.ttest_1samp(g.difference,0)
            region.append({'dataset':dataset,'endpoint':endpoint,'n':len(g),'mean':g.difference.mean(),'dz':g.difference.mean()/g.difference.std(ddof=1),'p':test.pvalue})
    region=pd.DataFrame(region);region['q']=region.groupby('dataset').p.transform(lambda p:bh(p.to_numpy()));region.to_csv(out/'paired_regional_replay.csv',index=False)
    # Start the new BAL path from full-RNA macrophage pseudobulk, before marker filtering.
    z=np.load(I/'macrophage_pseudobulk_counts.npz');counts=z['counts'];features=z['features'].astype(str);donors=z['donors'].astype(str).tolist()
    check('full_BAL_RNA_rows',counts.shape==(49764,22) and len(set(donors))==22)
    scored=pd.read_csv(EXPECTED/'patient_scores_primary_reference.csv').set_index('donor')
    meta=scored.loc[donors];fit_donors=meta.index[meta.in_main_comparison].tolist()
    signatures=json.loads((I/'mlm_six_state_signatures_frozen.json').read_text())['states']
    requested=set(g for genes in signatures.values() for g in genes);select=np.flatnonzero(np.isin(features,list(requested)))
    expr=pd.DataFrame(logcpm(counts[select],counts.sum(axis=0)),index=features[select],columns=donors)
    new,cal=calibrate(expr,signatures,fit_donors)
    close('BAL_scores_from_fullRNA',new.loc[donors,ENDPOINTS],scored.loc[donors,ENDPOINTS])
    result=compare(new,meta.loc[fit_donors],'main_same_source_11_vs_5',np.random.default_rng(20261023))
    expected=pd.read_csv(EXPECTED/'primary_seven_endpoint_results.csv').set_index('endpoint').loc[ENDPOINTS]
    result=result.set_index('endpoint').loc[ENDPOINTS]
    close('BAL_exact_p',result.permutation_p,expected.permutation_p,atol=1e-14,rtol=0)
    close('BAL_primary_q',result.q_BH_7,expected.q_BH_7,atol=1e-14,rtol=0)
    close('BAL_Welch_CI',result[['mean_difference','welch_ci_low','welch_ci_high']],expected[['mean_difference','welch_ci_low','welch_ci_high']])
    result.to_csv(out/'BAL_primary_replay.csv');print('Full-RNA BAL scores and seven tests replayed',flush=True)
    # Prior BAL correction: full library totals are explicitly checked before projection.
    import gzip
    raw=I/'GSE166036_count.tsv.gz'
    with gzip.open(raw,'rt') as h:names=h.readline().rstrip('\n').split('\t')
    full=pd.read_csv(raw,sep='\t',header=None,skiprows=1,names=['gene_id']+names)
    library=pd.read_csv(I/'sample_library_sizes.csv').set_index('matrix_sample')
    check('legacy_fullRNA_rows',len(full)==30727)
    close('legacy_fullRNA_denominators',full[library.index].sum(axis=0),library.full_RNA_library,atol=0,rtol=0)
    target=pd.read_csv(I/'unchanged_target_counts.csv',index_col=0)
    stored=pd.read_csv(I/'corrected_target_logCPM.csv',index_col=0)
    actual=pd.DataFrame(logcpm(target.to_numpy(),library.loc[target.columns,'full_RNA_library']),index=target.index,columns=target.columns)
    close('legacy_corrected_logCPM',actual,stored)
    mapping=pd.read_csv(I/'frozen_mapping_used.csv',dtype={'gene_id':str})
    full['gene_id']=full.gene_id.astype(str)
    mapped=mapping.merge(full,on='gene_id',how='inner').groupby('query')[target.columns.tolist()].sum()
    close('legacy_target_counts_from_frozen_mapping',mapped.loc[target.index,target.columns],target,atol=0,rtol=0)
    old_score,_=calibrate(actual,signatures,target.columns.tolist())
    all_old=pd.read_csv(EXPECTED/'corrected_patient_scores.csv')
    saved_old=all_old[all_old.dataset=='GSE166036'].set_index('matrix_sample')
    close('legacy_corrected_scores',old_score.loc[saved_old.index,ENDPOINTS],saved_old[ENDPOINTS])
    effects=pd.read_csv(EXPECTED/'corrected_cohort_effects.csv')
    patient=pd.read_csv(EXPECTED/'corrected_patient_scores.csv')
    for dataset,g in patient.groupby('dataset'):
        y=g[ENDPOINTS].to_numpy();case=g.analysis_group.eq('IPF').to_numpy();n1=case.sum()
        obs=np.abs(y[case].mean(0)-y[~case].mean(0));total=y.sum(0);exceed=np.zeros(7);tested=0
        indices=itertools.combinations(range(len(y)),int(n1))
        while batch:=list(itertools.islice(indices,4096)):
            part=y[np.asarray(batch)].sum(axis=1)
            delta=part/n1-(total-part)/(len(y)-n1)
            exceed+=(np.abs(delta)>=obs-1e-12).sum(axis=0);tested+=len(batch)
        p=exceed/tested;expected=effects[effects.dataset==dataset].set_index('marker').loc[ENDPOINTS]
        close(dataset+'_exact_mean_difference_p',p,expected.permutation_p,atol=1e-14,rtol=0)
        close(dataset+'_BH7',bh(p),expected.q_within_cohort,atol=1e-14,rtol=0)
    # Composition and spatial checks use biological donors, not individual cells/spots.
    models=pd.read_csv(I/'subtype_adjustment_and_within_cluster_tests.csv')
    close('composition_family_BH32',bh(models.p.to_numpy()),models.q_global_new_program_tests)
    frac=pd.read_csv(I/'donor_cluster_fractions.csv').set_index('donor')
    check('composition_21_donors',len(frac)==21);close('cluster_proportions_sum_one',frac.sum(axis=1),np.ones(21))
    cov=pd.read_csv(I/'donor_composition_PC_scores.csv')
    for name,pcs in [('depth_source',[]),('depth_source_PC1',['PC1']),('depth_source_PC1_PC2',['PC1','PC2'])]:
        depth=np.log2(cov.total_umi/cov.n_cells);depth-=depth.mean()
        X=pd.concat([pd.DataFrame({'intercept':1.,'disease':cov.diagnosis.eq('IPF').astype(float),'depth':depth}),pd.get_dummies(cov.source,drop_first=True,dtype=float),cov[pcs]],axis=1).to_numpy(float)
        for endpoint in ['SPP1hi','CCL2hi']:
            beta=np.linalg.lstsq(X,cov[endpoint],rcond=None)[0][1]
            close('conditional_'+name+'_'+endpoint,[beta],models[(models.model==name)&(models.endpoint==endpoint)].delta.to_numpy())
    tests=pd.read_csv(I/'spatial_depth_and_block_tests.csv');values=pd.read_csv(I/'spatial_depth_donor_differences.csv')
    for family,t in tests.groupby('family'):
        close('spatial_BH_'+family,bh(t.p.to_numpy()),t.q_BH)
        for r in t.itertuples():
            v=values.loc[values.family==family,r.endpoint].to_numpy();signs=np.array(list(itertools.product([-1,1],repeat=len(v))))
            p=np.mean(np.abs(signs@v/len(v))>=abs(v.mean())-1e-10)
            close('spatial_signflip_'+family+'_'+r.endpoint,[p],[r.p]);check('spatial_donor_n_'+family+'_'+r.endpoint,len(v)==r.n_donors)
    receipt={'status':'VERIFIED_SCOPED_NUMERICAL_REPLAY','checks':CHECKS,'scope':['mortality Efron-Cox family from prepared scores (cross-engine)','paired-regional scores (prepared donor differences)','GSE252465 full-RNA pseudobulk scoring and primary tests','GSE166036 full library denominator and earlier BAL permutation tests','composition coefficients/BH and spatial sign flips/BH'],
      'not_rerun':['raw single-cell filtering/integration from RDS','all historical sensitivities and figure rendering','original raw-data retrieval','clinical or biological external validation'],
      'environment':{'python':sys.version,'platform':platform.platform(),'numpy':np.__version__,'pandas':pd.__version__,'scipy':scipy.__version__,'statsmodels':statsmodels.__version__}}
    (out/'replay_receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
    print(f'PASS: {len(CHECKS)} scoped checks',flush=True)
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=ROOT/'replay_run');args=parser.parse_args()
    main(args.output.resolve())
