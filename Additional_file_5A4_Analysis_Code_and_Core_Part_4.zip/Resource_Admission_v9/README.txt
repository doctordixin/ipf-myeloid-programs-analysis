v9 resource admission, not new biological validation.
Run python verify_admission.py to verify the included compact records and hashes (standard library only).
This verifier checks recorded decisions; it does not reconstruct raw RNA measurements from these CSV summaries.
Raw workflow requires the original 1,346,304,362-byte GEO allPCLS file, rdata 1.1.0, NumPy and pandas, the original project-relative layout, and the supplied streaming reader/audit scripts. It was executed locally; no native R/Seurat validObject test was performed. Large RDS/arrays/parts are not in this submission archive. audit_pcls_v9.py retains its original project paths and is not advertised as a standalone raw-data replay.
Local lock preceded object metadata/scores. Counts, annotation coverage and depth passed; donor identity/pairing failed. D5 cocktail fibroblasts: 87 nuclei, below the locked 100-cell minimum. No treatment scores, P values, donor tests or clinical associations were fitted. This is an admission failure, not a biological null.
D0..D5 and H12 are times; orig.ident is time x treatment, not donor. The 19 in-vivo GEO subject IDs cannot be assigned to these PCLS without a real mapping. Actual PCLS donor number remains unidentified. No assumption of one donor or thirteen donors is made.
The 17.62 GB in-vivo file was not downloaded. Metadata provenance suggests possible overlap with historical micro-CT tissue collections; no independent BAL mortality evidence is provided.
The previous numerical entry points and result files are unchanged. New reference numbering is recorded separately and does not alter historical code/results.
Codex assisted code, search and manuscript editing; author responsibility is unchanged.
