"""Bounded four-stream public download, with persistent exact HTTP range parts."""
from pathlib import Path
import urllib.request,concurrent.futures,time,json,hashlib,gzip,os
R=Path(__file__).resolve().parents[1];O=R/'outputs/GSE286182_gate_20261026';O.mkdir(exist_ok=True)
URL='https://ftp.ncbi.nlm.nih.gov/geo/series/GSE286nnn/GSE286182/suppl/GSE286182_SeuratObject.allPCLS.rds.gz'
SIZE=1346304362;STEP=16*1024*1024;P=O/'download_parts';P.mkdir(exist_ok=True)
def chunk(i):
    start=i*STEP;end=min(SIZE,start+STEP)-1;dst=P/f'{i:04d}.part';need=end-start+1
    if dst.exists() and dst.stat().st_size==need:return i,'cached'
    for attempt in range(5):
        got=dst.stat().st_size if dst.exists() else 0
        if got>need:raise ValueError('oversize persistent part')
        lo=start+got
        if got==need:return i,'resumed'
        try:
            req=urllib.request.Request(URL,headers={'Range':f'bytes={lo}-{end}','Accept-Encoding':'identity'})
            with urllib.request.urlopen(req,timeout=45) as res:
                if res.status!=206 or res.headers.get('Content-Range')!=f'bytes {lo}-{end}/{SIZE}':raise ValueError('range identity mismatch')
                with dst.open('ab') as f:
                    while b:=res.read(min(1024*1024,need-got)):
                        f.write(b);got+=len(b)
                        if got==need:break
            if dst.stat().st_size==need:return i,'downloaded'
        except Exception as e:
            print('RETRY',i,attempt+1,type(e).__name__,str(e)[:90],flush=True)
            time.sleep(min(attempt+1,4))
    raise RuntimeError(f'Part {i} incomplete; all bytes retained')
n=(SIZE+STEP-1)//STEP;t=time.monotonic();done=0
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
    for f in concurrent.futures.as_completed([ex.submit(chunk,i) for i in range(n)]):
        i,status=f.result();done+=1
        if done%4==0 or done==n:print('PROGRESS',done,'/',n,'elapsed_seconds',round(time.monotonic()-t),flush=True)
dst=O/'GSE286182_SeuratObject.allPCLS.rds.gz';tmp=O/(dst.name+'.assembling');h=hashlib.sha256()
with tmp.open('wb') as out:
    for i in range(n):
        with (P/f'{i:04d}.part').open('rb') as f:
            while b:=f.read(4*1024*1024):out.write(b);h.update(b)
assert tmp.stat().st_size==SIZE
total=0
with gzip.open(tmp,'rb') as f:
    while b:=f.read(4*1024*1024):total+=len(b)
os.replace(tmp,dst)
receipt={'url':URL,'bytes':SIZE,'sha256':h.hexdigest(),'gzip_crc_passed':True,'uncompressed_bytes':total,'parts_preserved':n,'scope':'Download and compression integrity only; no biological analysis.'}
(O/'PCLS_download_integrity.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8');print('COMPLETE',json.dumps(receipt),flush=True)
