"""Read-only PCLS count/coverage gate; never fits treatment effects without donors."""
from pathlib import Path
import json, re
import numpy as np
import pandas as pd

R=Path(__file__).resolve().parents[1]
B=R/'outputs/GSE286182_gate_20261026'; O=B/'object_gate'
def js(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
md=pd.read_csv(O/'cell_metadata.tsv',sep='\t',index_col=0)
d=json.loads((O/'matrix_descriptors.json').read_text())['RNA.counts']
def arr(k):
    a=d[k];p=R/a['path']
    return np.load(p,mmap_mode='r') if a.get('npy') else np.memmap(p,mode='r',dtype=a['dtype'],shape=(a['length'],))
x,i,p=arr('x'),arr('i'),arr('p'); nf,nc=d['shape']
assert list(md.index)==d['cells'] and md.index.is_unique
assert len(set(d['features']))==nf and len(p)==nc+1 and int(p[0])==0 and int(p[-1])==len(x)==len(i)
assert np.all(np.diff(p)>=0)
raw_ok=True;imin=nf;imax=-1
for start in range(0,len(x),2000000):
    z=x[start:start+2000000];ri=i[start:start+2000000]
    raw_ok &= bool(np.all(np.isfinite(z)) and np.all(z>=0) and np.all(z==np.floor(z)))
    imin=min(imin,int(ri.min()));imax=max(imax,int(ri.max()))
assert raw_ok and imin>=0 and imax<nf
depth=np.array([np.sum(x[p[c]:p[c+1]],dtype=np.float64) for c in range(nc)])
stored=pd.to_numeric(md['nCount_RNA']).to_numpy()
depthmatch=bool(np.array_equal(depth,stored))
md['recomputed_RNA_count']=depth
md['audit_lineage']=md['baseName'].map({'MacAlv':'macrophage','MacSPP1':'macrophage','macCC':'macrophage','Fibroblast':'fibroblast'}).fillna('other')
summary=md.groupby(['orig.ident','Day','Condition','audit_lineage'],dropna=False).agg(cells=('recomputed_RNA_count','size'),RNA_total=('recomputed_RNA_count','sum'),median_RNA=('recomputed_RNA_count','median')).reset_index()
summary.to_csv(B/'PCLS_library_lineage_QC.csv',index=False)
states=json.loads((R/'data/derived/mlm_six_state_signatures_frozen.json').read_text())['states']
genesets={**states,'ECM_structure':['COL1A1','COL1A2','COL3A1','COL5A1','COL5A2','FN1'],'ECM_activation':['POSTN','CTHRC1','LRRC15','FAP','TGFBI','LOX','MMP14']}
features={g:j for j,g in enumerate(d['features'])};rows=[]
for lin in ['macrophage','fibroblast']:
    cols=np.flatnonzero(md.audit_lineage.eq(lin).to_numpy()); total=np.zeros(nf)
    for c in cols:
        a,b=int(p[c]),int(p[c+1]);np.add.at(total,i[a:b],x[a:b])
    for name,genes in genesets.items():
        for g in genes:
            row=features.get(g)
            rows.append({'lineage':lin,'program':name,'gene':g,'in_matrix':row is not None,'RNA_count_in_lineage':float(total[row]) if row is not None else None,'expressed_in_lineage':bool(row is not None and total[row]>0),'scope':'Catalogue/lineage coverage only; no donor-calibrated score or treatment inference'})
coverage=pd.DataFrame(rows);coverage.to_csv(B/'PCLS_gene_coverage.csv',index=False)
cov=coverage.groupby(['lineage','program']).agg(canonical=('gene','size'),in_matrix=('in_matrix','sum'),expressed=('expressed_in_lineage','sum')).reset_index()
cov.to_csv(B/'PCLS_coverage_summary.csv',index=False)
ident=md[['orig.ident','Day','Condition']].drop_duplicates()
identity_formula=(ident['orig.ident'].str.replace('_','',regex=False).str.replace('CTL','',regex=False).str.replace('FC','',regex=False)==ident.Day).all()
donor_fields=[c for c in md if re.search('donor|subject|patient|biological.rep|specimen',c,re.I)]
decision={'resource':'GSE286182 allPCLS','source_bytes':1346304362,'nuclei':nc,'RNA_features':nf,'nonzero_entries':len(x),'RNA_counts_finite_nonnegative_integer':raw_ok,'RNA_depth_equals_stored_nCount_RNA':depthmatch,'barcodes_match_exactly':True,'unique_barcode_and_feature_names':True,'metadata_columns':list(md.columns[:-2]),'library_labels':len(ident),'library_labels_explained_by_time_and_condition':bool(identity_formula),'donor_fields':donor_fields,'verified_independent_donor_pairs':None,'identity_gate':'FAILED: no verifiable donor/specimen-to-condition pairing in supplied object and audited public catalogue','inference_status':'NOT RUN: locked donor identity stop rule; not a biological null','lineage_cells':{str(k):int(v) for k,v in md.audit_lineage.value_counts().items()},'coverage_is_not_validation':True,'counts_of_cores_cells_libraries_times_not_counted_as_donors':True,'no_claim_of_pooled_or_single_donor':'Actual number of PCLS donors remains unidentified; cannot infer one or thirteen.','no_large_in_vivo_object_downloaded':True,'native_R_Seurat_validObject':'not performed; streaming RDS structural validation only','manuscript_action':'No new biological result added. Keep admission evidence in author review and reproducibility record.'}
primary=summary[summary.Day.eq('D5') & summary.audit_lineage.isin(['macrophage','fibroblast'])]
decision['120h_lineage_counts']=primary[['orig.ident','Condition','audit_lineage','cells']].to_dict('records')
decision['additional_cell_gate_failure']='120h cocktail fibroblast pool has 87 nuclei, below the locally locked 100-cell minimum even before any donor split.'
ident.to_csv(B/'PCLS_library_condition_mapping.csv',index=False)
js(B/'PCLS_admission_decision.json',decision)
print(json.dumps(decision,indent=2));print(cov.to_string(index=False))

