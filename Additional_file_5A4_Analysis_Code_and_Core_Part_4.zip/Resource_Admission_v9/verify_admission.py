"""Verify included gate records only; not raw-count reconstruction or association replay."""
from pathlib import Path
import json,hashlib,csv
B=Path(__file__).resolve().parent
h=json.loads((B/'gate_input_hashes.json').read_text(encoding='utf-8'))
for n,v in h.items():assert hashlib.sha256((B/n).read_bytes()).hexdigest()==v,n
d=json.loads((B/'PCLS_admission_decision.json').read_text(encoding='utf-8'))
m=list(csv.DictReader((B/'PCLS_library_condition_mapping.csv').open(encoding='utf-8')))
assert len(m)==13 and len({x['orig.ident'] for x in m})==13
assert d['verified_independent_donor_pairs'] is None and not d['donor_fields']
assert d['RNA_counts_finite_nonnegative_integer'] and d['barcodes_match_exactly']
assert d['RNA_depth_equals_stored_nCount_RNA']
assert any(x['Condition']=='Cocktail' and x['audit_lineage']=='fibroblast' and x['cells']==87 for x in d['120h_lineage_counts'])
print('PASS: included admission records/hash ledger; no donor-level effects fitted; not biological validation.')
