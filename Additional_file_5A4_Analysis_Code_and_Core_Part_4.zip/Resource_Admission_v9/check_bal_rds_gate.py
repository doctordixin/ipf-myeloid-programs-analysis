"""Read-only GSE252465 integrity and object-structure gate; no outcome analysis.

Uses rdata 1.1.0's parser with a streaming XDR backend. Large numeric vectors
are disk-backed, not expanded into dense matrices. The source is never changed.
"""
import argparse,gzip,hashlib,json,struct,time,shutil,sys
from pathlib import Path
import numpy as np
import pandas as pd
import rdata
from rdata.parser._parser import Parser
from rdata.parser._xdr import ParserXDR

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'data/raw/resource_gate_20261023/BAL/GSE252465_ILD_combined_sct_rpca20230720.rds.gz'
OUT=ROOT/'outputs/bal_object_gate_20261023'
EXPECTED='dcbb397c7930680bd39ee766d202124dc189d8e58db169091d6c523ff6a089ce'

def save(name,value):
    (OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')

def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
    return h.hexdigest()

class StreamingXDR(ParserXDR):
    def __init__(self,stream,cache):
        Parser.__init__(self,expand_altrep=True)
        self.file=stream;self.cache=cache;self.arrays=[];self.last=time.monotonic()
    def parse_int(self):
        return struct.unpack('>i',self.parse_string(4))[0]
    def parse_string(self,length):
        b=self.file.read(length)
        if len(b)!=length:raise EOFError(f'XDR short read: {len(b)}/{length}')
        return b
    def parse_nullable_int_array(self,*,fill_value=-2147483648):
        # Stock rdata's NA helper supports native int32 only; wire memmaps are >i4.
        data=self._parse_array(np.int32);mask=data==-2147483648
        if not np.any(mask):return data
        data[mask]=fill_value
        return np.ma.array(data,mask=mask,fill_value=fill_value)
    def _parse_array_values(self,dtype,length):
        if length<0:raise ValueError('unsupported negative/long-vector length')
        dtype=np.dtype(dtype);wire=dtype.newbyteorder('>');n=length*dtype.itemsize
        if n<8*1024*1024:
            return np.frombuffer(self.parse_string(n),dtype=wire).astype(dtype,copy=True)
        path=self.cache/f'array_{len(self.arrays):04d}.bin';h=hashlib.sha256()
        with path.open('xb') as f:
            left=n
            while left:
                b=self.parse_string(min(left,4*1024*1024));f.write(b);h.update(b);left-=len(b)
                if time.monotonic()-self.last>25:
                    print(f'XDR stream consumed {self.file.tell()/1024**3:.2f} GiB; caching numeric vectors',flush=True);self.last=time.monotonic()
        self.arrays.append({'path':str(path.relative_to(ROOT)),'dtype':wire.str,'length':length,'bytes':n,'sha256':h.hexdigest()})
        return np.memmap(path,dtype=wire,mode='r+',shape=(length,))

def ref(obj):
    for _ in range(100):
        if obj is None or obj.info.type.name!='REF':return obj
        obj=obj.referenced_object
    raise ValueError('reference cycle')

def scalar_string(obj):
    obj=ref(obj)
    if obj is None:return None
    if obj.info.type.name=='SYM':return scalar_string(obj.value)
    if obj.info.type.name=='CHAR':return None if obj.value is None else obj.value.decode('utf-8',errors='strict')
    raise TypeError(f'not a string: {obj.info.type.name}')

def pairs(obj):
    result={};obj=ref(obj)
    while obj is not None and obj.info.type.name not in ('NIL','NILVALUE'):
        if obj.info.type.name!='LIST':raise TypeError('expected named pairlist')
        key=scalar_string(obj.tag);result[key]=obj.value[0];obj=ref(obj.value[1])
    return result

def values(obj):
    obj=ref(obj)
    if obj.info.type.name=='STR':return [scalar_string(x) for x in obj.value]
    return obj.value

def attributes(obj):return pairs(ref(obj).attributes)

def named(obj):
    obj=ref(obj);names=values(attributes(obj)['names'])
    if len(names)!=len(obj.value):raise ValueError('named vector length mismatch')
    return dict(zip(names,obj.value,strict=True))

def describe(obj):
    obj=ref(obj);a=attributes(obj);v=obj.value
    return {'type':obj.info.type.name,'attributes':list(a),'class':values(a['class']) if 'class' in a else None,
      'length':len(v) if isinstance(v,(list,np.ndarray)) else None}

def vector_descriptor(obj,label):
    x=values(obj)
    if isinstance(x,np.memmap):
        return {'path':str(Path(x.filename).relative_to(ROOT)),'dtype':x.dtype.str,'length':len(x)}
    path=OUT/'arrays'/f'{label}.npy';np.save(path,x)
    return {'path':str(path.relative_to(ROOT)),'dtype':str(x.dtype),'length':len(x),'npy':True}

def metadata_frame(obj):
    columns=named(obj);result={}
    for key,value in columns.items():
        value=ref(value);a=attributes(value);v=values(value)
        if 'levels' in a:
            levels=values(a['levels'])
            result[key]=[None if np.ma.is_masked(i) or int(i)<1 else levels[int(i)-1] for i in v]
        else:result[key]=v
    frame=pd.DataFrame(result);a=attributes(obj);rows=values(a['row.names'])
    if isinstance(rows,list) and len(rows)==len(frame):frame.index=rows
    return frame

def main():
    OUT.mkdir(exist_ok=True);cache=OUT/'arrays';cache.mkdir(exist_ok=True)
    if any(cache.iterdir()):raise RuntimeError('non-empty array cache: inspect previous run before overwriting')
    if shutil.disk_usage(OUT).free<20*1024**3:raise RuntimeError('need at least 20 GiB free for bounded disk cache')
    report={'source':str(SOURCE.relative_to(ROOT)),'rdata_version':rdata.__version__,'source_bytes':SOURCE.stat().st_size,
      'scope':'integrity and feasibility only; manuscript and source read-only','status':'running'}
    save('object_integrity.json',report)
    h=digest(SOURCE)
    if h!=EXPECTED:raise ValueError('source SHA256 differs from download checkpoint')
    report['source_sha256']=h;print('Source SHA256 matches recorded completed download',flush=True)
    with SOURCE.open('rb') as raw,gzip.GzipFile(fileobj=raw,mode='rb') as outer:
        if outer.peek(2)[:2]!=b'\x1f\x8b':raise ValueError('expected inner gzip layer')
        with gzip.GzipFile(fileobj=outer,mode='rb') as inner:
            if inner.read(2)!=b'X\n':raise ValueError('expected R XDR header')
            parser=StreamingXDR(inner,cache);parsed=parser.parse_all();parser.check_complete()
            report['rds_uncompressed_bytes']=inner.tell()
        if outer.read(1)!=b'':raise ValueError('unexpected data after inner gzip member')
        report['inner_gzip_bytes']=outer.tell()
    report.update(gzip_layers_eof_crc_pass=True,rds_structural_parse_pass=True,
      native_R_Seurat_validObject_test='not performed; no native R runtime',serialization_versions=vars(parsed.versions),
      root=describe(parsed.object),arrays=parser.arrays)
    save('array_inventory.json',parser.arrays)
    slots=attributes(parsed.object);report['root_slots']={k:describe(v) for k,v in slots.items()}
    print('Both gzip layers and RDS structural EOF checks passed',flush=True)
    assays=named(slots['assays']);report['assays']={k:describe(v) for k,v in assays.items()}
    meta=metadata_frame(slots['meta.data']);meta.to_csv(OUT/'cell_metadata.tsv',sep='\t',index=True,index_label='object_cell_id')
    report['metadata_shape']=list(meta.shape);report['metadata_columns']=list(meta.columns)
    report['metadata_row_id_unique']=bool(meta.index.is_unique)
    summaries={}
    for key in meta.columns:
        if meta[key].nunique(dropna=False)<=60:summaries[key]={str(k):int(v) for k,v in meta[key].value_counts(dropna=False).items()}
    save('metadata_categories.json',summaries)
    matrices={}
    for assay,object_ in assays.items():
        ass=attributes(object_);report['assays'][assay]['slots']={k:describe(v) for k,v in ass.items()}
        for slot in ('counts','data','scale.data'):
            if slot not in ass:continue
            m=ref(ass[slot]);a=attributes(m);key=assay+'.'+slot
            if 'Dim' in a and all(k in a for k in ('i','p','x')):
                shape=[int(x) for x in values(a['Dim'])];names=ref(a['Dimnames']).value
                descriptor={'format':'CSC','shape':shape,'features':values(names[0]),'cells':values(names[1]),
                    **{k:vector_descriptor(a[k],assay+'_'+slot+'_'+k) for k in ('i','p','x')}}
                matrices[key]=descriptor
            elif 'dim' in a:
                matrices[key]={'format':'dense','shape':[int(x) for x in values(a['dim'])]}
    save('matrix_descriptors.json',matrices)
    report['matrices']={k:{x:v for x,v in m.items() if x not in ('features','cells','i','p','x')} for k,m in matrices.items()}
    report['status']='structural_pass_biological_gate_pending';save('object_integrity.json',report)
    print(json.dumps({'status':report['status'],'metadata_shape':report['metadata_shape'],'assays':list(assays),'matrices':report['matrices']},indent=2),flush=True)

if __name__=='__main__':
    cli=argparse.ArgumentParser();cli.add_argument('--source',type=Path,default=SOURCE)
    cli.add_argument('--output',type=Path,default=OUT);cli.add_argument('--expected-sha256',default=EXPECTED)
    args=cli.parse_args();SOURCE=args.source.resolve();OUT=args.output.resolve();EXPECTED=args.expected_sha256
    try:main()
    except Exception as exc:
        if (OUT/'object_integrity.json').exists():
            report=json.loads((OUT/'object_integrity.json').read_text(encoding='utf-8'))
            report.update(status='failed_no_biological_analysis',error=repr(exc));save('object_integrity.json',report)
        raise
