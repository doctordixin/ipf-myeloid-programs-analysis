"""Portable reconstruction of all four prespecified soluble-protein models.
Run with: python replay_comet_bal_extension.py
Inputs and reference tables are relative to this file; no network is needed.
"""
from pathlib import Path
import hashlib,json
import numpy as np,pandas as pd
from scipy import stats,optimize,special
from statsmodels.stats.multitest import multipletests
import statsmodels.api as sm
R=Path(__file__).resolve().parent
P=R/'inputs/41598_2020_67956_MOESM1_ESM.xlsx'
lock=json.loads((R/'inputs/COMET_locked_analysis_plan.json').read_text(encoding='utf-8'))
assert hashlib.sha256(P.read_bytes()).hexdigest()==lock['data_sha256']
ref=pd.read_csv(R/'reference/COMET_model_results.csv')
loo_ref=pd.read_csv(R/'reference/COMET_leave_one_out.csv')
checks=[];rows=[];loo=[]
for sheet in ['BCA Normalized','Nonnormalized']:
    d=pd.read_excel(P,sheet_name=sheet,header=1)
    assert len(d)==51 and d['Subject ID'].is_unique
    y=d['Progressor marked by 1'].to_numpy(float)
    assert set(y)=={0,1} and y.sum()==31
    for anchor,col in [('CCL2','MCP_1'),('CXCL10','IP_10')]:
        v=d[col].to_numpy(float);assert np.isfinite(v).all() and (v>0).all()
        l=np.log2(v);x=(l-l.mean())/l.std(ddof=1)
        X=np.column_stack([np.ones(len(y)),x])
        nll=lambda b:np.sum(np.logaddexp(0,X@b)-y*(X@b))
        grad=lambda b:X.T@(special.expit(X@b)-y)
        b=optimize.minimize(nll,np.zeros(2),jac=grad,method='BFGS',options={'gtol':1e-9}).x
        pr=special.expit(X@b);cov=np.linalg.inv(X.T@((pr*(1-pr))[:,None]*X))
        se=np.sqrt(cov[1,1]);nullb=special.logit(y.mean())
        ll0=np.sum(y*nullb-np.logaddexp(0,nullb))
        LR=2*(-nll(b)-ll0);p=stats.chi2.sf(LR,1)
        result=dict(sheet=sheet,anchor=anchor,n=51,beta=b[1],OR_per_SD_log2=np.exp(b[1]),
            CI95_low=np.exp(b[1]-1.959963984540054*se),CI95_high=np.exp(b[1]+1.959963984540054*se),LR=LR,p_LR=p)
        expect=ref[(ref.sheet==sheet)&(ref.anchor==anchor)].iloc[0]
        for k in ['n','beta','OR_per_SD_log2','CI95_low','CI95_high','LR','p_LR']:
            assert np.isclose(result[k],expect[k],rtol=1e-6,atol=1e-7),(sheet,anchor,k)
            checks.append(dict(sheet=sheet,anchor=anchor,field=k,passed=True))
        fit=sm.Logit(y,X).fit(disp=False)
        quad=sm.Logit(y,np.column_stack([X,x*x])).fit(disp=False)
        qp=stats.chi2.sf(max(0,2*(quad.llf-fit.llf)),1)
        assert np.isclose(qp,expect.quadratic_diagnostic_p,rtol=1e-6,atol=1e-7)
        for i,pid in enumerate(d['Subject ID']):
            keep=np.arange(len(y))!=i
            lf=sm.Logit(y[keep],X[keep]).fit(disp=False,maxiter=100)
            lr=loo_ref[(loo_ref.sheet==sheet)&(loo_ref.anchor==anchor)&(loo_ref.omitted_subject==pid)]
            assert len(lr)==1 and np.isclose(lf.params[1],lr.iloc[0].beta,atol=1e-7)
            checks.append(dict(sheet=sheet,anchor=anchor,field='leave_one_out_'+str(pid),passed=True))
        rows.append(result)
    part=[r for r in rows if r['sheet']==sheet]
    holm=multipletests([r['p_LR'] for r in part]+[1.0],method='holm')[1]
    for r,q in zip(part,holm):
        e=ref[(ref.sheet==sheet)&(ref.anchor==r['anchor'])].iloc[0]
        assert np.isclose(q,e.Holm3,atol=1e-7)
        checks.append(dict(sheet=sheet,anchor=r['anchor'],field='Holm3',passed=True))
assert len(ref)==6 and (ref.status=='not_measured').sum()==2
out=R/'replay_report.json'
out.write_text(json.dumps(dict(passed=True,checks=len(checks),details=checks,
    scope='Two BCA-normalized and two raw-concentration unadjusted logistic models, Holm3, nonlinear diagnostic and all 204 leave-one-out fits reconstructed from the original public workbook. Not mortality validation; not adjusted clinical utility.'),indent=2),encoding='utf-8')
print('COMET replay passed',len(checks),'checks; 4 models, 204 leave-one-out fits; SPP1 unavailable.')
