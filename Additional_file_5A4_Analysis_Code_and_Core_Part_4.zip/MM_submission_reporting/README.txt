Molecular Medicine v13 reporting and package update

Extract all three files 5A, 5B and 5C into THE SAME empty folder, retaining paths.
5A: Core code, remaining extensions, historical results and this guide.
5B: Perturbation_extension (human lung-slice inputs and analysis).
5C: ILD_boundary_extension and Sarcoidosis_BAL_extension.

Each ZIP is complete and can be opened normally; these are not binary split-archive fragments. No new download is needed for the included prepared-input replays. Use the requirements files for the relevant modules in your own environment.

Core numerical replay: python portable_replay.py --output fresh_output
Centre-held-out replay: python Centre_transport_extension/replay.py
Matched-block replay: python Same_core_extension/replay_primary.py

All 611 entries of the v12 archive remain unchanged in content. The new files here only map reference labels and the current reporting index. Historical scripts and reports retain their original reference numbering; use the mapping for v13 manuscript labels. No statistical results or analysis definitions changed. Prepared-input replay does not imply independent clinical or complete raw-object validation. The AI-use disclosure is preserved.
