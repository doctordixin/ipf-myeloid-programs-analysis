IPF myeloid programs numerical replay

Default current entry point: python portable_replay.py --output replay_run
Run from any directory. Use Python 3.11 or newer with requirements_replay.txt.
The output directory must not exist. Execution is offline and does not modify inputs.

Scope: refits the seven-score mortality family using statsmodels Efron PHReg from prepared participant scores; recomputes paired regional summaries; computes GSE252465 scores from the full 49,764-feature macrophage pseudobulk and primary exact tests; checks the GSE166036 full RNA denominator and recomputes the earlier BAL permutation families; checks donor composition and spatial inference. See replay_receipt.json for exact executed checks and tolerances. Cross-engine Cox agreement is numerical verification, not identical-code reproduction. All negative endpoints are retained.

Not an end-to-end raw-data pipeline: raw-cell filtering/integration, all historical sensitivities, download and figure generation are not rerun by the default entry point. Historical scripts are supplied as source records, NOT as verified portable commands. Additional file 4 retains full result tables. Public repository accession identifiers and methods allow retrieval of source matrices; the large RDS and spatial archives are not duplicated here.

Important normalization correction: the historical original_submission_code_UNCHANGED_NOT_CURRENT.zip contains a superseded GSE166036 pathway that selected target rows before computing CPM. Do not execute its analyze_external_bal_disease_state.py as the current workflow. The default entry point explicitly verifies the full 30,727-row denominator first. Old results are version-history evidence, not current positive findings.

Input provenance: inputs/ contains de-identified public participant-level or donor-level derivatives and a public GEO count matrix. They are analytical inputs, not newly collected patient data. expected/ contains previously locked numerical outputs, used for comparisons only; newly calculated results are written separately. Hashes are listed in input_manifest.json. This does not certify genetic independence of donors across studies.

GSE252465 integrity: scoring used the separately retained official-byte repair copy, SHA256 adcadfa52a10622f080f926eb515f43dca9a9cba14459e364de508f8878e0edc. Two mismatched inherited download blocks were replaced with official bytes. Gzip, serialization structure, counts and metadata were checked; native R/Seurat validObject was not run. The damaged download was not scored. Source accession: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE252465

Chronology: the BAL plan was locally locked on 23 October 2026 before scoring; it was not prospectively preregistered. The GSE166036 correction was subsequently performed in a separate directory. Revision was author-authorized on 24 October 2026. Original submissions and old outputs remain archived unchanged.

AI disclosure: OpenAI Codex assisted code development, quality-control planning and manuscript drafting/editing. Authors are responsible for analytical decisions, results, citations and interpretation. Numerical replay is not independent biological validation.

Historical standalone script copies have personal absolute paths normalized to project-relative placeholders. This does not make those historical scripts portable; optional diagnostics helpers and original folder layouts remain historical dependencies. The unchanged original archive is retained separately; hashes and copy changes are recorded in provenance/. The current replay entry point does not use those historical modules.

Execution record: the current default entry point passed 1549 specified checks in the supplied environment. Initial stricter cross-engine Cox P-value comparison differed by at most 5.31124832e-7. Refit HRs agreed within 2e-6 absolute / 2e-5 relative tolerance; P values were compared at 1e-6 absolute / 2e-5 relative tolerance. Original manuscript statistics were not replaced. BAL exact permutation and BH comparisons used 1e-14 absolute tolerance.


NEW ECM EXTENSION
See ECM_extension/README.txt for the separately tested primary replay, optional tested raw-count reconstruction, complete negative results and plotting entry point. The historical1549-check replay scope is unchanged.


NEW ECM EXTENSION
See ECM_extension/README.txt for the separately tested primary replay, optional tested raw-count reconstruction, complete negative results and plotting entry point. The historical1549-check replay scope is unchanged.


NEW ECM EXTENSION
See ECM_extension/README.txt for the separately tested primary replay, optional tested raw-count reconstruction, complete negative results and plotting entry point. The historical1549-check replay scope is unchanged.


NEW ECM EXTENSION
See ECM_extension/README.txt for the separately tested primary replay, optional tested raw-count reconstruction, complete negative results and plotting entry point. The historical1549-check replay scope is unchanged.


v7 later boundary extension: ILD_boundary_extension/README_v7.txt. Run python replay_ild_boundary_extension.py in that directory after installing its requirements.txt. Existing core and prior analysis entries are unchanged.


v8 clinical boundary extension: Sarcoidosis_BAL_extension/README.txt. Run python replay.py there after installing its pinned requirements. Historical entries and results are unchanged.


v9 editorial revision: no changed numerical models/results. See Resource_Admission_v9/README.txt for the GSE286182 failed donor-identity gate and compact record verifier. No new biological validation. Reference mapping is included there for historical provenance.


v10 update: PCLS_descriptive_extension/README.txt describes the newly added post-gate single-donor model description. Historical v9 failed inferential admission records are preserved. Only the descriptive layer was admitted; no independent validation or patient-level test was added. Run the self-contained prepared-count replay.py.


v11: Centre_transport_extension/ and Same_core_extension/ provide scoped portable replays. Original processed-matrix normalization and prior selection limit centre transport; no independent BAL mortality validation is added. Both same-core null results and all sensitivities are retained.
