"""Portable primary-association replay from prepared block scores, not raw nuclei."""
from pathlib import Path
import itertools,json
import numpy as np,pandas as pd
from scipy.stats import rankdata
E=Path(__file__).resolve().parent;I=E/'inputs';O=E/'replay_results';O.mkdir(exist_ok=True)
c=pd.read_csv(I/'all54_core_scores_flow_depth_composition.csv',dtype={'Subject.ID':str});c=c[c.primary_within_IPF].reset_index(drop=True);g=c['Subject.ID'].to_numpy();x=c.CCL2hi.to_numpy()
def resid(a,g):
 _,ix,n=np.unique(g,return_inverse=True,return_counts=True);w=1/n[ix];a=rankdata(a);a=a.copy()
 for d in np.unique(g):a[g==d]-=a[g==d].mean()
 return a,w
def within(a,b,g):
 ar,w=resid(a,g);br,_=resid(b,g);return float(np.sum(w*ar*br)/np.sqrt(np.sum(w*ar**2)*np.sum(w*br**2)))
groups=[np.flatnonzero(g==d) for d in np.unique(g)];allperms=[]
for combo in itertools.product(*[list(itertools.permutations(a)) for a in groups]):
 row=np.arange(len(g))
 for ids,perm in zip(groups,combo):row[ids]=perm
 allperms.append(row)
idx=np.asarray(allperms);assert idx.shape==(31104,19)
rng=np.random.default_rng(2026102801);draws=rng.integers(0,7,size=(10000,7));rows=[]
for ep in ['ECM_structure','ECM_activation_remodeling']:
 y=c[ep].to_numpy();r=within(x,y,g);xr,w=resid(x,g);yr,_=resid(y,g);null=(yr[idx]@(w*xr))/np.sqrt(np.sum(w*xr*xr)*np.sum(w*yr*yr));p=float(np.mean(np.abs(null)>=abs(r)-1e-12));bs=[]
 for draw in draws:
  ix=np.concatenate([groups[z] for z in draw]);gg=np.concatenate([np.full(len(groups[z]),j) for j,z in enumerate(draw)]);bs.append(within(x[ix],y[ix],gg))
 lo,hi=np.quantile(bs,[.025,.975]);rows.append(dict(endpoint=ep,n_donors=7,n_cores=19,weighted_within_donor_rank_r=r,exact_within_donor_permutation_P=p,permutation_labelings=31104,bootstrap_CI95_low=lo,bootstrap_CI95_high=hi))
rows[0]['Holm_P_2']=min(1,2*rows[0]['exact_within_donor_permutation_P']);rows[1]['Holm_P_2']=max(rows[0]['Holm_P_2'],rows[1]['exact_within_donor_permutation_P'])
out=pd.DataFrame(rows);ref=pd.read_csv(I/'primary_results.csv');diff={k:float(np.max(np.abs(out[k]-ref[k]))) for k in ['weighted_within_donor_rank_r','exact_within_donor_permutation_P','Holm_P_2','bootstrap_CI95_low','bootstrap_CI95_high']};assert max(diff.values())<1e-10
out.to_csv(O/'reconstructed_primary_results.csv',index=False);(O/'verification.json').write_text(json.dumps({'maximum_absolute_differences':diff,'prepared_score_replay_only':True,'no_raw_count_reconstruction':True},indent=2),encoding='utf-8');print('SAME CORE PRIMARY REPLAY PASSED',diff)
