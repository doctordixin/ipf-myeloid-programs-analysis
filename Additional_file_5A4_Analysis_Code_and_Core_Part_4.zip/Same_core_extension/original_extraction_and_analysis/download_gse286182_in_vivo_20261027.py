"""Resumable official GEO download. Keep parts; check both gzip layers before admission."""
from pathlib import Path
from datetime import datetime,timezone
import urllib.request,concurrent.futures,threading,time,json,hashlib,gzip,os,io,math,shutil,traceback

R=Path(__file__).resolve().parents[1]
O=R/'data/raw/GSE286182_inVivo_20261027';P=O/'parts';P.mkdir(parents=True,exist_ok=True)
URL='https://ftp.ncbi.nlm.nih.gov/geo/series/GSE286nnn/GSE286182/suppl/GSE286182_SeuratObject.AllNucleiInVivo.rds.gz'
SIZE=17622890066;STEP=16*1024*1024;N=math.ceil(SIZE/STEP)
LOG_LOCK=threading.Lock();STOP=threading.Event()
def now():return datetime.now(timezone.utc).isoformat()
def atomic(n,obj):
 b=json.dumps(obj,ensure_ascii=False,indent=2);tmp=O/(n+f'.{os.getpid()}.tmp')
 for attempt in range(6):
  try:
   tmp.write_text(b,encoding='utf-8');os.replace(tmp,O/n);return
  except PermissionError:
   if attempt==5:raise
   time.sleep(.2*(attempt+1))
def event(**kw):
 with LOG_LOCK:
  with (O/'download_events.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps({'UTC':now(),**kw},ensure_ascii=False)+'\n')
def sizes():return [min(STEP,SIZE-i*STEP) for i in range(N)]
NEEDS=sizes()
def snapshot(state,**extra):
 counts=[(P/f'{i:04d}.part').stat().st_size if (P/f'{i:04d}.part').exists() else 0 for i in range(N)]
 atomic('download_status.json',{'state':state,'UTC':now(),'pid':os.getpid(),'URL':URL,'expected_bytes':SIZE,'bytes_present':sum(counts),'percent':100*sum(counts)/SIZE,'completed_parts':sum(a==b for a,b in zip(counts,NEEDS)),'total_parts':N,'workers':4,'all_existing_parts_preserved':True,'biological_analysis_started':False,**extra})
def chunk(i):
 dst=P/f'{i:04d}.part';start=i*STEP;need=NEEDS[i];end=start+need-1
 if dst.exists() and dst.stat().st_size>need:raise ValueError(f'Oversize part {i}; source retained for inspection')
 if dst.exists() and dst.stat().st_size==need:return i,True
 for attempt in range(9):
  if STOP.is_set():return i,False
  got=dst.stat().st_size if dst.exists() else 0
  if got==need:return i,True
  try:
   if shutil.disk_usage(O).free<15*1024**3:STOP.set();raise RuntimeError('Free disk below 15 GiB floor; retain all breakpoints')
   lo=start+got;req=urllib.request.Request(URL,headers={'Range':f'bytes={lo}-{end}','Accept-Encoding':'identity','User-Agent':'public academic data download'})
   with urllib.request.urlopen(req,timeout=45) as h:
    if h.status!=206 or h.headers.get('Content-Range')!=f'bytes {lo}-{end}/{SIZE}':raise ValueError('Exact HTTP range identity mismatch')
    modified=h.headers.get('Last-Modified')
    if SOURCE_MODIFIED and modified and modified!=SOURCE_MODIFIED:STOP.set();raise RuntimeError('Source Last-Modified changed')
    with dst.open('ab',buffering=0) as f:
     while got<need:
      b=h.read(min(256*1024,need-got))
      if not b:raise EOFError('Unexpected short HTTP body')
      f.write(b);got+=len(b)
   if got==need:
    event(event='part_complete',part=i,bytes=need);return i,True
  except Exception as e:
   event(event='part_retry',part=i,attempt=attempt+1,bytes_preserved=dst.stat().st_size if dst.exists() else 0,error=repr(e))
   if STOP.is_set():break
   time.sleep(min(2**attempt,30))
 return i,False

class PartReader(io.RawIOBase):
 def __init__(self,paths):self.paths=paths;self.k=0;self.h=None;self.position=0;self.digest=hashlib.sha256()
 def readable(self):return True
 def readinto(self,b):
  while self.k<len(self.paths):
   if self.h is None:self.h=self.paths[self.k].open('rb')
   n=self.h.readinto(b)
   if n:self.digest.update(memoryview(b)[:n]);self.position+=n;return n
   self.h.close();self.h=None;self.k+=1
  return 0
 def tell(self):return self.position
 def close(self):
  if self.h:self.h.close()
  super().close()

def verify_gzip_layers():
 paths=[P/f'{i:04d}.part' for i in range(N)];assert all(p.stat().st_size==n for p,n in zip(paths,NEEDS))
 raw=PartReader(paths);serialized=0;last=time.monotonic();snapshot('verifying_two_gzip_layers')
 with io.BufferedReader(raw,4*1024*1024) as buffered,gzip.GzipFile(fileobj=buffered,mode='rb') as outer,gzip.GzipFile(fileobj=outer,mode='rb') as inner:
  assert inner.read(2)==b'X\n';serialized=2
  while b:=inner.read(4*1024*1024):
   serialized+=len(b)
   if time.monotonic()-last>30:snapshot('verifying_two_gzip_layers',serialization_bytes_read=serialized);last=time.monotonic()
  assert outer.read(1)==b'','Trailing bytes after inner gzip'
  assert buffered.read(1)==b'','Trailing bytes after outer gzip'
  digest=raw.digest.hexdigest();compressed=raw.position
 assert compressed==SIZE
 atomic('download_integrity.json',{'UTC':now(),'URL':URL,'compressed_bytes':compressed,'compressed_SHA256':digest,'both_gzip_layers_EOF_CRC_passed':True,'RDS_serialization_bytes':serialized,'part_count':N,'no_duplicate_assembled_file_required':True,'RDS_object_structure_and_biological_gate':'not yet tested','no_manuscript_edits':True})
 snapshot('download_complete_both_gzip_CRC_passed',SHA256=digest,serialization_bytes_read=serialized)

def main():
 global SOURCE_MODIFIED
 lock=O/'download.lock';fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY);os.write(fd,str(os.getpid()).encode());os.close(fd)
 try:
  req=urllib.request.Request(URL,method='HEAD')
  with urllib.request.urlopen(req,timeout=35) as h:
   assert int(h.headers['Content-Length'])==SIZE;SOURCE_MODIFIED=h.headers.get('Last-Modified');headers=dict(h.headers)
  if (O/'source_identity.json').exists():
   previous=json.loads((O/'source_identity.json').read_text(encoding='utf-8'));assert previous['Last-Modified']==SOURCE_MODIFIED
  atomic('source_identity.json',{'URL':URL,'bytes':SIZE,'Last-Modified':SOURCE_MODIFIED,'headers':headers})
  first=P/'0000.part';seed=R/'outputs/GSE286182_same_core_gate_20261027/AllNucleiInVivo_first1MiB.part'
  if not first.exists() and seed.exists():shutil.copyfile(seed,first);event(event='seed_previous_verified_prefix',bytes=seed.stat().st_size)
  event(event='worker_started',pid=os.getpid(),workers=4,parts=N);snapshot('downloading')
  pending=list(range(N))
  for round_no in range(3):
   failed=[]
   with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    futures={pool.submit(chunk,i):i for i in pending}
    while futures:
     done,_=concurrent.futures.wait(futures,timeout=12,return_when=concurrent.futures.FIRST_COMPLETED)
     for f in done:
      i=futures.pop(f)
      try:
       _,ok=f.result()
       if not ok:failed.append(i)
      except Exception as e:failed.append(i);event(event='part_failed',part=i,error=repr(e))
     snapshot('downloading',retry_round=round_no+1,remaining_scheduled_parts=len(futures),deferred_parts=len(failed))
   if not failed:verify_gzip_layers();return
   if STOP.is_set():break
   pending=failed;event(event='retry_deferred_parts',round=round_no+2,parts=failed)
  snapshot('incomplete_all_parts_retained',deferred_parts=pending)
 except Exception as e:
  event(event='download_error',error=repr(e),traceback=traceback.format_exc());snapshot('error_all_parts_retained',error=repr(e));raise
 finally:
  lock.unlink(missing_ok=True)

if __name__=='__main__':main()
