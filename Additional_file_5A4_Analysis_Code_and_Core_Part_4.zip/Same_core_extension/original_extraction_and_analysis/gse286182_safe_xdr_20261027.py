"""Numeric XDR arrays streamed to bounded disk cache; supports R long lengths."""
from pathlib import Path
import struct,hashlib,time,json,io,gzip,tempfile
import numpy as np
from check_bal_rds_gate import StreamingXDR

class SafeXDR(StreamingXDR):
 def __init__(self,stream,cache,cap_bytes=80_000_000_000,threshold=8*1024*1024):
  super().__init__(stream,Path(cache));self.cache.mkdir(parents=True,exist_ok=True);self.cap_bytes=cap_bytes;self.threshold=threshold;self.long_headers=[];self.cache_bytes=0
 def _parse_array(self,dtype):
  length=self.parse_int()
  if length==-1:
   hi,lo=struct.unpack('>II',self.parse_string(8));length=(hi<<32)|lo
   if length<2**31:raise ValueError('Invalid noncanonical R long-vector header')
   self.long_headers.append({'dtype':str(np.dtype(dtype)),'length':length})
  elif length<0:raise ValueError('Invalid negative R numeric vector length')
  return self._parse_array_values(dtype,length)
 def _parse_array_values(self,dtype,length):
  dtype=np.dtype(dtype);wire=dtype.newbyteorder('>');n=length*dtype.itemsize
  if n<self.threshold:return np.frombuffer(self.parse_string(n),dtype=wire).astype(dtype,copy=True)
  if self.cache_bytes+n>self.cap_bytes:raise MemoryError(f'Numeric cache hard cap: {self.cache_bytes+n}>{self.cap_bytes}; all source data preserved')
  self.cache_bytes+=n;path=self.cache/f'array_{len(self.arrays):04d}.bin';h=hashlib.sha256()
  if path.exists():
   if path.stat().st_size!=n:raise ValueError('Partial previous numeric cache retained; inspect before reuse')
   with path.open('rb') as old:
    left=n
    while left:
     b=self.parse_string(min(left,4*1024*1024));assert old.read(len(b))==b,'Cached array differs from source';h.update(b);left-=len(b)
  else:
   with path.open('xb') as out:
    left=n
    while left:
     b=self.parse_string(min(left,4*1024*1024));out.write(b);h.update(b);left-=len(b)
     if time.monotonic()-self.last>25:print(f'XDR numeric cache {self.cache_bytes/1e9:.2f} GB reserved; serialization consumed {self.file.tell()/1e9:.2f} GB',flush=True);self.last=time.monotonic()
  # Cache paths are absolute in this internal engineering receipt, never manuscript content.
  self.arrays.append({'path':str(path.resolve()),'dtype':wire.str,'length':length,'bytes':n,'sha256':h.hexdigest()})
  (self.cache/'numeric_cache_inventory.json').write_text(json.dumps(self.arrays,indent=2),encoding='utf-8')
  return np.memmap(path,dtype=wire,mode='r+',shape=(length,))
 def parse_nullable_int_array(self,*,fill_value=-2147483648):
  data=self._parse_array(np.int32);has_na=False
  for i in range(0,len(data),1024*1024):
   if np.any(data[i:i+1024*1024]==-2147483648):has_na=True;break
  if not has_na:return data
  if len(data)>50_000_000:raise MemoryError('Large NA mask needs a separate bounded strategy; source/cache preserved')
  mask=data==-2147483648;data[mask]=fill_value;return np.ma.array(data,mask=mask,fill_value=fill_value)

def engineering_tests(output):
 import rdata
 output=Path(output);output.mkdir(parents=True,exist_ok=True);tests=[]
 class HeaderOnly(SafeXDR):
  def _parse_array_values(self,dtype,length):return length
 with tempfile.TemporaryDirectory(dir=output) as tmp:
  tmp=Path(tmp)
  p=HeaderOnly(io.BytesIO(struct.pack('>iII',-1,1,7)),tmp);assert p._parse_array(np.float64)==2**32+7;tests.append('long_length_upper_lower_32bits')
  p=HeaderOnly(io.BytesIO(struct.pack('>iII',-1,0,2**31)),tmp);assert p._parse_array(np.int32)==2**31;tests.append('long_length_2power31')
  try:HeaderOnly(io.BytesIO(struct.pack('>i',-2)),tmp)._parse_array(np.int32)
  except ValueError:tests.append('negative_invalid_header_rejected')
  else:raise AssertionError('Invalid length accepted')
  x=np.arange(3000,dtype=np.float64);wire=struct.pack('>i',len(x))+x.astype('>f8').tobytes();p=SafeXDR(io.BytesIO(wire),tmp/'cache',cap_bytes=50000,threshold=1024);y=p._parse_array(np.float64);assert isinstance(y,np.memmap) and np.array_equal(y,x);del y;tests.append('numeric_memmap_matches_values')
  p=SafeXDR(io.BytesIO(wire),tmp/'cap',cap_bytes=100,threshold=1)
  try:p._parse_array(np.float64)
  except MemoryError:assert not list((tmp/'cap').glob('array*'));tests.append('cache_cap_before_allocation')
  else:raise AssertionError('Budget not enforced')
  fixture=tmp/'single.rds';expected={'counts':np.array([0,1,12,3],dtype=np.int32),'x':np.array([.1,.2,3.4])};rdata.write_rds(fixture,expected)
  nested=tmp/'double.rds.gz';nested.write_bytes(gzip.compress(fixture.read_bytes()))
  with nested.open('rb') as raw,gzip.GzipFile(fileobj=raw,mode='rb') as outer,gzip.GzipFile(fileobj=outer,mode='rb') as inner:
   assert inner.read(2)==b'X\n';p=SafeXDR(inner,tmp/'fixture_cache');parsed=p.parse_all();p.check_complete();assert outer.read(1)==b''
  actual=rdata.conversion.convert(parsed);assert np.array_equal(actual['counts'],expected['counts']) and np.array_equal(actual['x'],expected['x']);tests.append('two_layer_gzip_structural_roundtrip')
  # Existing official in-vivo prefix: no numeric allocation needed to read its large header.
  prefix=output.parents[1]/'outputs/GSE286182_same_core_gate_20261027/AllNucleiInVivo_first1MiB.part'
  if prefix.exists():
   a=zlib_decompress_prefix(prefix.read_bytes());p=HeaderOnly(io.BytesIO(a[2:]),tmp)
   # Bound parser stops exactly at the first large numeric array.
   class PrefixStop(SafeXDR):
    def _parse_array_values(self,dtype,length):
     if length>10000:assert length==468482077;raise StopIteration('expected original count-index length')
     return super()._parse_array_values(dtype,length)
   p=PrefixStop(io.BytesIO(a[2:]),tmp/'prefix')
   try:p.parse_all()
   except StopIteration:tests.append('official_in_vivo_prefix_header_reproduced')
  receipt={'engineering_tests_passed':tests,'n_tests':len(tests),'full_in_vivo_object_not_tested':True,'numeric_long_header_supported':'Atomic numeric vectors; not a claim to support every R ALTREP/environment/object type','reference':'https://www.stat.ethz.ch/R-manual/R-devel/doc/manual/R-ints.html','no_biological_models':True}
 (output/'engineering_tests.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8');print(json.dumps(receipt,indent=2))

def zlib_decompress_prefix(b):
 import zlib
 a=zlib.decompressobj(31).decompress(b,4*1024*1024)
 return zlib.decompressobj(31).decompress(a,8*1024*1024)

if __name__=='__main__':engineering_tests(Path(__file__).resolve().parents[1]/'outputs/GSE286182_streaming_preflight_20261027')
