"""Full streaming RDS structural gate only; no expression association models."""
from pathlib import Path
from datetime import datetime,timezone
import io,gzip,json,hashlib,time,sys,traceback
import numpy as np
from gse286182_safe_xdr_20261027 import SafeXDR
from check_bal_rds_gate import attributes,ref,values,named,describe,metadata_frame
from download_gse286182_in_vivo_20261027 import PartReader,P,NEEDS,R
O=R/'outputs/GSE286182_object_gate_20261028';O.mkdir(exist_ok=True)
def dump(n,v):(O/n).write_text(json.dumps(v,ensure_ascii=False,indent=2,default=lambda x:x.item() if isinstance(x,np.generic) else str(x)),encoding='utf-8')
def descriptor(o,key):
 a=attributes(o)
 if 'Dim' not in a or not all(k in a for k in ['i','p','x']):return {'format':'other','description':describe(o)}
 dn=ref(a['Dimnames']).value
 d={'format':'CSC','shape':[int(x) for x in values(a['Dim'])],'features':values(dn[0]),'cells':values(dn[1])}
 for k in ['i','p','x']:
  v=values(a[k])
  if isinstance(v,np.memmap):d[k]={'path':str(Path(v.filename).relative_to(R)),'dtype':v.dtype.str,'length':len(v)}
  else:
   f=O/'arrays'/f'{key.replace(".","_")}_{k}.npy';np.save(f,v);d[k]={'path':str(f.relative_to(R)),'dtype':v.dtype.str,'length':len(v),'npy':True}
 return d
def main():
 integrity=json.loads((P.parent/'download_integrity.json').read_text(encoding='utf-8'));assert integrity['both_gzip_layers_EOF_CRC_passed']
 paths=[P/f'{i:04d}.part' for i in range(len(NEEDS))];assert all(p.stat().st_size==n for p,n in zip(paths,NEEDS))
 report={'started_UTC':datetime.now(timezone.utc).isoformat(),'state':'parsing_disk_backed','source_integrity':integrity,'no_manuscript_edits':True,'biological_association_models':0};dump('object_parse_status.json',report)
 with io.BufferedReader(PartReader(paths),4*1024*1024) as source,gzip.GzipFile(fileobj=source,mode='rb') as outer,gzip.GzipFile(fileobj=outer,mode='rb') as inner:
  assert inner.read(2)==b'X\n';parser=SafeXDR(inner,O/'arrays');parsed=parser.parse_all();parser.check_complete();assert outer.read(1)==b'';assert source.read(1)==b''
  assert source.raw.digest.hexdigest()==integrity['compressed_SHA256']
 slots=attributes(parsed.object);assays=named(slots['assays']);print('PARSED RNA/object assays',list(assays),flush=True)
 meta=metadata_frame(slots['meta.data']);meta.to_csv(O/'cell_metadata.tsv',sep='\t',index=True,index_label='object_cell_id')
 mats={}
 for an,ao in assays.items():
  aa=attributes(ao)
  for slot in ['counts','data','scale.data']:
   if slot in aa:mats[an+'.'+slot]=descriptor(ref(aa[slot]),an+'.'+slot)
 dump('matrix_descriptors.json',mats)
 cats={c:{str(k):int(v) for k,v in meta[c].value_counts(dropna=False).items()} for c in meta.columns if meta[c].nunique(dropna=False)<=100}
 dump('metadata_categories.json',cats)
 report.update(state='structure_pass_expression_gate_pending',completed_UTC=datetime.now(timezone.utc).isoformat(),assays=list(assays),root=describe(parsed.object),metadata_shape=list(meta.shape),metadata_columns=list(meta.columns),metadata_index_unique=bool(meta.index.is_unique),matrices={k:{'format':v['format'],'shape':v.get('shape')} for k,v in mats.items()},numeric_cache_bytes=parser.cache_bytes,long_headers=parser.long_headers,both_gzip_crc_rechecked=True,whole_compressed_SHA256_rechecked=True)
 dump('object_parse_status.json',report);print(json.dumps(report,ensure_ascii=False,default=str),flush=True)
if __name__=='__main__':
 try:main()
 except Exception as e:
  dump('object_parse_failure.json',{'error':repr(e),'traceback':traceback.format_exc(),'all_source_and_cache_retained':True,'no_association_fit':True});raise
