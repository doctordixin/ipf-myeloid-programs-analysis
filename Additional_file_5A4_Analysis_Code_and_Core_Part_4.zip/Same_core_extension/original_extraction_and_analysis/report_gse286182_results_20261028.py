"""Deliver QC and all exploratory null/reverse findings; never modify manuscript."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,shutil,zipfile
import pandas as pd
import numpy as np
R=Path(__file__).resolve().parents[1];A=R/'outputs/GSE286182_same_core_analysis_20261028';Q=R/'outputs/GSE286182_RNA_admission_20261028';G=R/'outputs/GSE286182_object_gate_20261028';O=R/'outputs/GSE286182_Complete_Admission_and_Exploratory_20261028';O.mkdir(exist_ok=True)
for name,source in [('Analysis',A),('RNA_QC',Q),('Object_structure',G)]:
 dst=O/name;dst.mkdir(exist_ok=True)
 for p in source.iterdir():
  if p.is_file() and p.suffix in ['.json','.csv','.npz'] and p.name not in ['matrix_descriptors.json','selected_gene_order.json']:
   shutil.copy2(p,dst/p.name)
 # Full donor-cell metadata, count arrays and sparse descriptors stay local; not duplicated in report archive.
code=O/'Code';code.mkdir(exist_ok=True)
for n in ['parse_gse286182_in_vivo_20261028.py','qc_gse286182_in_vivo_20261028.py','analyze_gse286182_same_core_20261028.py','verify_gse286182_same_core_20261028.py','report_gse286182_results_20261028.py','gse286182_safe_xdr_20261027.py','download_gse286182_in_vivo_20261027.py','check_bal_rds_gate.py']:shutil.copy2(R/'work'/n,code/n)
result=pd.read_csv(A/'primary_results.csv');core=pd.read_csv(A/'all54_core_scores_flow_depth_composition.csv',dtype={'Subject.ID':str});q=core[core.primary_within_IPF].reset_index(drop=True)
from scipy.stats import rankdata
import matplotlib;matplotlib.use('Agg');import matplotlib.pyplot as plt
fig,axes=plt.subplots(1,3,figsize=(12,3.7),layout='constrained');x=rankdata(q.CCL2hi.to_numpy());xx=x.copy()
for d,ids in q.groupby('Subject.ID').groups.items():xx[ids]-=x[ids].mean()
for ax,ep,title in zip(axes[:2],['ECM_structure','ECM_activation_remodeling'],['ECM structure','ECM activation / remodeling']):
 y=rankdata(q[ep].to_numpy());yy=y.copy()
 for d,ids in q.groupby('Subject.ID').groups.items():yy[ids]-=y[ids].mean()
 for j,(d,ids) in enumerate(q.groupby('Subject.ID').groups.items()):ax.scatter(xx[ids],yy[ids],label=d,color=plt.get_cmap('tab10')(j),s=28)
 ax.axhline(0,lw=.6,color='#bbbbbb');ax.axvline(0,lw=.6,color='#bbbbbb');ax.set_xlabel('Within-donor CCL2hi rank deviation');ax.set_ylabel('Within-donor ECM rank deviation');ax.set_title(title)
v=result.weighted_within_donor_rank_r.to_numpy();lo=result.bootstrap_CI95_low.to_numpy();hi=result.bootstrap_CI95_high.to_numpy();axes[2].errorbar(v,[1,0],xerr=np.vstack([v-lo,hi-v]),fmt='o',color='#527b9c',capsize=3);axes[2].set_yticks([1,0],['Structure','Activation /\nremodeling']);axes[2].axvline(0,lw=.8,color='gray');axes[2].set_xlim(-1,1);axes[2].set_xlabel('Weighted within-donor rank r\nDonor bootstrap 95% CI');axes[2].set_title('19 cores from 7 IPF donors')
for ax in axes:ax.spines[['top','right']].set_visible(False)
fig.savefig(O/'Internal_QC_and_null_results.png',dpi=180);plt.close(fig)
report='''GSE286182：完整下载、数据准入及探索性分析完成报告
日期：2026-10-28（Pacific/Apia）

结论先行
完整下载、双层gzip、完整RDS结构、RNA计数及逐组织块配对核查均已通过。因此按新锁定方案完成了作者肺泡巨噬细胞亚型内、同供者/同组织块的探索性ECM共变分析。
结果没有支持预期的正向关联：ECM结构相关方向为负但校正后不显著，ECM激活/重塑相关接近零且敏感性不稳定。不能宣称新强阳性、CCL2hi保护效应或机制独立复现。原稿未修改。

1. 下载与完整性
官方文件17,622,890,066字节（约17.62GB），1051个断点分块全部正确，完整日志无超时/重试失败/拒绝访问事件。
内外gzip两层CRC/EOF通过；实际RDS序列化流32,009,360,516字节（约32.01GB）。完整流再次重读并核对压缩SHA256一致：
c2b4d629f39705f7492e48aedaff55a09e2010289e1943f17932e2ab37e56f59
原分块保留；没有另复制17.62GB合并文件。数值磁盘缓存约31.71GB，低于80GB缓存硬上限。

2. 原始RNA及元数据核查
确认Seurat对象的RNA与integrated两套assay。本分析只用RNA.counts，未用整合或归一化矩阵作为原始计数。
RNA.counts为60,651特征×514,988列的CSC矩阵，468,482,077个稀疏条目；全部有限、非负、整数样，最大单基因计数9605，无存储零值。i/p/x长度、行索引范围及每列严格排序通过。
RNA条码与完整作者元数据逐一对应，无重复条码；按全部RNA特征重算每列UMI及检出基因数，与作者nCount_RNA/nFeature_RNA均0处不一致；没有零RNA分母细胞。
514,988列仍是对象中的细胞核记录，不是独立患者数。

3. 逐块及亚型数量
19名供者、54个组织块；作者Sample.ID、Library.Ident、Subject.ID、诊断和microCT surface density已逐块连接并一致。
作者标签包括MacAlveolar、MacProfibrotic、Mac，以及4类成纤维细胞。选择MacAlveolar做亚型内检验，广义成纤维池仅含Fibroblast_Alveolar、Fibroblast_Adventitial、Fibroblast_Fibrotic、Fibroblast_Airway。
至少50个MacAlveolar及50个广义成纤维细胞：IPF21块/9人，对照30块/10人。
供者内分析要求至少2块合格、microCT不同的组织块：IPF7人/19块；对照10人/30块。7名IPF供者为120、127、190、204、319、323、325。
120_21、224_48、323_37分别只有40、2、22个MacAlveolar，不降低50阈值。224和253各仅剩1块合格组织，故只退出供者内估计，仍保留流程和全部数据。
主分析19块实际MacAlveolar为124–675个、广义成纤维376–2720个。100细胞阈值与50阈值的主分析支持相同；200阈值只剩5人/13块，不能算新增独立验证。

4. 固定基因覆盖
CCL2hi20/20基因在RNA目录中且在MacAlveolar群中全部检出；原6基因ECM结构和7基因ECM激活/重塑均全部覆盖、检出。
其余六状态目录及实际检出情况也完整保存：目录缺失与真实零值分开。没有替换基因、用CCL2hi分数定义亚型或根据相关性选择接收端。

5. 预锁定的探索性设计
使用7名IPF供者19块，按同块分别汇总MacAlveolar及成纤维RNA，完整RNA分母log1pCPM；冻结原20基因及既有ECM指标。
每名供者的总权重相等，供者内组织块等权；计算排除供者固定效应后的加权秩相关。供者是生物学重复，不把19块当19名患者。
两个预定端点进行Holm校正；枚举31,104种供者内接收端标签排列，双侧P值。条件可交换性是观察性检验假设，不是随机试验因果推断。
整供者bootstrap10000次，固定分数校准、重算秩，给出探索性百分位95%CI。只有7名供者，区间覆盖能力有限。
这是已知既往队列结果之后的回顾性预锁定，不是前瞻性注册。计划、输入SHA256及全部检验和敏感性均保存。

6. 主要结果
CCL2hi—ECM结构：r=-0.530988，原始精确P=0.085102，Holm校正P=0.170203；供者bootstrap95%CI为-0.841670至+0.185286。
CCL2hi—ECM激活/重塑：r=+0.047042，原始精确P=0.904835，Holm校正P=0.904835；95%CI为-0.708435至+0.588881。
两个置信区间均跨零，没有校正后正向阳性。结构指标的负方向也不能解释为保护作用或抑制ECM机制。

7. 全部敏感性：阴性、反向、不稳定均保留
逐一剔除7名供者：结构r范围-0.650837至-0.379026，激活/重塑-0.338591至+0.183259。后者方向不稳定。
深度校正：结构-0.503684，激活/重塑+0.229472。
microCT背景校正：结构-0.530714，激活/重塑+0.053079。
联合microCT和两池深度：结构-0.504030，激活/重塑+0.249588。
按成纤维亚型比例校正：结构-0.414346，激活/重塑-0.030428；按巨噬细胞RNA贡献比例校正亦完整保留。
改为肺泡成纤维接收端：结构-0.379243，激活/重塑+0.051260。
改为广义巨噬细胞发送端：结构-0.230597，激活/重塑+0.250040。
200细胞阈值：结构-0.688108，激活/重塑-0.476913，仅5人，方向/幅度受支持集变化影响，不独立提出新发现。
逐一剔除20个CCL2hi基因：结构-0.675276至-0.427541；激活/重塑-0.058991至+0.150181。
每池等50细胞抽样200次：结构r中位数-0.438157，处理分布2.5%–97.5%为-0.761779至-0.014750，4/200次为正；激活/重塑中位数+0.157845，分布跨零。
完整RNA分子总量统一200次：结构中位数-0.473713，处理分布-0.644112至-0.223310，200次均为负；激活/重塑中位数-0.036035，分布跨零。
抽样重复不是新供者，处理分布不是生物学95%CI，不能用它替代主分析的非显著结论。
对照供者内系数为结构+0.476729、激活/重塑+0.519484；它们仅作适用边界描述，没有做诊断交互验证，不能因此宣称疾病特异性改变。

8. 对文章的含义
可保留为重要的适用边界：同块配对和作者亚型内分析可行，但未支持一个普遍稳定的“CCL2hi上升—成纤维ECM上升”关系。
SCP2879此前的跨供者、广义巨噬细胞结果，与本轮IPF供者内、肺泡巨噬细胞结果估计对象不同；本轮不能称为相同关系的复制，也不能用反向结果直接断言原阳性一定错误。
GSE135893未复现和SCP2879组成敏感性仍应保留。更适合收紧机制措辞，而非继续换细胞、换通路或阈值寻找阳性。
作者注释的循环性未完全排除；microCT只是同块病理背景，测序与H&E为连续薄片，没有细胞级空间定位。本轮ECM是表达共变，不是已证实的CCL2/TGF-beta接收端响应。
没有独立BAL死亡结局验证，不应宣称文章档次明显跃升。

9. 独立验证与文件完整性
主要加权相关经statsmodels WLS独立实现核验；另用逐供者交叉积独立重建每端点全部31,104个零分布，精确P值一致。
原基线305个文件SHA256未变；没有修改稿件、旧投稿包或既有结果。
代码、输入指纹、全体54块分数/流程、14条供者剔除、40条基因剔除、20条确定性敏感性、800条处理抽样系数以及全部对应核心分数已保留。
所有17.62GB源分块、完整RNA稀疏缓存、细胞元数据及目标计数另留本地，不在小型报告包中重复压缩。Code目录供审计；工作区work内同名脚本为实际执行入口，需相应已下载输入及Python依赖。

公开来源
GEO：https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE286182
原始研究：https://pubmed.ncbi.nlm.nih.gov/40667263/
UNAGI正式论文：https://doi.org/10.1038/s41551-025-01423-7
'''
(O/'完整核查与探索性结果说明.txt').write_text(report,encoding='utf-8')
status={'date_Pacific_Apia':'2026-10-28','download':'complete','gzip_and_RDS_structure':'passed','RNA_counts_and_barcode_core_QC':'passed','exploratory_author_subtype_analysis':'completed','strong_positive_validation':False,'primary_results':result.to_dict(orient='records'),'no_manuscript_edits':True,'not_causal_or_mortality_validation':True}
(O/'completion_summary.json').write_text(json.dumps(status,ensure_ascii=False,indent=2),encoding='utf-8')
files=[p for p in O.rglob('*') if p.is_file() and p.name!='artifact_sha256.json'];manifest={str(p.relative_to(O)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files};(O/'artifact_sha256.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
with zipfile.ZipFile(R/'outputs/GSE286182_Complete_Admission_and_Exploratory_20261028.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in files+[O/'artifact_sha256.json']:z.write(p,str(p.relative_to(O)))
print('Complete audit/results package:',len(files),'files; manuscript unchanged')
