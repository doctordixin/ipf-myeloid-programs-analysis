"""Locked, exploratory matched-core CCL2hi/ECM analysis; independent replicate = donor."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,itertools,sys
import numpy as np
import pandas as pd
from scipy.stats import rankdata,spearmanr
R=Path(__file__).resolve().parents[1];Q=R/'outputs/GSE286182_RNA_admission_20261028';O=R/'outputs/GSE286182_same_core_analysis_20261028'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(n,v):(O/n).write_text(json.dumps(v,ensure_ascii=False,indent=2,default=lambda x:x.item() if isinstance(x,np.generic) else str(x)),encoding='utf-8')
def lock():
 assert not O.exists();O.mkdir()
 files=[Q/n for n in ['RNA_admission_decision.json','selected_cells_fixed_gene_counts.npy','selected_cells_metadata.csv.gz','selected_gene_order.json','core_author_subtype_counts.csv']]+[R/'data/derived/mlm_six_state_signatures_frozen.json',R/'outputs/mac_fib_feasibility_20261024/candidate_panels_feasibility_only.json',Path(__file__)]
 spec={'UTC':datetime.now(timezone.utc).isoformat(),'study':'Retrospective exploratory after known SCP2879/GSE135893 results and RNA QC; not prospective preregistration','question':'Within author MacAlveolar, does fixed CCL2hi co-vary with same-core fibroblast ECM expression within IPF donors? Not ligand-specific signalling','primary_cohort':'IPF cores >=50 MacAlveolar and >=50 broad fibroblasts; only donors with >=2 eligible cores and >=2 surface density values. QC yields7donors/19cores; 2 single-eligible-core donors excluded from within-donor estimation only, retained in flow','primary_endpoints':['CCL2hi versus ECM_structure','CCL2hi versus ECM_activation_remodeling'],'genes':'Original frozen20 CCL2hi; existing6gene structure and7gene activation/remodeling; no replacements or new pathways','normalization':'Donor-core/pool raw RNA sums divided by complete RNA totals; log1p CPM. Each donor equal total calibration weight, each core within donor equal. Fixed weighted gene mean/SD then mean gene z then module z across primary19cores; zero-SD genes retained as zero-information z=0 and named. Require >=16 informative CCL2hi genes','statistic':'Rank each core score globally within current analysis set using average ties; weighted residuals after donor fixed effects, weights1/n_cores_per_donor; correlate weighted residuals. Biological unit donor, no cell-level or naive core-level independent test','P':'Exact two-sided within-donor permutation of receiver core labels, enumerate full permutation product (expected31104); assume conditional core exchangeability under null, not randomized causal inference','multiplicity':'Holm across exactly2primary tests','CI':'10000 whole-donor bootstrap draws, seed2026102801, resample7donor blocks with replacement, retain all cores and label each selected block separately; fixed score calibration, rerank in each draw. Percentile95%CI, few clusters limit coverage; report nonfinite draws','sensitivities':['leave each of7donors out, coefficient only','add rank RNA-depth covariates (median RNA per cell, macrophage and fibroblast)','add rank microCT density; jointly add density and RNA depths','adjust for author Fibroblast_Fibrotic cell proportion, descriptive circularity/composition caveat','alveolar fibroblast recipient instead of broad pool, primary fixed gene calibration','broad macrophage sender instead of MacAlveolar, primary fixed gene calibration','>=100 cells (same support) and >=200 cells (5 multi-core donors); coefficients only','leave each20CCL2hi genes out with fixed gene/module calibration, no replacement','equal50cells per sender/receiver core, 200draws seed2026102802; no biological CI claim','RNA molecule rarefaction to primary minimum full RNA total in each pool separately, 200draws seed2026102803; exact multivariate hypergeometric on unique genes plus remaining RNA, no biological CI claim','same within-donor coefficient in controls separately, descriptive boundary; no pooled IPF/control discovery'],'no_significance_search':'Keep null, reverse, nonfinite and unstable outputs; do not change labels/thresholds/endpoints to obtain a positive result','limits':'Author labels not target-gene-excluded validation; microCT same-core background not cell-level spatial localization; no new TGF-beta response-footprint use; no mortality endpoint','bindings':[{'file':str(p.relative_to(R)),'sha256':sha(p)} for p in files],'no_manuscript_edits':True}
 dump('analysis_plan_locked_before_associations.json',spec);print('Locked',sha(O/'analysis_plan_locked_before_associations.json'))

def weights(g):
 _,inv,n=np.unique(g,return_inverse=True,return_counts=True);return 1/n[inv]
def residuals(v,g,cov=None):
 labels=np.unique(g);D=np.column_stack([np.asarray(g)==d for d in labels]).astype(float)
 if cov is not None:D=np.column_stack([D]+[rankdata(c) for c in cov])
 w=weights(g);Z=D*np.sqrt(w[:,None]);rank=np.linalg.matrix_rank(Z)
 if rank<D.shape[1]:return None,w
 return v-D@np.linalg.lstsq(Z,v*np.sqrt(w),rcond=None)[0],w
def within(a,b,g,cov=None):
 a=np.asarray(a,float);b=np.asarray(b,float);g=np.asarray(g)
 if len(np.unique(g))<2 or not np.isfinite(a).all() or not np.isfinite(b).all():return np.nan
 ra,w=residuals(rankdata(a),g,cov);rb,_=residuals(rankdata(b),g,cov)
 if ra is None or rb is None:return np.nan
 den=np.sqrt(np.sum(w*ra**2)*np.sum(w*rb**2));return float(np.sum(w*ra*rb)/den) if den>1e-12 else np.nan
def calibrate(logs,weights_,cal=None):
 w=weights_/weights_.sum()
 if cal is None:
  mu=w@logs;sd=np.sqrt(w@((logs-mu)**2)/(1-np.sum(w*w)));active=sd>1e-12;safe=np.where(active,sd,1.)
 else:mu=np.array(cal['mean']);safe=np.array(cal['SD']);active=np.array(cal['informative'])
 z=(logs-mu)/safe;z[:,~active]=0.;v=z.mean(axis=1)
 if cal is None:mm=float(w@v);ms=float(np.sqrt(w@((v-mm)**2)/(1-np.sum(w*w))))
 else:mm=cal['module_mean'];ms=cal['module_SD']
 assert ms>1e-12
 return (v-mm)/ms,{'mean':mu.tolist(),'SD':safe.tolist(),'informative':active.tolist(),'module_mean':mm,'module_SD':ms},z

def run():
 plan=json.loads((O/'analysis_plan_locked_before_associations.json').read_text(encoding='utf-8'))
 for x in plan['bindings']:assert sha(R/x['file'])==x['sha256']
 assert not (O/'primary_results.csv').exists()
 meta=pd.read_csv(Q/'selected_cells_metadata.csv.gz',dtype={'Subject.ID':str,'core_key':str});counts=np.load(Q/'selected_cells_fixed_gene_counts.npy',mmap_mode='r',allow_pickle=False);genes=json.loads((Q/'selected_gene_order.json').read_text(encoding='utf-8'))
 states=json.loads((R/'data/derived/mlm_six_state_signatures_frozen.json').read_text(encoding='utf-8'))['states'];panels=json.loads((R/'outputs/mac_fib_feasibility_20261024/candidate_panels_feasibility_only.json').read_text(encoding='utf-8'))['panels'];mods={'CCL2hi':states['CCL2hi'],**{k:panels[k] for k in ['ECM_structure','ECM_activation_remodeling']}}
 fib=['Fibroblast_Alveolar','Fibroblast_Adventitial','Fibroblast_Fibrotic','Fibroblast_Airway'];mac=['MacAlveolar','MacProfibrotic','Mac']
 core=pd.read_csv(Q/'core_author_subtype_counts.csv',dtype={'Subject.ID':str});core=core.sort_values(['Subject.ID','core_key']).reset_index(drop=True)
 dat={k:[] for k in ['MacAlveolar','broad_fibroblasts','Fibroblast_Alveolar','broad_macrophages']};index={k:[] for k in dat};depth={k:[] for k in dat};rna={k:[] for k in dat}
 for ck in core.core_key:
  iscore=meta.core_key.eq(ck).to_numpy()
  for k,labels in [('MacAlveolar',['MacAlveolar']),('broad_fibroblasts',fib),('Fibroblast_Alveolar',['Fibroblast_Alveolar']),('broad_macrophages',mac)]:
   ix=np.flatnonzero(iscore&meta.renamedFinal.isin(labels).to_numpy());index[k].append(ix);dat[k].append(np.asarray(counts[ix]).sum(axis=0));u=meta.iloc[ix].RNA_UMI_recomputed.to_numpy();rna[k].append(int(u.sum()));depth[k].append(float(np.median(u)) if len(u) else np.nan)
 for k in dat:dat[k]=np.asarray(dat[k]);rna[k]=np.array(rna[k]);depth[k]=np.array(depth[k])
 eligible=(core['Disease.Ident'].eq('IPF')&(core.MacAlveolar>=50)&(core.broad_fibroblasts>=50)).to_numpy();eligible_donor_counts=core.loc[eligible].groupby('Subject.ID').size();keepdonors=eligible_donor_counts[eligible_donor_counts>=2].index
 primary=eligible&core['Subject.ID'].isin(keepdonors).to_numpy();ix=np.flatnonzero(primary);g=core.loc[primary,'Subject.ID'].to_numpy();assert len(ix)==19 and len(np.unique(g))==7
 core['eligible_50']=eligible;core['primary_within_IPF']=primary;w=weights(g);cal={};scores={};genez={};gene_qc=[]
 for name,gs in mods.items():
  assert all(a in genes for a in gs);pool='MacAlveolar' if name=='CCL2hi' else 'broad_fibroblasts';jj=[genes.index(a) for a in gs];logs=np.log1p(dat[pool][:,jj]/rna[pool][:,None]*1e6)
  _,cal[name],_=calibrate(logs[primary],w);scores[name],_,genez[name]=calibrate(logs,np.ones(len(core)),cal[name]);cal[name]['genes']=gs
  for j,a in enumerate(gs):gene_qc.append({'program':name,'gene':a,'primary_cores_nonzero':int((dat[pool][primary,jj[j]]>0).sum()),'primary_gene_informative':cal[name]['informative'][j]})
 assert sum(cal['CCL2hi']['informative'])>=16
 pd.DataFrame(gene_qc).to_csv(O/'locked_gene_variance_diagnostics.csv',index=False);dump('fixed_score_calibration.json',cal)
 for k,v in scores.items():core[k]=v
 for k in dat:core[k+'_full_RNA']=rna[k];core[k+'_median_cell_RNA']=depth[k]
 core['fibrotic_fibroblast_fraction']=core.Fibroblast_Fibrotic/core.broad_fibroblasts;core['alveolar_mac_cell_fraction']=core.MacAlveolar/core.broad_macrophages;core['alveolar_mac_RNA_fraction']=rna['MacAlveolar']/rna['broad_macrophages']
 core.to_csv(O/'all54_core_scores_flow_depth_composition.csv',index=False)
 # Validate WLS residual implementation against explicit donor-centering in the no-covariate case.
 a=rankdata(scores['CCL2hi'][primary]);ar,_=residuals(a,g);direct=a.copy()
 for d in np.unique(g):direct[g==d]-=a[g==d].mean()
 assert np.allclose(ar,direct)
 # Pre-interpretation diagnostics, no removal based on scores/outliers.
 sys.path.insert(0,str(Path.home()/'.codex/skills/statistical-analysis/scripts'));from assumption_checks import detect_outliers
 diagnostics=[]
 for name,v in scores.items():
  o=detect_outliers(v[primary],name=name,plot=False);diagnostics.append({'score':name,'n_cores':19,'n_donors':7,'IQR_flags':int(o['n_outliers']),'none_removed':True})
 dump('assumption_diagnostics.json',{'outliers':diagnostics,'within_donor_exchangeability':'Assumption for permutation, not verified by observational design; microCT/depth adjustment sensitivity reported','bootstrap_limit':'Only7donors; percentileCI is exploratory','RNA_counts_author_match':'QC reports all cell totals/features matched','no_cell_level_inference':True})
 groups=[np.flatnonzero(g==d) for d in np.unique(g)];perms=[list(itertools.permutations(a)) for a in groups];perm_ix=[]
 for combo in itertools.product(*perms):
  row=np.arange(len(g))
  for ids,pp in zip(groups,combo):row[ids]=pp
  perm_ix.append(row)
 perm_ix=np.asarray(perm_ix);assert len(perm_ix)==31104
 result=[];bootstrap={};null={};rng=np.random.default_rng(2026102801);draws=rng.integers(0,len(groups),size=(10000,len(groups)))
 for endpoint in ['ECM_structure','ECM_activation_remodeling']:
  y=scores[endpoint][primary];x=scores['CCL2hi'][primary];r=within(x,y,g);xr,ww=residuals(rankdata(x),g);yr,_=residuals(rankdata(y),g);dist=(yr[perm_ix]@(ww*xr))/np.sqrt(np.sum(ww*xr*xr)*np.sum(ww*yr*yr));p=float(np.mean(np.abs(dist)>=abs(r)-1e-12));null[endpoint]=dist
  bs=[]
  for draw in draws:
   ids=np.concatenate([groups[z] for z in draw]);gg=np.concatenate([np.full(len(groups[z]),k) for k,z in enumerate(draw)]);bs.append(within(x[ids],y[ids],gg))
  bs=np.asarray(bs);bootstrap[endpoint]=bs;finite=bs[np.isfinite(bs)];lo,hi=np.quantile(finite,[.025,.975]) if len(finite) else (np.nan,np.nan)
  result.append({'endpoint':endpoint,'n_donors':7,'n_cores':19,'weighted_within_donor_rank_r':r,'exact_within_donor_permutation_P':p,'permutation_labelings':len(dist),'bootstrap_CI95_low':lo,'bootstrap_CI95_high':hi,'bootstrap_finite':len(finite),'bootstrap_draws':len(bs)})
  print('PRIMARY computed',endpoint,flush=True)
 pp=np.array([v['exact_within_donor_permutation_P'] for v in result]);order=np.argsort(pp);adjusted=np.maximum.accumulate(pp[order]*np.array([2,1]));holm=np.empty(2);holm[order]=np.minimum(adjusted,1)
 for j,v in enumerate(result):v['Holm_P_2']=holm[j]
 pd.DataFrame(result).to_csv(O/'primary_results.csv',index=False);np.savez_compressed(O/'primary_null_and_donor_bootstrap.npz',**{k+'_null':v for k,v in null.items()},**{k+'_bootstrap':v for k,v in bootstrap.items()})
 # Descriptive sensitivities, never selected by nominal P.
 sens=[];loo=[];geneout=[]
 def record(label,x,y,gg,endpoint,cov=None):sens.append({'sensitivity':label,'endpoint':endpoint,'n_donors':len(np.unique(gg)),'n_cores':len(gg),'r':within(x,y,gg,cov),'descriptive_no_extra_discovery_P':True})
 dep=[np.log(depth['MacAlveolar'][primary]),np.log(depth['broad_fibroblasts'][primary])];density=core.Surface_Density_min.to_numpy()[primary]
 for endpoint,gs in list(mods.items())[1:]:
  xx=scores['CCL2hi'][primary];yy=scores[endpoint][primary]
  for d in np.unique(g):
   keep=g!=d;loo.append({'omitted_donor':d,'endpoint':endpoint,'n_donors':6,'n_cores':int(keep.sum()),'r':within(xx[keep],yy[keep],g[keep])})
  for label,cv in [('RNA_depth_adjusted',dep),('microCT_adjusted',[density]),('microCT_and_RNA_depth_adjusted',[density]+dep),('fibroblast_subtype_composition_adjusted',[core.fibrotic_fibroblast_fraction.to_numpy()[primary]]),('macrophage_RNA_share_adjusted',[core.alveolar_mac_RNA_fraction.to_numpy()[primary]])]:record(label,xx,yy,g,endpoint,cv)
  for threshold in [100,200]:
   keep=primary&(core.MacAlveolar>=threshold)&(core.broad_fibroblasts>=threshold);ds=core.loc[keep].groupby('Subject.ID').size();keep&=core['Subject.ID'].isin(ds[ds>=2].index).to_numpy();record(f'minimum_{threshold}_cells',scores['CCL2hi'][keep],scores[endpoint][keep],core.loc[keep,'Subject.ID'].to_numpy(),endpoint)
  jj=[genes.index(a) for a in gs];logs=np.log1p(dat['Fibroblast_Alveolar'][:,jj]/rna['Fibroblast_Alveolar'][:,None]*1e6);alternative,_,_=calibrate(logs,np.ones(len(core)),cal[endpoint]);record('alveolar_fibroblast_receiver',xx,alternative[primary],g,endpoint)
  jj=[genes.index(a) for a in mods['CCL2hi']];logs=np.log1p(dat['broad_macrophages'][:,jj]/rna['broad_macrophages'][:,None]*1e6);alternative,_,_=calibrate(logs,np.ones(len(core)),cal['CCL2hi']);record('broad_macrophage_sender',alternative[primary],yy,g,endpoint)
  ctrl=(core['Disease.Ident'].eq('Control')&(core.MacAlveolar>=50)&(core.broad_fibroblasts>=50)).to_numpy();record('control_within_donor_boundary',scores['CCL2hi'][ctrl],scores[endpoint][ctrl],core.loc[ctrl,'Subject.ID'].to_numpy(),endpoint)
  for j,a in enumerate(mods['CCL2hi']):
   z=np.delete(genez['CCL2hi'][primary],j,axis=1).mean(axis=1);z=(z-cal['CCL2hi']['module_mean'])/cal['CCL2hi']['module_SD'];geneout.append({'omitted_gene':a,'endpoint':endpoint,'r':within(z,yy,g)})
 pd.DataFrame(loo).to_csv(O/'leave_one_donor_out_all.csv',index=False);pd.DataFrame(geneout).to_csv(O/'leave_one_gene_out_all.csv',index=False);pd.DataFrame(sens).to_csv(O/'all_deterministic_sensitivities.csv',index=False)
 # Repeated cell/molecule subsampling: processing sensitivity, never biological replication.
 cgenes=mods['CCL2hi'];fgenes=sorted(set(mods['ECM_structure']+mods['ECM_activation_remodeling']));ci=[genes.index(a) for a in cgenes];fi=[genes.index(a) for a in fgenes]
 ctarget=int(rna['MacAlveolar'][primary].min());ftarget=int(rna['broad_fibroblasts'][primary].min());rc=np.random.default_rng(2026102802);rr=np.random.default_rng(2026102803);sampling=[];sampling_scores=[]
 def from_raw(c,u,gs,cal_):return calibrate(np.log1p(np.asarray(c)/np.asarray(u)[:,None]*1e6),np.ones(len(u)),cal_)[0]
 for rep in range(200):
  c=[];cu=[];f=[];fu=[];cr=[];fr=[]
  for j in ix:
   cm=rc.choice(index['MacAlveolar'][j],50,replace=False);fm=rc.choice(index['broad_fibroblasts'][j],50,replace=False);c.append(counts[cm][:,ci].sum(axis=0));cu.append(meta.iloc[cm].RNA_UMI_recomputed.sum());f.append(counts[fm][:,fi].sum(axis=0));fu.append(meta.iloc[fm].RNA_UMI_recomputed.sum())
   cv=dat['MacAlveolar'][j,ci];fv=dat['broad_fibroblasts'][j,fi];cr.append(rr.multivariate_hypergeometric(np.r_[cv,rna['MacAlveolar'][j]-cv.sum()].astype(np.int64),ctarget,method='marginals')[:-1]);fr.append(rr.multivariate_hypergeometric(np.r_[fv,rna['broad_fibroblasts'][j]-fv.sum()].astype(np.int64),ftarget,method='marginals')[:-1])
  for method,cc,uu,ff,vv in [('equal_50_cells',np.asarray(c),np.array(cu),np.asarray(f),np.array(fu)),('equal_RNA_molecules',np.asarray(cr),np.full(len(ix),ctarget),np.asarray(fr),np.full(len(ix),ftarget))]:
   xx=from_raw(cc,uu,cgenes,cal['CCL2hi'])
   for endpoint in ['ECM_structure','ECM_activation_remodeling']:
    jj=[fgenes.index(a) for a in mods[endpoint]];yy=from_raw(ff[:,jj],vv,mods[endpoint],cal[endpoint]);sampling.append({'method':method,'replicate':rep,'endpoint':endpoint,'r':within(xx,yy,g)})
    for j,ck in enumerate(core.core_key[primary]):sampling_scores.append({'method':method,'replicate':rep,'endpoint':endpoint,'core':ck,'CCL2hi':xx[j],'ECM':yy[j]})
  if (rep+1)%50==0:print('sampling',rep+1,flush=True)
 pd.DataFrame(sampling).to_csv(O/'all_sampling_coefficients.csv',index=False);pd.DataFrame(sampling_scores).to_csv(O/'all_sampling_core_scores.csv',index=False)
 summary=[]
 for (method,endpoint),ss in pd.DataFrame(sampling).groupby(['method','endpoint']):
  v=ss.r.to_numpy();summary.append({'method':method,'endpoint':endpoint,'r_median':np.median(v),'r_processing_p025':np.quantile(v,.025),'r_processing_p975':np.quantile(v,.975),'fraction_positive':np.mean(v>0),'not_biological_CI':True})
 pd.DataFrame(summary).to_csv(O/'sampling_processing_summary.csv',index=False)
 dump('analysis_completion.json',{'completed_UTC':datetime.now(timezone.utc).isoformat(),'plan_SHA256':sha(O/'analysis_plan_locked_before_associations.json'),'primary_results':result,'RNA_rarefaction_targets':{'macrophages':ctarget,'fibroblasts':ftarget},'full_sensitivities_preserved':True,'no_manuscript_edits':True,'limits':'Exploratory7-donor within-core ECM co-variation; no causal ligand or spatial colocalization proof; not independent BAL mortality validation'})
 print(json.dumps(result,ensure_ascii=False,default=str),flush=True)
if __name__=='__main__':
 if sys.argv[1]=='lock':lock()
 elif sys.argv[1]=='run':run()
 else:raise ValueError('lock/run')
