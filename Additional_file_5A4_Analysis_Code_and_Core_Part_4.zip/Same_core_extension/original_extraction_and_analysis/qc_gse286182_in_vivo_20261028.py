"""All RNA-count entries, barcode/core mapping and paired-cell capacity; no association."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,time
import numpy as np
import pandas as pd
R=Path(__file__).resolve().parents[1];G=R/'outputs/GSE286182_object_gate_20261028';O=R/'outputs/GSE286182_RNA_admission_20261028';O.mkdir(exist_ok=True)
def dump(n,v):(O/n).write_text(json.dumps(v,ensure_ascii=False,indent=2,default=lambda x:x.item() if isinstance(x,np.generic) else str(x)),encoding='utf-8')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load_array(d):return np.load(R/d['path'],mmap_mode='r',allow_pickle=False) if d.get('npy') else np.memmap(R/d['path'],dtype=d['dtype'],mode='r',shape=(d['length'],))
def main():
 assert not (O/'RNA_admission_decision.json').exists(),'Do not overwrite completed QC'
 parse=json.loads((G/'object_parse_status.json').read_text(encoding='utf-8'));assert parse['state']=='structure_pass_expression_gate_pending'
 mac=['MacAlveolar','MacProfibrotic','Mac'];fib=['Fibroblast_Alveolar','Fibroblast_Adventitial','Fibroblast_Fibrotic','Fibroblast_Airway']
 dump('QC_plan_before_expression_scan.json',{'UTC':datetime.now(timezone.utc).isoformat(),'scope':'QC only, no scores/correlations','annotation':'author renamedFinal','macrophage_pool':mac,'alveolar_macrophage_subtype':'MacAlveolar','fibroblast_pool':fib,'alveolar_fibroblast_subtype':'Fibroblast_Alveolar','cell_rule':'Author-annotated cells; exclude only nonpositive RNA denominator or invalid count mapping; no new score-based classification','paired_thresholds':[50,100,200],'within_donor_requirement':'at least2 paired eligible cores with distinct surface density','no_marker_replacement':True,'frozen_gene_file_SHA256':sha(R/'data/derived/mlm_six_state_signatures_frozen.json'),'metadata_SHA256':sha(G/'cell_metadata.tsv'),'matrix_descriptor_SHA256':sha(G/'matrix_descriptors.json'),'biological_association_models':0})
 desc=json.loads((G/'matrix_descriptors.json').read_text(encoding='utf-8'))['RNA.counts'];assert desc['format']=='CSC'
 nr,nc=desc['shape'];features=desc['features'];bars=desc['cells'];assert len(features)==nr and len(bars)==nc and len(set(bars))==nc and len(set(features))==nr
 meta=pd.read_csv(G/'cell_metadata.tsv',sep='\t',keep_default_na=False,dtype={'object_cell_id':str,'Subject.ID':str});assert meta.object_cell_id.tolist()==bars
 i,p,x=[load_array(desc[k]) for k in ['i','p','x']];assert len(p)==nc+1 and p[0]==0 and p[-1]==len(i)==len(x);assert (np.diff(p)>=0).all()
 signatures=json.loads((R/'data/derived/mlm_six_state_signatures_frozen.json').read_text(encoding='utf-8'))['states']
 panels=json.loads((R/'outputs/mac_fib_feasibility_20261024/candidate_panels_feasibility_only.json').read_text(encoding='utf-8'))['panels'];panels={k:panels[k] for k in ['ECM_structure','ECM_activation_remodeling']}
 modules={**signatures,**panels};gset=set(sum(modules.values(),[]));genes=[g for g in features if g in gset];lookup=np.full(nr,-1,dtype=np.int32)
 for k,g in enumerate(features):
  if g in gset:lookup[k]=genes.index(g)
 selected=meta.renamedFinal.isin(mac+fib).to_numpy();which=np.flatnonzero(selected);to_selected=np.full(nc,-1,dtype=np.int64);to_selected[which]=np.arange(len(which))
 target=np.lib.format.open_memmap(O/'selected_cells_fixed_gene_counts.npy',mode='w+',dtype=np.int32,shape=(len(which),len(genes)));target[:]=0
 umi=np.zeros(nc,dtype=np.int64);detected=np.zeros(nc,dtype=np.int32);zero_entries=0;maxentry=0;canonical_bad=0;last=time.monotonic()
 for start in range(0,nc,2500):
  end=min(nc,start+2500);a,b=int(p[start]),int(p[end]);xb=np.asarray(x[a:b]);ib=np.asarray(i[a:b]);offs=np.asarray(p[start:end+1],dtype=np.int64)-a
  assert np.isfinite(xb).all() and (xb>=0).all() and np.equal(xb,np.rint(xb)).all(),'Invalid RNA counts'
  assert (ib>=0).all() and (ib<nr).all(),'Row index out of bounds'
  if len(xb):maxentry=max(maxentry,int(xb.max()))
  assert maxentry<np.iinfo(np.int32).max;zero_entries+=int((xb==0).sum())
  pref=np.r_[0.,np.cumsum(xb,dtype=np.float64)];umi[start:end]=(pref[offs[1:]]-pref[offs[:-1]]).astype(np.int64)
  pr=np.r_[np.int64(0),np.cumsum(xb>0,dtype=np.int64)];detected[start:end]=(pr[offs[1:]]-pr[offs[:-1]]).astype(np.int32)
  if len(ib)>1:
   bad=np.diff(ib.astype(np.int64))<=0;boundaries=offs[1:-1]-1;boundaries=boundaries[(boundaries>=0)&(boundaries<len(bad))];bad[boundaries]=False;canonical_bad+=int(bad.sum())
  col=np.repeat(np.arange(start,end),np.diff(offs));sel=to_selected[col];gg=lookup[ib];ok=(sel>=0)&(gg>=0)
  np.add.at(target,(sel[ok],gg[ok]),xb[ok].astype(np.int32))
  if time.monotonic()-last>25:print('RNA_QC',end,'/',nc,'cells; entries checked',b,flush=True);last=time.monotonic()
 target.flush();assert canonical_bad==0,'Noncanonical duplicate/unsorted row indices need separate handling'
 meta['RNA_UMI_recomputed']=umi;meta['RNA_features_recomputed']=detected;meta['positive_RNA_denominator']=umi>0
 meta['core_key']=meta['Sample.ID'].str.extract(r'^(\d+_\d+)')[0];meta['core_from_library']=meta['Library.Ident'].str.extract(r'^(\d+_\d+)')[0];assert meta.core_key.eq(meta.core_from_library).all()
 core=pd.read_csv(R/'outputs/Intratype_route_gate_20261027/GSE286182_core_microCT_metadata.csv',dtype={'Subject.ID':str})
 check=meta[['core_key','Subject.ID','Disease.Ident','Surface.Density']].drop_duplicates().merge(core[['core_key','Subject.ID','Disease.Ident','Surface_Density_min']],on='core_key',suffixes=('_raw','_mapped'),how='left',validate='many_to_one')
 check['subject_agrees']=check['Subject.ID_raw'].eq(check['Subject.ID_mapped']);check['diagnosis_agrees']=check['Disease.Ident_raw'].eq(check['Disease.Ident_mapped']);check['microCT_agrees']=np.isclose(check['Surface.Density'].astype(float),check.Surface_Density_min.astype(float),atol=1e-10,rtol=1e-7)
 check.to_csv(O/'whole_object_core_microCT_match.csv',index=False);assert check[['subject_agrees','diagnosis_agrees','microCT_agrees']].all().all()
 source_umi=pd.to_numeric(meta.nCount_RNA,errors='coerce');source_features=pd.to_numeric(meta.nFeature_RNA,errors='coerce')
 mismatch=int((~np.isclose(umi,source_umi,atol=1e-6)).sum());feature_mismatch=int((detected!=source_features).sum())
 meta[['object_cell_id','Subject.ID','core_key','Library.Ident','Disease.Ident','renamedFinal','RNA_UMI_recomputed','RNA_features_recomputed','positive_RNA_denominator']].to_csv(O/'all_cells_RNA_QC.csv.gz',index=False)
 sm=meta.loc[selected].reset_index(drop=True);sm.to_csv(O/'selected_cells_metadata.csv.gz',index=False);dump('selected_gene_order.json',genes)
 counts=meta[meta.positive_RNA_denominator].groupby(['Subject.ID','core_key','Disease.Ident','renamedFinal']).size().unstack('renamedFinal',fill_value=0).reset_index()
 for label in mac+fib:
  if label not in counts:counts[label]=0
 counts['broad_macrophages']=counts[mac].sum(axis=1);counts['broad_fibroblasts']=counts[fib].sum(axis=1)
 counts=counts.merge(core[['core_key','Surface_Density_min']],on='core_key',validate='one_to_one');counts.to_csv(O/'core_author_subtype_counts.csv',index=False)
 gates=[];spans=[]
 for receiver in ['broad_fibroblasts','Fibroblast_Alveolar']:
  for threshold in [50,100,200]:
   eligible=counts[(counts.MacAlveolar>=threshold)&(counts[receiver]>=threshold)]
   for diag,g in eligible.groupby('Disease.Ident'):
    group=g.groupby('Subject.ID').agg(cores=('core_key','nunique'),density_values=('Surface_Density_min','nunique')).reset_index();multi=group[(group.cores>=2)&(group.density_values>=2)]
    gates.append({'receiver':receiver,'minimum_cells_each':threshold,'diagnosis':diag,'eligible_cores':len(g),'eligible_donors':g['Subject.ID'].nunique(),'donors_with_2plus_distinct_density_cores':len(multi)})
    for _,v in group.iterrows():spans.append({'receiver':receiver,'minimum_cells_each':threshold,'diagnosis':diag,**v.to_dict()})
 pd.DataFrame(gates).to_csv(O/'paired_core_capacity_gates.csv',index=False);pd.DataFrame(spans).to_csv(O/'eligible_donor_core_span.csv',index=False)
 coverage=[]
 for name,gs in modules.items():
  for label,groupname in [('MacAlveolar','alveolar_macrophages'),('Fibroblast_Alveolar','alveolar_fibroblasts')]:
   use=[g for g in gs if g in genes];ix=sm.renamedFinal.eq(label).to_numpy();idx=[genes.index(g) for g in use];cg=target[ix][:,idx].sum(axis=0);coverage.append({'program':name,'cell_type':label,'original_genes':len(gs),'directory_present':len(use),'globally_detected':int((cg>0).sum()),'directory_missing':','.join(g for g in gs if g not in genes),'not_detected_in_subtype':','.join(g for g,v in zip(use,cg) if v==0)})
 pd.DataFrame(coverage).to_csv(O/'fixed_program_directory_and_subtype_detection.csv',index=False)
 # Core-level counts/detection are QC, not z scores or inferential analyses.
 cg=[]
 for (donor,ck,label),ids in sm.groupby(['Subject.ID','core_key','renamedFinal']).groups.items():
  if label not in ['MacAlveolar']+fib:continue
  arr=target[np.asarray(list(ids))];sums=arr.sum(axis=0);dets=(arr>0).sum(axis=0)
  for name,gs in modules.items():
   if label=='MacAlveolar' and name not in signatures:continue
   if label in fib and name not in panels:continue
   for g in gs:
    if g in genes:
     j=genes.index(g);cg.append({'donor':donor,'core':ck,'subtype':label,'program':name,'gene':g,'RNA_count':int(sums[j]),'detected_cells':int(dets[j]),'cells':len(ids),'full_RNA_total':int(sm.loc[ids,'RNA_UMI_recomputed'].sum())})
 pd.DataFrame(cg).to_csv(O/'core_fixed_gene_counts_detection_QC.csv',index=False)
 result={'completed_UTC':datetime.now(timezone.utc).isoformat(),'source_RNA_count_matrix':[nr,nc],'all_sparse_values_checked':len(x),'all_counts_finite_nonnegative_integer_like':True,'stored_zero_entries':zero_entries,'max_gene_count':maxentry,'CSC_index_bounds_and_strict_within_column_order_passed':True,'metadata_barcode_exact_match':True,'RNA_totals_match_author_nCount_RNA_mismatches':mismatch,'RNA_features_match_author_nFeature_RNA_mismatches':feature_mismatch,'zero_RNA_cells':int((umi<=0).sum()),'mapped_donors':meta['Subject.ID'].nunique(),'mapped_cores':meta.core_key.nunique(),'all_core_microCT_matches':True,'paired_core_gates':gates,'annotation_gate':'Author MacAlveolar labels available; marker-independent annotation/circularity not fully excluded','histology_gate':'same-core microCT and serial-section methods verified; no cell-level spatial coordinates or complete digital pathology labeling verified','recipient_gate':'fixed ECM expression metrics available; no ligand-specific response or TGF-beta experimental footprint validation','overall':'RNA and donor-core pairing QC passed; statistical estimand and usable donor support require pre-model review','biological_association_models_fitted':0,'no_manuscript_edits':True};dump('RNA_admission_decision.json',result);print(json.dumps(result,ensure_ascii=False,default=str),flush=True)
if __name__=='__main__':main()
