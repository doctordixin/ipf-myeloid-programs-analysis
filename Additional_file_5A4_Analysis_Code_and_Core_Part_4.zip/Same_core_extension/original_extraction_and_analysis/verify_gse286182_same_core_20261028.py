"""Independent WLS/donor-centering and full-null cross-check; source preservation."""
from pathlib import Path
import json,hashlib,itertools
import numpy as np
import pandas as pd
from scipy.stats import rankdata
import statsmodels.api as sm
R=Path(__file__).resolve().parents[1];O=R/'outputs/GSE286182_same_core_analysis_20261028'
core=pd.read_csv(O/'all54_core_scores_flow_depth_composition.csv',dtype={'Subject.ID':str});q=core[core.primary_within_IPF].reset_index(drop=True);g=q['Subject.ID'].to_numpy();groups=[np.flatnonzero(g==d) for d in np.unique(g)];w=np.zeros(len(q))
for a in groups:w[a]=1/len(a)
X=pd.get_dummies(q['Subject.ID'],dtype=float).to_numpy();x=rankdata(q.CCL2hi);rx=sm.WLS(x,X,weights=w).fit().resid
primary=pd.read_csv(O/'primary_results.csv');saved=np.load(O/'primary_null_and_donor_bootstrap.npz',allow_pickle=False);checks=[]
for endpoint in ['ECM_structure','ECM_activation_remodeling']:
 y=rankdata(q[endpoint]);ry=sm.WLS(y,X,weights=w).fit().resid;r=float(np.sum(w*rx*ry)/np.sqrt(np.sum(w*rx*rx)*np.sum(w*ry*ry)))
 row=primary[primary.endpoint==endpoint].iloc[0];assert np.allclose(r,row.weighted_within_donor_rank_r,rtol=1e-11,atol=1e-11)
 # Reconstruct null via independent per-donor cross-products, without fitted residual matrices.
 ar=x.copy();br=y.copy()
 for a in groups:ar[a]-=ar[a].mean();br[a]-=br[a].mean()
 terms=[]
 for a in groups:terms.append(np.array([float(np.dot(ar[a],br[list(perm)]))/len(a) for perm in itertools.permutations(a)]))
 values=np.array([0.])
 for t in terms:values=(values[:,None]+t[None,:]).ravel()
 values/=np.sqrt(np.sum(w*ar**2)*np.sum(w*br**2));assert np.allclose(np.sort(values),np.sort(saved[endpoint+'_null']),rtol=1e-10,atol=1e-10)
 p=float(np.mean(abs(values)>=abs(r)-1e-12));assert abs(p-row.exact_within_donor_permutation_P)<1e-12
 checks.append({'endpoint':endpoint,'statsmodels_WLS_r_verified':r,'independent_full_null_distribution_matched':len(values),'exact_P_verified':p})
protected=json.loads((R/'outputs/SCP2879_alvMac_CCL2hi_20261027_final/protected_before.json').read_text(encoding='utf-8'));unchanged=all(hashlib.sha256((R/p).read_bytes()).hexdigest()==h for p,h in protected.items());assert unchanged
out={'independent_checks':checks,'protected_files_checked':len(protected),'protected_unchanged':unchanged,'no_manuscript_edits':True,'no_extra_hypotheses_added':True,'same_core_technical_admission':'complete RNA/metadata QC; exploratory author-subtype analysis only','full_causal_marker_independent_mechanism_gate':'not established'}
(O/'independent_numerical_and_preservation_verification.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out,indent=2))
