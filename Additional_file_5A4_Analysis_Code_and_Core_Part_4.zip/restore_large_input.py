from pathlib import Path
import hashlib,json,os
ROOT=Path(__file__).resolve().parent
manifest=json.loads((ROOT/'split_package_manifest.json').read_text(encoding='utf8'))
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def local(name):
 p=(ROOT/name).resolve()
 if not p.is_relative_to(ROOT):raise ValueError('Unsafe package path')
 return p
for entry in manifest['split_files']:
 dst=local(entry['restore_path']);dst.parent.mkdir(parents=True,exist_ok=True)
 if dst.exists():
  if digest(dst)!=entry['sha256']:raise RuntimeError('Existing file differs; refusing overwrite: '+str(dst))
 else:
  tmp=dst.with_name(dst.name+'.reassembly.tmp')
  if tmp.exists():raise RuntimeError('Temporary output already exists: '+str(tmp))
  with tmp.open('xb') as out:
   for part in entry['chunks']:
    src=local(part['path'])
    if src.stat().st_size!=part['bytes'] or digest(src)!=part['sha256']:raise RuntimeError('Missing or invalid chunk: '+str(src))
    with src.open('rb') as f:
     for b in iter(lambda:f.read(1024*1024),b''):out.write(b)
  if tmp.stat().st_size!=entry['bytes'] or digest(tmp)!=entry['sha256']:raise RuntimeError('Reassembly checksum mismatch')
  tmp.rename(dst)
for name,entry in manifest['original_entries'].items():
 p=local(name)
 if entry['is_directory']:
  if not p.is_dir():raise RuntimeError('Missing directory: '+name)
 elif not p.is_file() or p.stat().st_size!=entry['bytes'] or digest(p)!=entry['sha256']:
  raise RuntimeError('Original-file verification failed: '+name)
print('PASS: all '+str(len(manifest['original_entries']))+' original entries verified; original contents unchanged.')
print('Large input restored. Use the original README replay commands. Keep the package subdirectories.')
