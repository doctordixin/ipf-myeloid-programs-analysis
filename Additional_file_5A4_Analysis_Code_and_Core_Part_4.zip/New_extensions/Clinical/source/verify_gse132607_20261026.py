"""Independent HC3 sandwich algebra and exact patient-visit reconciliation."""
from pathlib import Path
import json,hashlib
import numpy as np,pandas as pd
from scipy.stats import t
R=Path(__file__).resolve().parents[1];O=R/'outputs/GSE132607_clinical_20261026'
rows=pd.read_csv(O/'model_results.csv');data=pd.read_csv(O/'model_patient_data.csv',dtype={'patient':str})
meta=pd.read_csv(R/'outputs/Clinical_evidence_sweep_20261026/GSE132607_patient_visit_metadata.csv',dtype=str)
checks=[]
def check(name,cond):checks.append(dict(check=name,passed=bool(cond)))
for r in json.loads((O/'analysis_input_freeze.json').read_text())['files']:
    check('input SHA '+r['path'],hashlib.sha256((R/r['path']).read_bytes()).hexdigest()==r['sha256'])
check('no duplicate original patient visits',not meta[['comet_id','follow-up time']].duplicated().any())
for (contrast,ep,scale),g in data.groupby(['contrast','endpoint','scale']):
    for _,r in g.iterrows():
        pid=r.patient;v=meta[meta.comet_id==pid].set_index('follow-up time')
        ref='Baseline' if contrast=='baseline_to_12mo' else '4mo'
        y=100*(float(v.loc['12mo','fvc_pp'])/float(v.loc[ref,'fvc_pp'])-1)
        check('temporal outcome '+contrast+' '+pid+' '+ep+' '+scale,np.isclose(y,r.outcome,rtol=1e-12,atol=1e-12))
for _,r in rows[rows.status=='estimated'].iterrows():
    g=data[(data.contrast==r.contrast)&(data.endpoint==r.endpoint)&(data.scale==r.scale)]
    fs=['predictor']+(['age','male','FVC_reference'] if r.adjusted else [])
    g=g.dropna(subset=fs+['outcome']);X=np.column_stack([np.ones(len(g)),g[fs].to_numpy()]);y=g.outcome.to_numpy()
    inv=np.linalg.inv(X.T@X);coef=inv@X.T@y;res=y-X@coef;h=np.einsum('ij,jk,ik->i',X,inv,X)
    meat=X.T@((res/(1-h))[:,None]**2*X);se=np.sqrt(np.diag(inv@meat@inv));p=2*t.sf(abs(coef[1]/se[1]),len(g)-X.shape[1]);ci=coef[1]+np.array([-1,1])*t.ppf(.975,len(g)-X.shape[1])*se[1]
    check('independent HC3 '+r.contrast+' '+r.endpoint+' '+r.scale+' '+str(r.adjusted),np.allclose([coef[1],p,*ci],[r.beta,r.p,r.CI95_low,r.CI95_high],rtol=1e-8,atol=1e-8))
pri=rows[(rows.scale=='standardized')&rows.adjusted].copy();check('18 planned primary slots',len(pri)==18)
ordered=pri.assign(padp=pri.p.fillna(1)).sort_values('padp');run=0
for i,(_,r) in enumerate(ordered.iterrows()):
    run=max(run,min(1,(18-i)*r.padp))
    check('Holm '+r.contrast+' '+r.endpoint,np.isnan(r.Holm18) if r.status!='estimated' else np.isclose(run,r.Holm18))
check('CXCL10/balance not inferred',pri[pri.endpoint.isin(['CXCL10hi','SPP1_CXCL10_balance'])].p.isna().all())
receipt=dict(overall='PASS' if all(x['passed'] for x in checks) else 'FAIL',checks=len(checks),details=checks,
 scope='Independent algebra and patient visit checks; not clinical validation, genotype identity, missing-at-random or model-assumption proof')
(O/'verification_receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(receipt['overall'],len(checks));assert receipt['overall']=='PASS'
