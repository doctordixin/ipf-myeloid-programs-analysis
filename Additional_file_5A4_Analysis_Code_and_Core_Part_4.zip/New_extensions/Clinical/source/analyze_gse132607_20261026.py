"""Outcome-blind frozen-module processing followed by prespecified PBMC/FVC boundary tests."""
from pathlib import Path
from datetime import datetime,timezone
import gzip,io,json,hashlib,re,sys
import numpy as np,pandas as pd,statsmodels.api as sm
from scipy import stats
from statsmodels.stats.multitest import multipletests
R=Path(__file__).resolve().parents[1];O=R/'outputs/GSE132607_clinical_20261026'
M=R/'outputs/upgrade_gate_20261025/unchanged_candidate_modules.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def js(name,v):(O/name).write_text(json.dumps(v,indent=2,ensure_ascii=False,allow_nan=False),encoding='utf-8')
def main():
    assert not (O/'model_results.csv').exists(),'Do not overwrite effects'
    inputs=[O/'GSE132607_series_matrix.txt.gz',O/'GPL15207_probe_symbols.tsv',O/'locked_plan.json',M,
      R/'outputs/Clinical_evidence_sweep_20261026/GSE132607_patient_visit_metadata.csv']
    js('analysis_input_freeze.json',dict(utc=datetime.now(timezone.utc).isoformat(),files=[dict(path=p.relative_to(R).as_posix(),sha256=sha(p)) for p in inputs],code_sha256=sha(Path(__file__))))
    meta=pd.read_csv(inputs[-1],dtype=str).rename(columns={'comet_id':'patient','follow-up time':'visit'})
    assert not meta[['patient','visit']].duplicated().any()
    for k in ['age','fvc_pp']:meta[k]=pd.to_numeric(meta[k],errors='coerce')
    meta['male']=meta.gender.map({'M':1,'F':0});base=meta[meta.visit=='Baseline'].set_index('patient');assert len(base)==74
    with gzip.open(inputs[0],'rt',encoding='utf-8') as f:
        header=[]
        for l in f:
            if l.startswith('!series_matrix_table_begin'):break
            header.append(l)
        expr=pd.read_csv(f,sep='\t',index_col=0,comment='!',dtype={0:str})
    assert len(expr.columns)==276 and set(expr)==set(meta.gsm) and not expr.index.duplicated().any()
    assert np.isfinite(expr.to_numpy()).all()
    processing=[l for l in header if l.startswith('!Sample_data_processing')]
    js('expression_QC.json',dict(shape=list(expr.shape),min=float(expr.min().min()),max=float(expr.max().max()),
       processing_unique=sorted(set(re.findall(r'"([^"]+)"',''.join(processing)))),already_normalized_no_second_log=True))
    mods=json.loads(M.read_text());lookup=json.loads((M.parent/'Ensembl_symbol_lookup.json').read_text())
    idmap={v['id']:v['display_name'] for v in lookup.values() if isinstance(v,dict) and v.get('id') and v.get('display_name')}
    amap=pd.read_csv(inputs[1],sep='\t',dtype=str).fillna('')
    amap=amap[amap['Gene Symbol'].str.match(r'^[A-Za-z0-9_-]+$')]
    amap=amap[amap.ID.isin(expr.index)]
    assert not amap.ID.duplicated().any()
    mapped=expr.loc[amap.ID].copy();mapped.index=amap['Gene Symbol'].tolist();gene=mapped.groupby(level=0,sort=False).mean()
    endpoints=list(mods)+['SPP1_CXCL10_balance'];scores=pd.DataFrame(index=expr.columns);raw=scores.copy();audit=[];cal={}
    for mod,labels in mods.items():
        genes=[]
        for g in labels:
            cg=idmap.get(g,g) if g.startswith('ENSG') else g
            found=cg if cg in gene.index else g if g in gene.index else None
            good=found is not None and gene.loc[found,base.gsm].std(ddof=1)>1e-8
            audit.append(dict(module=mod,frozen_gene=g,mapped_gene=found,usable=bool(good),probes=int((amap['Gene Symbol']==found).sum()) if found else 0))
            if good:genes.append(found)
        usable=len(genes)>=np.ceil(.8*len(labels));cal[mod]=dict(usable=bool(usable),genes=genes,canonical_n=len(labels))
        if not usable:scores[mod]=np.nan;raw[mod]=np.nan;continue
        mu=gene.loc[genes,base.gsm].mean(axis=1);sd=gene.loc[genes,base.gsm].std(axis=1,ddof=1)
        s=gene.loc[genes].sub(mu,axis=0).div(sd,axis=0).mean(axis=0)
        smu=float(s[base.gsm].mean());ssd=float(s[base.gsm].std(ddof=1));assert ssd>1e-8
        scores[mod]=(s-smu)/ssd;raw[mod]=gene.loc[genes].mean(axis=0)
        cal[mod].update(gene_mean=mu.to_dict(),gene_sd=sd.to_dict(),module_mean=smu,module_sd=ssd)
    b=scores.SPP1hi-scores.CXCL10hi;bs=float(b[base.gsm].std(ddof=1))
    scores['SPP1_CXCL10_balance']=(b-b[base.gsm].mean())/bs if np.isfinite(bs) and bs>1e-8 else np.nan
    raw['SPP1_CXCL10_balance']=raw.SPP1hi-raw.CXCL10hi
    js('calibration.json',cal);pd.DataFrame(audit).to_csv(O/'gene_coverage.csv',index=False)
    scores.rename_axis('gsm').to_csv(O/'sample_scores.csv');raw.rename_axis('gsm').to_csv(O/'unstandardized_scores.csv')
    clinical=[];model_data=[]
    for pid,row in base.iterrows():
        follow=meta[(meta.patient==pid)&(meta.visit=='12mo')];four=meta[(meta.patient==pid)&(meta.visit=='4mo')]
        clinical.append(dict(patient=pid,baseline_gsm=row.gsm,has_12mo=len(follow)==1,has_4mo=len(four)==1,
          age=row.age,male=row.male,baseline_FVCpp=row.fvc_pp,original_progression_flag=row.get('fvc_decline_10')))
        if len(follow)!=1:continue
        twelve=follow.iloc[0]
        if row.fvc_pp<=0 or twelve.fvc_pp<=0:continue
        for scale,sc in [('standardized',scores),('unstandardized',raw)]:
            for ep in endpoints:
                model_data.append(dict(patient=pid,contrast='baseline_to_12mo',scale=scale,endpoint=ep,predictor=sc.loc[row.gsm,ep],
                   outcome=100*(twelve.fvc_pp/row.fvc_pp-1),age=row.age,male=row.male,FVC_reference=row.fvc_pp))
                if len(four)==1 and four.iloc[0].fvc_pp>0:
                    f=four.iloc[0]
                    model_data.append(dict(patient=pid,contrast='four_month_landmark',scale=scale,endpoint=ep,predictor=sc.loc[f.gsm,ep]-sc.loc[row.gsm,ep],
                      outcome=100*(twelve.fvc_pp/f.fvc_pp-1),age=row.age,male=row.male,FVC_reference=f.fvc_pp))
    clinical=pd.DataFrame(clinical);clinical.to_csv(O/'patient_flow.csv',index=False)
    data=pd.DataFrame(model_data);data.to_csv(O/'model_patient_data.csv',index=False,float_format='%.17g')
    rows=[];coeff=[]
    for (contrast,scale,ep),g in data.groupby(['contrast','scale','endpoint'],sort=True):
        for adj in [False,True]:
            features=['predictor']+(['age','male','FVC_reference'] if adj else [])
            d=g.dropna(subset=features+['outcome']);n=len(d)
            result=dict(contrast=contrast,scale=scale,endpoint=ep,adjusted=adj,n=n,status='not_estimable',beta=None,CI95_low=None,CI95_high=None,p=None,Holm18=None)
            if n>=25 and d.predictor.std()>1e-8:
                X=sm.add_constant(d[features],has_constant='add');y=d.outcome
                fit=sm.OLS(y,X).fit(cov_type='HC3',use_t=True);ci=fit.conf_int().loc['predictor']
                result.update(status='estimated',beta=float(fit.params['predictor']),CI95_low=float(ci.iloc[0]),CI95_high=float(ci.iloc[1]),p=float(fit.pvalues['predictor']),
                  condition_number=float(np.linalg.cond(X)),Shapiro_residual_p=float(stats.shapiro(fit.resid).pvalue),max_leverage=float(sm.OLS(y,X).fit().get_influence().hat_matrix_diag.max()))
                for i,(pid,res,pr) in enumerate(zip(d.patient,fit.resid,fit.fittedvalues)):
                    coeff.append(dict(contrast=contrast,scale=scale,endpoint=ep,adjusted=adj,patient=pid,residual=res,fitted=pr))
            rows.append(result)
    res=pd.DataFrame(rows)
    primary=(res.scale=='standardized')&res.adjusted
    assert primary.sum()==18
    p=res.loc[primary,'p'].fillna(1).to_numpy(dtype=float);padj=multipletests(p,method='holm')[1]
    res.loc[primary,'Holm18']=padj;res.loc[primary&(res.status!='estimated'),'Holm18']=np.nan
    res.to_csv(O/'model_results.csv',index=False,float_format='%.17g');pd.DataFrame(coeff).to_csv(O/'model_diagnostics.csv',index=False)
    js('flow_summary.json',dict(baseline_patients=len(base),unique_ids_all_visits=int(meta.patient.nunique()),total_libraries=len(meta),
      visits=meta.groupby('visit').size().to_dict(),actual_baseline_12_pairs=int(clinical.has_12mo.sum()),missing_12mo=int((~clinical.has_12mo).sum()),
      notes='Exact IDs only; unmatched follow-up IDs excluded; missing follow-up never coded as stable. Original fvc_decline_10 not used as primary outcome.',
      models_available=int(res.loc[primary,'p'].notna().sum()),family_size=18,Holm_positive=int((res.loc[primary,'Holm18']<.05).sum()),
      frozen_inputs_unchanged=all(sha(R/r['path'])==r['sha256'] for r in json.loads((O/'analysis_input_freeze.json').read_text())['files'])))
    print(res.loc[primary,['contrast','endpoint','n','status','beta','p','Holm18']].to_string(index=False))
    print('Coverage',[(k,len(v['genes']),v['usable']) for k,v in cal.items()])
if __name__=='__main__':main()
