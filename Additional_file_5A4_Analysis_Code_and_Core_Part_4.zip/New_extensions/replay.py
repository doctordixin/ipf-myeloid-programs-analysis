"""Portable scoped verification: deposited B2 RNA -> scores; prepared PBMC design matrices -> all models."""
from pathlib import Path
import json,itertools
import numpy as np,pandas as pd
from scipy.stats import t
R=Path(__file__).resolve().parent
B=R/'B2';C=R/'Clinical';checks=[]
def check(name,ok):checks.append(dict(check=name,passed=bool(ok)))
x=pd.read_csv(B/'inputs/GSE291190_ipf_tpm.csv.gz',index_col=0)
cal=json.loads((B/'results/DMSO_calibration.json').read_text());pairs=pd.read_csv(B/'results/all_donor_paired_deltas.csv')
libs=['S2945','S294D5','S2965','S296D5','S2975','S297D5'];s=pd.DataFrame(index=libs);raw=s.copy()
for module,c in cal.items():
    if module=='SPP1_CXCL10_balance':continue
    g=c['genes'];z=x.loc[g,libs].sub(pd.Series(c['gene_means']),axis=0).div(pd.Series(c['gene_SDs']),axis=0)
    s[module]=(z.mean(axis=0)-c['module_mean'])/c['module_SD'];raw[module]=x.loc[g,libs].mean(axis=0)
bc=cal['SPP1_CXCL10_balance'];s['SPP1_CXCL10_balance']=(s.SPP1hi-s.CXCL10hi-bc['DMSO_mean'])/bc['DMSO_SD']
raw['SPP1_CXCL10_balance']=raw.SPP1hi-raw.CXCL10hi
for _,r in pairs.iterrows():
    sc=s if r.scale=='DMSO_standardized' else raw
    drug='S'+r.donor.split('_')[1]+'5';ctrl=drug[:-1]+'D5'
    check('B2 score '+r.scale+' '+r.donor+' '+r.endpoint,np.isclose(sc.loc[drug,r.endpoint]-sc.loc[ctrl,r.endpoint],r.delta,rtol=1e-10,atol=1e-10))
primary=pd.read_csv(B/'results/primary_nine_endpoints.csv')
for _,r in primary.iterrows():
    vals=pairs[(pairs.scale=='DMSO_standardized')&(pairs.endpoint==r.endpoint)].delta.to_numpy()
    p=np.mean([abs(np.mean(vals*np.array(k)))>=abs(vals.mean())-1e-12 for k in itertools.product([-1,1],repeat=3)])
    check('B2 signflip '+r.endpoint,np.isclose(p,r.inferential_p))
models=pd.read_csv(C/'results/model_results.csv');d=pd.read_csv(C/'results/model_patient_data.csv')
for _,r in models[models.status=='estimated'].iterrows():
    g=d[(d.contrast==r.contrast)&(d.scale==r.scale)&(d.endpoint==r.endpoint)]
    fields=['predictor']+(['age','male','FVC_reference'] if r.adjusted else [])
    g=g.dropna(subset=fields+['outcome']);X=np.column_stack([np.ones(len(g)),g[fields]]);y=g.outcome.to_numpy()
    inv=np.linalg.inv(X.T@X);beta=inv@X.T@y;res=y-X@beta;h=np.einsum('ij,jk,ik->i',X,inv,X)
    se=np.sqrt(np.diag(inv@(X.T@((res/(1-h))[:,None]**2*X))@inv));p=2*t.sf(abs(beta[1]/se[1]),len(y)-X.shape[1])
    ci=beta[1]+np.array([-1,1])*t.ppf(.975,len(y)-X.shape[1])*se[1]
    check('Clinical HC3 '+r.contrast+' '+r.scale+' '+r.endpoint+' '+str(r.adjusted),np.allclose([beta[1],p,*ci],[r.beta,r.p,r.CI95_low,r.CI95_high],rtol=1e-8,atol=1e-8))
for label,df,pname,qname,family in [('B2',primary,'inferential_p','Holm_p_9',9),('Clinical',models[(models.scale=='standardized')&models.adjusted],'p','Holm18',18)]:
    ordered=df.assign(padp=df[pname].fillna(1)).sort_values('padp');run=0
    for i,(_,r) in enumerate(ordered.iterrows()):
        run=max(run,min(1,(family-i)*r.padp))
        check(label+' Holm '+str(i),pd.isna(r[qname]) if pd.isna(r[pname]) else np.isclose(run,r[qname]))
result=dict(overall='PASS' if all(x['passed'] for x in checks) else 'FAIL',checks=checks,
 scope='B2: deposited expression and fixed calibration to paired scores/P values. Clinical: prepared patient-level design matrices to coefficients/HC3 intervals/P values. Does not reconstruct full raw microarray processing or prove clinical validity.')
(R/'scoped_replay_receipt.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(result['overall'],len(checks),'scoped checks');assert result['overall']=='PASS'
