from pathlib import Path
from copy import deepcopy
from io import BytesIO
import json,zipfile,re
from docx import Document
from docx.text.paragraph import Paragraph
from docx.shared import Pt
R=Path(__file__).resolve().parents[1];B=R/'outputs/Revision_20261028_v11';U=B/'01_Upload_Files';OLD=R/'outputs/Revision_20261026_v10/01_Upload_Files';ops=[]
def text(p,t):
 prop=deepcopy(p.runs[0]._r.rPr) if p.runs and p.runs[0]._r.rPr is not None else None
 old=p.text;p.clear();r=p.add_run(t)
 if prop is not None:r._r.insert(0,prop)
 if t.startswith(('Methods: ','Results: ')):
  label,body=t.split(': ',1);r.text=label+': ';r.bold=True;r2=p.add_run(body)
  if prop is not None:r2._r.insert(0,deepcopy(prop))
  r2.bold=False
 ops.append({'old':old,'new':t})
def after(p,t):
 q=deepcopy(p._p);p._p.addnext(q);v=Paragraph(q,p._parent);text(v,t);return v
def append(p,t):
 prop=deepcopy(p.runs[0]._r.rPr) if p.runs and p.runs[0]._r.rPr is not None else None
 r=p.add_run(t)
 if prop is not None:r._r.insert(0,prop)
def add(d,t,bold=False):
 t=re.sub(r'(?<=[a-z])(?=\d)',' ',t)
 t=re.sub(r'\band(?=[A-Z])','and ',t).replace('CI−','CI −')
 t=re.sub(r',(?=\S)',', ',t)
 p=d.add_paragraph(t);p.paragraph_format.space_after=Pt(6);p.paragraph_format.line_spacing=1.15;p.paragraph_format.keep_with_next=bold
 for r in p.runs:r.font.name='Times New Roman';r.font.size=Pt(11);r.bold=bold
 return p
def save(d,n):
 b=BytesIO();d.save(b)
 with zipfile.ZipFile(OLD/n) as old,zipfile.ZipFile(b) as new,zipfile.ZipFile(U/n,'w',zipfile.ZIP_DEFLATED) as z:
  for info in old.infolist():z.writestr(info,new.read(info.filename) if info.filename=='word/document.xml' else old.read(info.filename))

d=Document(OLD/'Manuscript.docx');p=list(d.paragraphs)
text(p[9],p[9].text.replace('Additional BAL macrophage, cellular-composition, spatial and same-donor macrophage–fibroblast analyses assessed supporting evidence and interpretive boundaries.','Retrospective centre-held-out prediction and additional BAL, cellular, spatial and matched-block analyses assessed transportability and interpretive boundaries.'))
text(p[10],p[10].text.replace('CCL2hi shared information with established BAL risk programs.','CCL2hi shared established BAL risk information; centre-held-out concordance gains over GAP were 0.064–0.133, with two of three conditional bootstrap intervals crossing zero.').replace('Cellular and spatial analyses constrained mechanistic interpretation; a composition-sensitive macrophage–ECM association was not replicated across the two cellular cohorts.','Macrophage–ECM covariation was composition-sensitive and lacked consistent replication.'))
text(p[30],p[30].text.replace('Leave-one-centre-out and leave-one-platform-intersection-gene-out analyses assessed dependence on an individual centre or marker.','Centre-deletion refits and leave-one-platform-intersection-gene-out analyses assessed dependence on an individual centre or marker.'))
after(p[30],'A later centre-held-out sensitivity trained GAP-only and GAP-plus-program Cox models in two centres and evaluated concordance in the third. All seven programs or contrasts were retained. Gene and module scaling were estimated only in training patients, without changing the available marker lists. However, the deposited expression matrices had already undergone joint source-study normalization across IPF and control samples. This analysis therefore evaluated transport conditional on processed expression, rather than independent preprocessing or independent-study validation. Paired test-patient bootstrap intervals (2,000 draws) were conditional on fitted models and excluded training and prior program-selection uncertainty. No absolute-risk calibration was estimated (Table S23).')
after(p[38],'A later GSE286182 tissue analysis [49] paired author-annotated MacAlveolar and fibroblast RNA within the same tissue blocks. The exploratory within-IPF-donor analysis required at least 50 cells per pool and two eligible blocks per donor; fixed CCL2hi and two existing ECM programs were tested using donor-balanced rank associations and within-donor permutations (Table S24).')
text(p[59],'The associations retained their directions after centre and marker deletion. In the separate centre-held-out analysis, GAP-only versus GAP-plus-CCL2hi concordance was 0.613 versus 0.746 in Freiburg, 0.663 versus 0.727 in Siena and 0.709 versus 0.790 in Leuven. The corresponding gains were 0.133 (pointwise conditional 95% bootstrap interval 0.043 to 0.219), 0.064 (−0.036 to 0.165) and 0.081 (−0.011 to 0.171). These retrospective estimates were conditional on the published preprocessing and prior pooled exploration (Table S23); common-gene and other robustness results remain in Table S6 and Supplementary Fig. 1.')
after(p[73],'In GSE286182, the same-block analysis within author-annotated alveolar macrophages included seven IPF donors and 19 blocks. It did not support positive CCL2hi–ECM coupling: the within-donor rank correlation was −0.531 for ECM structure (Holm P=0.170) and 0.047 for ECM activation/remodelling (Holm P=0.905). Depth, tissue-background and donor-deletion sensitivities are retained in Table S24.')
text(p[85],p[85].text+' Centre-held-out ranking gains were directionally consistent for CCL2hi but imprecise in two centres. Prior program prioritisation and joint source normalization prevent treating this exercise as untouched external validation.')
append(p[88],' The same-block GSE286182 results likewise did not support uniform positive coupling within the author-defined alveolar macrophage subtype; their different within-donor estimand does not directly negate the earlier cross-donor association.')
text(p[90],'The principal clinical gap is validation of the fixed BAL RNA program against mortality in a newly collected, non-overlapping study. Additional cellular evidence would need independent donors, subtype definitions independent of the tested program, matched receiver-cell measurements and controlled perturbations. Clinical use also requires assay standardization, external calibration and incremental value over existing predictors.')
append(p[104],' The GSE286182 inVivo tissue object additionally supplied the matched-block qualification reported in Table S24; this added no BAL mortality observations.')
append(p[106],' Centre_transport_extension reproduces the 21 held-out concordance comparisons from prepared author-processed expression. Same_core_extension independently replays the two primary matched-block associations, exact permutation P values and donor-bootstrap intervals from prepared block scores; original extraction code and all sensitivity outputs are retained separately.')
append(p[182],' Additional file 18: Table S23 (all 21 centre-held-out comparisons, score diagnostics and definitions, XLSX). Additional file 19: Table S24 (matched-block primary results, all-block flow, donor/gene and depth/pathology sensitivities, and sampling diagnostics, XLSX).')
table=d.tables[3]
for cell,t in zip(table.rows[-1].cells,['GSE286182 [49]','Human lung and PCLS snRNA-seq','Tissue: 19 donors/54 blocks; within-IPF 7/19. PCLS: 46,930 nuclei, 13 labels, source single donor','Same-block CCL2hi–ECM; descriptive slice time course','Exploratory tissue qualification; descriptive model context','Null tissue tests; PCLS lacks donor replication; no BAL outcome; H12 donor unresolved']):
 text(cell.paragraphs[0],t)
 for q in list(cell.paragraphs)[1:]:q._p.getparent().remove(q._p)
save(d,'Manuscript.docx')

si=Document(OLD/'Additional_file_1_Supplementary_Information.docx')
for heading,paras in [
('Centre held out transport sensitivity',[
 'This retrospective extension used the existing 176 IPF patients and 100 deaths, without adding clinical participants. Freiburg (62 patients,45 deaths), Siena (50,31) and Leuven (64,24) were held out in turn. Unlike centre-deletion refits, each held-out centre was predicted by models fitted only in the other two centres. CCL2hi had already been prioritized after the pooled seven-score outcome comparison; the extension was locally specified after that exploration and was not preregistration or an untouched external test.',
 'The public GEO processing description states that the source investigators quantile-normalized expression across IPF and control samples, removed unexpressed or invariant transcripts, and merged the centres. That source processing could not be reversed. Freiburg/Siena used GPL14550 and Leuven GPL17077. The common available genes remained14,19,18,18,18 and15 for MLM0,CCL2hi,MLM1,IL1Bhi,SPP1hi andCXCL10hi, respectively. No genes were selected using held-out outcomes. All new gene means and sample standard deviations were estimated in pooled training patients. The unweighted gene-z mean, module scaling and relative-contrast scaling were also fixed in training and applied unchanged to the test centre. This training-reference construction is a new transport sensitivity, not replacement of the original within-centre scores or hazard ratios.',
 'Unpenalized Cox models used continuous GAP alone or GAP plus one program, with training-centre-stratified baseline hazards. All six programs and the relative contrast were evaluated in each fold. Linear predictors were transferred without fitting to test outcomes; Harrell concordance was evaluated separately within each held-out centre. Different fold scales were not pooled to create an across-centre C index. Absolute risk, calibration, Brier scores and decision curves were not computed because no baseline hazard was estimated for the held-out centre and no deployable assay calibration was established.',
 'Two thousand paired held-out-patient bootstrap samples per centre compared GAP and GAP-plus-program predictions from the same fixed fitted models (seed20261028). Percentile95% intervals are pointwise and conditional on the trained models, published preprocessing and selected programs; they omit training/selection uncertainty and are not simultaneous or multiplicity-adjusted. No new discrimination P values or optimized cutpoints were used. All21 comparisons and score-location/scale diagnostics are in Table S23. The concordance calculation for all24 original risk vectors (three GAP and21 augmented) was independently checked by enumerating comparable patient pairs.',
 'For CCL2hi, the concordance gains were0.132817,0.063874 and0.081309 in Freiburg,Siena andLeuven, respectively. Conditional intervals crossed zero in the latter two. Directional agreement supports further transport testing, but does not establish stable clinical added value, superiority to established molecular risk programs, or independent BAL mortality replication. All other programs, including negative or reduced-concordance results, remain visible.'
 ]),
('Matched tissue block qualification within alveolar macrophages',[
 'The GSE286182 inVivo object [49] was analysed separately from its descriptive PCLS object. Full double-gzip and serialization checks, RNA count validation and exact cell-metadata matching passed. The RNA assay contained60,651 features and514,988 nuclei; integrated values were not used as raw counts. The source comprised19 donors and54 tissue blocks (9 IPF donors/24 blocks;10 controls/30 blocks). These are not54 independent patients. Source partitions and all blocks remain in Table S24.',
 'Author MacAlveolar annotations defined the sending cell pool, without dividing cells by the tested CCL2hi score. The receiving pool combined author Fibroblast_Alveolar,Fibroblast_Adventitial,Fibroblast_Fibrotic andFibroblast_Airway annotations. Both pools required at least50 nuclei. Nine IPF donors/21 blocks passed this pool-count gate; the within-donor primary analysis additionally required at least two eligible blocks and varying microCT surface density, leaving seven IPF donors/19 blocks. Two single-eligible-block donors remained in flow but did not contribute to within-donor inference. Cell-count minima were not lowered to include failed blocks.',
 'The original20 CCL2hi genes and existing six-gene ECM structure and seven-gene ECM activation/remodelling sets were unchanged and covered. RNA counts were summed within each block/cell pool and divided by its complete provided RNA total before log1p(CPM) transformation. Gene and module calibration used equal total weight per donor and equal block weight within donor, fixed from the19 primary blocks. The primary association globally ranked the block scores, removed donor fixed effects by weighted regression, and correlated the weighted residuals. Donors were the biological units; neither nuclei nor blocks were treated as independent patients.',
 'The two-sided primary permutation tests enumerated all31,104 within-donor permutations of fibroblast block labels and used a two-test Holm correction. This assumes conditional block exchangeability, which is not randomized by the observational design. Ten thousand whole-donor bootstrap draws (seed2026102801) retained all blocks of each sampled donor, treated repeated donor draws as distinct blocks, held score calibration fixed, and reranked scores in each draw. Percentile95% intervals remain exploratory because only seven donors were available.',
 'CCL2hi versus ECM structure had weighted within-donor rank r=−0.530988, exact P=0.085102, Holm P=0.170203 and donor-bootstrap95% CI−0.841670 to0.185286. ECM activation/remodelling had r=0.047042, exact/Holm P=0.904835 and CI−0.708435 to0.588881. The negative structural estimate does not establish a protective effect. The analysis did not independently reproduce a stable positive macrophage–fibroblast relation.',
 'All donor/gene deletions, RNA-depth and microCT-background adjustment, fibroblast-composition controls, alternate receiving/sending pools, count thresholds and equal-cell/equal-RNA sampling diagnostics remain in Table S24 and Additional file5. The structural coefficient stayed negative after individual donor deletion (−0.651 to−0.379); activation/remodelling was directionally unstable. The matched microCT/H&E descriptions concern block background and serial tissue sections, not cell-resolved spatial ligand-receptor signalling. Author subtype annotations do not rule out finer composition or annotation dependence. These within-IPF-donor matched-block estimands differ from the earlier mixed-diagnosis cross-donor SCP2879 association and do not, by themselves, show that the earlier estimate was erroneous.',
 'The portable Same_core_extension replay starts from the supplied54-block score/flow table and independently reconstructs both primary coefficients, exact permutation P values, Holm adjustments and donor-bootstrap intervals. It does not reconstruct the full RNA matrix from the17.62GB source object. Original extraction/analysis code, RNA QC records and all numerical outputs are retained with their stated scope. The tissue extension is mechanistic qualification, not BAL mortality validation.'
 ])]:
 add(si,heading,True)
 for t in paras:add(si,t)
save(si,'Additional_file_1_Supplementary_Information.docx')
st=Document(OLD/'Additional_file_3_STROBE_Checklist.docx');add(st,'Scope of centre transport and matched block analyses',True)
add(st,'Items 5–8, 10, 12–16 and 19–21 additionally map to Tables S23–S24 and corresponding Methods/Results. S23 reuses 176 patients/100 deaths, reporting all 21 comparisons and source-normalization/selection limits. S24 retains 54-block flow, seven-donor/19-block inference, null results and sensitivities. Portable-replay scope is explicit; neither extension adds independent BAL mortality validation.')
save(st,'Additional_file_3_STROBE_Checklist.docx')
(B/'QA/document_revision_operations.json').write_text(json.dumps(ops,ensure_ascii=False,indent=2),encoding='utf-8')
print('V11 DOCUMENTS BUILT; original non-document XML parts preserved')
