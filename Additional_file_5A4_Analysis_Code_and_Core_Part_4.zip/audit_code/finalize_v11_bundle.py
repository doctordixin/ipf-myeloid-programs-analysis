from pathlib import Path
import json,hashlib,shutil,zipfile,subprocess,sys,os,importlib.metadata as M
import numpy as np,pandas as pd,openpyxl
from docx import Document
from pypdf import PdfReader
from PIL import Image,ImageOps,ImageDraw
R=Path(__file__).resolve().parents[1];B=R/'outputs/Revision_20261028_v11';U=B/'01_Upload_Files';Q=B/'QA';A=B/'02_Author_Review';OLD=R/'outputs/Revision_20261026_v10';checks=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def js(p,o):p.write_text(json.dumps(o,ensure_ascii=False,indent=2),encoding='utf-8')
def check(n,v,details=None):
 checks.append(dict(check=n,pass_=bool(v),details=details))
 if not v:raise AssertionError(n)
e=B/'Reproducibility/Centre_transport_extension';s=B/'Reproducibility/Same_core_extension'
for target in [e,s]:
 packages=['numpy','pandas','scipy']+(['lifelines','formulaic','autograd','autograd-gamma','interface-meta','wrapt','narwhals'] if target==e else [])
 (target/'requirements.txt').write_text('\n'.join(n+'=='+M.version(n) for n in packages)+'\n',encoding='utf-8')
(e/'README.txt').write_text('''Centre-held-out transport sensitivity
Install requirements.txt, then run python replay.py from this folder or any working directory. Inputs include 176 public IPF subjects, the 101 unique available marker-gene rows, original processed-expression units and frozen available lists. All scaling and Cox coefficients are estimated in training centres, then applied unchanged to the held-out centre. Original deposited preprocessing used all source samples and cannot be made independent retrospectively. This is not a new independent BAL mortality cohort or an untouched external validation. Prior CCL2hi prioritisation used pooled outcomes.
The script rebuilds all21 comparisons,1232 patient/program predictions, training coefficients, score diagnostics and fixed training-transform parameters. It uses2000 paired test-patient bootstrap draws per centre with fixed trained models; intervals are conditional and pointwise. They do not include training, program-selection or source-preprocessing uncertainty. No new P values, cutpoints, calibration, baseline hazards, Brier scores or clinical-utility claims are computed. Absolute-risk prediction for the unseen stratum is not identified.
Independent Efron coefficient and comparable-pair concordance checks are recorded in results. The independent coefficient-check source is in audit_code. Exact published matrices and original microarray normalization are outside this prepared-input replay; source hashes and processing are in analysis_plan_locked.json. Outputs preserve all seven scores in all three centres. Codex assisted coding; author responsibility and the manuscript AI declaration remain unchanged.
''',encoding='utf-8')
(s/'README.txt').write_text('''Matched-core primary association replay
Install requirements.txt and run python replay_primary.py. The replay uses prepared scores for54 tissue blocks, selects the original7 IPF donors/19 blocks, enumerates all31104 within-donor label permutations, rebuilds10000 whole-donor bootstrap samples, and verifies the two primary coefficients, P values, Holm values and intervals against preserved results. It does not re-extract the17.62GB object or rebuild raw-count scores.
inputs contains all existing primary, flow, depth/pathology/composition, donor/gene deletion and sampling outputs. original_extraction_and_analysis holds the original project-bound scripts for provenance; those entry points require the original project data layout and are not portable replay commands. RNA_QC records link counts, full RNA denominators, author annotations, block IDs and microCT. This remains exploratory qualification with7 donors, not causal communication or BAL mortality validation. Null, reverse and unstable results are retained. Codex assisted coding; authors remain responsible.
''',encoding='utf-8')
shutil.copytree(R/'outputs/GSE286182_Complete_Admission_and_Exploratory_20261028/RNA_QC',s/'RNA_QC',dirs_exist_ok=True)
audit=B/'Reproducibility/audit_code';audit.mkdir(exist_ok=True)
for n in ['prepare_v11_centre_transport.py','verify_v11_cox_independently.py','prepare_v11_bundle.py','build_v11_documents.py','build_v11_workbooks.mjs','merge_v11_workbooks.py','finalize_v11_bundle.py']:shutil.copy2(R/'work'/n,audit/n)
js(e/'analysis_admission.json',{'strict_independent_preprocessing_gate':'failed: source-wide quantile normalization predates deposition','allowed_scope':'conditional processed-matrix centre transport sensitivity only','gene_coverage':'14/19/18/18/18/15, unchanged','training_test_patient_overlap':0,'new_clinical_patients':0,'new_mortality_cohorts':0})
oldzip=OLD/'01_Upload_Files/Additional_file_5_Analysis_Code.zip';newzip=U/oldzip.name
with zipfile.ZipFile(oldzip) as old,zipfile.ZipFile(newzip,'w',zipfile.ZIP_DEFLATED) as new:
 for info in old.infolist():
  data=old.read(info.filename)
  if info.filename=='README.txt':data+=b'\n\nv11: Centre_transport_extension/ and Same_core_extension/ provide scoped portable replays. Original processed-matrix normalization and prior selection limit centre transport; no independent BAL mortality validation is added. Both same-core null results and all sensitivities are retained.\n'
  new.writestr(info,data)
 for target in [e,s,audit]:
  for p in target.rglob('*'):
   if p.is_file() and '__pycache__' not in p.parts:new.write(p,str(p.relative_to(B/'Reproducibility')).replace('\\','/'))
with zipfile.ZipFile(oldzip) as old,zipfile.ZipFile(newzip) as new:
 changed=[n for n in old.namelist() if n!='README.txt' and old.read(n)!=new.read(n)];check('historical_code_entries_unchanged',not changed,changed)
metrics=pd.read_csv(e/'results/heldout_concordance.csv');prim=pd.read_csv(s/'inputs/primary_results.csv')
ev=pd.read_csv(OLD/'Evidence_Classification_v10.csv')
ev=pd.concat([ev,pd.DataFrame([
 ['GSE70866 centre transport','posthoc processed-matrix prediction sensitivity','CCL2hi deltaC Freiburg0.132817/Siena0.063874/Leuven0.081309; two conditional intervals cross0','conditional centre-held-out ranking beyond GAP','new independent BAL mortality cohort; untouched preprocessing; stable clinical utility'],
 ['GSE286182 inVivo same-core','exploratory mechanistic boundary','7 IPF donors19 blocks; ECM structure r-0.530988 HolmP0.170203; activation r0.047042 HolmP0.904835','qualified same-core within-author-subtype association','positive replication; protective causality; ligand-specific response; BAL mortality validation']
 ],columns=ev.columns)],ignore_index=True);ev.to_csv(B/'Evidence_Classification_v11.csv',index=False)
# Preserve original worksheet parts and compare new formal tables numerically.
for name in ['Additional_file_2_Supplementary_Table_S2.xlsx','Additional_file_4_Source_Data.xlsx']:
 with zipfile.ZipFile(OLD/'01_Upload_Files'/name) as old,zipfile.ZipFile(U/name) as new:
  ns=[n for n in old.namelist() if n.startswith('xl/worksheets/')];check(name+'_old_worksheet_XML_preserved',all(old.read(n)==new.read(n) for n in ns),len(ns))
def sheetdf(p,n):
 w=openpyxl.load_workbook(p,read_only=True,data_only=True);rr=list(w[n].iter_rows(values_only=True));h=list(rr[0]);h=h[:h.index(None)] if None in h else h;return pd.DataFrame([(list(r)+[None]*len(h))[:len(h)] for r in rr[1:]],columns=h)
df=sheetdf(U/'Additional_file_18_Supplementary_Table_S23.xlsx','S23_Heldout_C');df=df.iloc[:len(metrics),:len(metrics.columns)];df.columns=metrics.columns
check('S23_all21_comparisons',len(df)==21)
for col in ['C_GAP','C_GAP_plus_program','delta_C','delta_low','delta_high']:check('S23_'+col,np.allclose(pd.to_numeric(df[col]),metrics[col],atol=1e-13,rtol=0))
df=sheetdf(U/'Additional_file_19_Supplementary_Table_S24.xlsx','S24_Primary');df=df.iloc[:2,:len(prim.columns)];df.columns=prim.columns
for col in ['weighted_within_donor_rank_r','exact_within_donor_permutation_P','Holm_P_2']:check('S24_'+col,np.allclose(pd.to_numeric(df[col]),prim[col],atol=1e-13,rtol=0))
for name in ['Manuscript.docx','Additional_file_1_Supplementary_Information.docx','Additional_file_3_STROBE_Checklist.docx']:
 with zipfile.ZipFile(OLD/'01_Upload_Files'/name) as old,zipfile.ZipFile(U/name) as new:
  check(name+'_nonbody_parts_preserved',all(old.read(n)==new.read(n) for n in old.namelist() if n!='word/document.xml'))
 d=Document(U/name);tx='\n'.join(p.text for p in d.paragraphs);check(name+'_S23_S24_references','S23' in tx and 'S24' in tx)
main=Document(U/'Manuscript.docx');oldmain=Document(OLD/'01_Upload_Files/Manuscript.docx');refs=lambda d:[p.text for p in d.paragraphs if __import__('re').match(r'^\d+\. ',p.text)]
check('all49_reference_entries_unchanged',refs(main)==refs(oldmain) and len(refs(main))==49)
maintext='\n'.join(p.text for p in main.paragraphs)
check('main_core_effects_preserved',all(oldmain.paragraphs[i].text in maintext for i in [58,64,65]))
check('AI_declaration_preserved','OpenAI Codex was used' in maintext)
def count(d):
 a=[p.text for p in d.paragraphs];return len(' '.join(a[a.index('Background'):a.index('List of abbreviations')]).split())
js(Q/'word_counts.json',{'v10_main':count(oldmain),'v11_main':count(main),'abstract_words':len(' '.join(p.text for p in main.paragraphs[8:12]).split())})
unchanged=[]
for p in (OLD/'01_Upload_Files').rglob('*'):
 if p.is_file() and (U/p.relative_to(OLD/'01_Upload_Files')).exists() and sha(p)==sha(U/p.relative_to(OLD/'01_Upload_Files')):unchanged.append(str(p.relative_to(OLD/'01_Upload_Files')))
js(Q/'unchanged_upload_files.json',unchanged)
baseline=json.loads((B/'baseline_v10_manifest.json').read_text(encoding='utf-8'));check('original_v10_all_files_unchanged',all(sha(R/x['file'])==x['sha256'] for x in baseline),len(baseline))
# Visual atlas for all rendered pages; full-resolution pages remain beside it.
atlas=Q/'visual_atlas';atlas.mkdir(exist_ok=True);loc=[]
for folder in (Q/'render_verified').iterdir():
 pages=sorted(folder.glob('page-*.png'),key=lambda p:int(p.stem.split('-')[-1]))
 for start in range(0,len(pages),12):
  tilew,tileh=390,570;canvas=Image.new('RGB',(tilew*3,tileh*4),'#bbbbbb');draw=ImageDraw.Draw(canvas)
  for i,p in enumerate(pages[start:start+12]):
   im=Image.open(p).convert('RGB');im.thumbnail((tilew-8,tileh-28));x=(i%3)*tilew;y=(i//3)*tileh;canvas.paste(im,(x+4,y+24));draw.text((x+6,y+5),p.stem,fill='black')
  name=folder.name+'_'+str(start//12+1)+'.jpg';canvas.save(atlas/name,quality=92)
 pdfs=list(folder.glob('*.pdf'))
 if pdfs:
  doc=PdfReader(pdfs[0]);
  for i,pg in enumerate(doc.pages):
   t=pg.extract_text() or ''
   if any(a in t for a in ['centre-held-out','same-block analysis','Centre held out','Matched tissue block','0.132817','Scope of centre transport']):loc.append(dict(document=folder.name,page=i+1,excerpt=t[:140]))
js(Q/'changed_page_locations.json',loc);js(Q/'cross_file_consistency.json',checks)
(A/'v11修订说明与上传清单.txt').write_text('''v11修订说明
新版本保留原v10全部文件和既有数值。本轮新增基于公开处理后矩阵的中心留出可迁移性敏感性分析，以及已经完成的GSE286182同组织块资格性结果。
CCL2hi在三个留出中心的C指数增益为0.133、0.064、0.081；后两个条件bootstrap区间跨零。它补强跨中心排序表现，但不是新增独立BAL死亡验证。GSE286182两项ECM结果均未通过校正，结构方向为负，激活/重塑不稳定；这些结果完整纳入解释边界，不称保护效应或机制复现。
主稿、补充信息、STROBE、TableS2流程、SourceData、证据分级与代码同步；新正式表为Additional_file_18 TableS23和Additional_file_19 TableS24。表S23保留全部21项比较；表S24保留54块流程、7人19块主分析及全部敏感性。无新大文件下载，没有更换基因集、删除阴性或改变既有主结果。原49篇参考文献条目和编号未改。
01_Upload_Files为研究文件，含不同格式的既有图像，实际上传时按期刊选择格式，避免将同一图重复上传。02_Author_Review、QA和检索工作记录供作者审核，不直接全部上传。该包为通用修订资料包，未针对新期刊额外套用格式，未替您提交。
代码包新增Centre_transport_extension和Same_core_extension。前者从所附101个基因×176个患者的处理后表达重跑21项比较；后者从所附组织块分数重跑两个主关联、精确置换与供者bootstrap。它们不还原源研究联合归一化、不重读17.62GB完整对象；原始提取代码和完整历史输出另保留，不声称全部历史大型分析本轮重跑。
本轮增强了跨中心检验和机制边界的透明度，尚未解决独立研究的BAL死亡结局验证，也不能据此保证中科院1区或录用。
''',encoding='utf-8-sig')
print('NUMERICAL_AND_DOCUMENT_CHECKS',len(checks),'PASSED; ORIGINAL_FILES',len(baseline),'UNCHANGED; unchanged uploads',len(unchanged));print('CHANGED_PAGES',loc)
