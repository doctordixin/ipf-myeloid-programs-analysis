import fs from 'node:fs/promises';
import path from 'node:path';
import {Workbook,SpreadsheetFile} from '@oai/artifact-tool';
const B=path.join(process.cwd(),'outputs/Revision_20261028_v11'),Q=path.join(B,'QA/workbooks');
await fs.mkdir(path.join(Q,'new_sheets'),{recursive:true});
const p=JSON.parse(await fs.readFile(path.join(B,'QA/workbook_payload.json'),'utf8'));
const jobs=[['Additional_file_2_Supplementary_Table_S2.xlsx',p.flow],['Additional_file_4_Source_Data.xlsx',p.source],['Additional_file_18_Supplementary_Table_S23.xlsx',p.formal23],['Additional_file_19_Supplementary_Table_S24.xlsx',p.formal24]];
const receipt=[];
for(const [name,tabs] of jobs){
 const wb=Workbook.create();
 for(const t of tabs){
  const s=wb.worksheets.add(t.sheet),nr=t.values.length,nc=t.values[0].length;
  s.getRangeByIndexes(0,0,nr,nc).values=t.values;
  s.getRangeByIndexes(0,0,nr,nc).format={font:{name:'Arial',size:10},columnWidth:25,rowHeight:42,wrapText:true,verticalAlignment:'center'};
  s.getRangeByIndexes(0,0,1,nc).format={font:{name:'Arial',size:10,bold:true},fill:'#E7EDF2',rowHeight:72,wrapText:true};
  if(t.sheet.includes('Definitions')){s.getRangeByIndexes(0,1,nr,1).format.columnWidth=110;s.getRangeByIndexes(0,0,nr,nc).format.rowHeight=82;}
  if(t.sheet==='V11_Flow'){s.getRangeByIndexes(0,4,nr,2).format.columnWidth=70;s.getRangeByIndexes(0,0,nr,nc).format.rowHeight=90;}
  for(let j=0;j<nc;j++){
   const a=t.values.slice(1).map(x=>x[j]).filter(x=>x!==null);
   if(a.length&&a.every(x=>typeof x==='number'))s.getRangeByIndexes(1,j,nr-1,1).setNumberFormat(a.every(Number.isInteger)?'0':'0.000000');
  }
  s.getRangeByIndexes(0,nc+1,1,1).values=[['Source: '+t.source]];s.getRangeByIndexes(0,nc+1,1,1).format.columnWidth=95;
  s.freezePanes.freezeRows(1);s.showGridLines=false;
  if(!name.includes('Source_Data')){const im=await wb.render({sheetName:t.sheet,range:`A1:${String.fromCharCode(64+Math.min(nc,5))}${Math.min(nr,5)}`,scale:1});await fs.writeFile(path.join(Q,t.sheet+'.png'),new Uint8Array(await im.arrayBuffer()));}
 }
 await(await SpreadsheetFile.exportXlsx(wb)).save(path.join(Q,'new_sheets',name));
 receipt.push({name,tabs:tabs.map(x=>x.sheet)});console.log('EXPORTED',name);
}
await fs.writeFile(path.join(Q,'artifact_receipt.json'),JSON.stringify(receipt,null,2));
