"""Append artifact-authored sheets without round-tripping any original cells."""
from pathlib import Path
from copy import deepcopy
from io import BytesIO
import zipfile,shutil,posixpath,json,argparse
from lxml import etree as ET
R=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser();ap.add_argument('--revision',default='v7');ap.add_argument('--original',default='v6');ap.add_argument('--table',default='S19');args=ap.parse_args()
B=R/'outputs/Revision_20261028_v11'
O=R/'outputs/Revision_20261026_v10/01_Upload_Files';U=B/'01_Upload_Files';Q=B/'QA/workbooks/new_sheets'
NS='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
REL='http://schemas.openxmlformats.org/package/2006/relationships'
RID='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
CT='http://schemas.openxmlformats.org/package/2006/content-types'
def q(s):return '{'+NS+'}'+s
def xml(e):return ET.tostring(e,encoding='utf-8',xml_declaration=True,standalone=True)
def target(t):return t.lstrip('/') if t.startswith('/') else posixpath.normpath('xl/'+t)
def append_sheets(name):
    original=(O/name).read_bytes()
    with zipfile.ZipFile(BytesIO(original)) as old,zipfile.ZipFile(Q/name) as new:
        doc=ET.fromstring(old.read('xl/workbook.xml'));rels=ET.fromstring(old.read('xl/_rels/workbook.xml.rels'))
        content=ET.fromstring(old.read('[Content_Types].xml'))
        styles=ET.fromstring(old.read('xl/styles.xml'));added=ET.fromstring(new.read('xl/styles.xml'))
        maps={}
        # Each appended xf keeps its own font/fill/border and base-style index.
        nf=styles.find(q('numFmts'))
        if nf is None:nf=ET.Element(q('numFmts'),count='0');styles.insert(0,nf)
        used=[int(x.get('numFmtId')) for x in nf]
        next_id=max([163]+used)+1;num_map={}
        for e in added.find(q('numFmts')) or []:
            v=deepcopy(e);num_map[int(e.get('numFmtId'))]=next_id;v.set('numFmtId',str(next_id));nf.append(v);next_id+=1
        nf.set('count',str(len(nf)))
        for key in ['fonts','fills','borders','cellStyleXfs','cellXfs']:
            dst=styles.find(q(key));src=added.find(q(key))
            assert dst is not None and src is not None,key
            maps[key]={i:len(dst)+i for i in range(len(src))}
            for e in src:
                v=deepcopy(e)
                if key in ['cellStyleXfs','cellXfs']:
                    for a,group in [('fontId','fonts'),('fillId','fills'),('borderId','borders')]:
                        if v.get(a) is not None:v.set(a,str(maps[group][int(v.get(a))]))
                    if v.get('numFmtId') is not None:
                        idx=int(v.get('numFmtId'));v.set('numFmtId',str(num_map.get(idx,idx)))
                    if v.get('xfId') is not None:v.set('xfId',str(maps['cellStyleXfs'][int(v.get('xfId'))]))
                dst.append(v)
            dst.set('count',str(len(dst)))
        a_dx=added.find(q('dxfs'));assert a_dx is None or len(a_dx)==0
        sst=ET.fromstring(new.read('xl/sharedStrings.xml')) if 'xl/sharedStrings.xml' in new.namelist() else []
        ndoc=ET.fromstring(new.read('xl/workbook.xml'))
        nrels={x.get('Id'):target(x.get('Target')) for x in ET.fromstring(new.read('xl/_rels/workbook.xml.rels'))}
        sheets=doc.find(q('sheets'));present={s.get('name') for s in sheets}
        ids={e.get('Id') for e in rels};sid=max(int(s.get('sheetId')) for s in sheets)
        updates={};record=[]
        for i,s in enumerate(ndoc.find(q('sheets')),1):
            assert s.get('name') not in present
            namepart=f'xl/worksheets/{args.revision}_extension_{i}.xml'
            assert namepart not in old.namelist()
            sheet=ET.fromstring(new.read(nrels[s.get('{'+RID+'}id')]))
            # Inline the new strings, leaving every original shared-string index intact.
            for c in sheet.iter(q('c')):
                assert c.find(q('f')) is None,'New tabs must contain recorded values, not cross-workbook formulas'
                if c.get('s') is not None:c.set('s',str(maps['cellXfs'][int(c.get('s'))]))
                if c.get('t')=='s':
                    v=c.find(q('v'));item=sst[int(v.text)];c.remove(v);c.set('t','inlineStr')
                    inline=ET.SubElement(c,q('is'))
                    for child in item:inline.append(deepcopy(child))
            for row in sheet.iter(q('row')):
                if row.get('s') is not None:row.set('s',str(maps['cellXfs'][int(row.get('s'))]))
            for col in sheet.iter(q('col')):
                if col.get('style') is not None:col.set('style',str(maps['cellXfs'][int(col.get('style'))]))
            assert not sheet.findall('.//'+q('conditionalFormatting'))
            assert not sheet.findall('.//'+q('drawing'))
            rid=f'rId{args.revision.upper()}Extension{i}';assert rid not in ids;ids.add(rid);sid+=1
            n=deepcopy(s);n.set('sheetId',str(sid));n.set('{'+RID+'}id',rid);sheets.append(n)
            ET.SubElement(rels,'{'+REL+'}Relationship',Id=rid,Type=RID+'/worksheet',Target=namepart[3:])
            ET.SubElement(content,'{'+CT+'}Override',PartName='/'+namepart,ContentType='application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml')
            updates[namepart]=xml(sheet);record.append(s.get('name'))
        updates.update({'xl/workbook.xml':xml(doc),'xl/_rels/workbook.xml.rels':xml(rels),'xl/styles.xml':xml(styles),'[Content_Types].xml':xml(content)})
        with zipfile.ZipFile(U/name,'w',zipfile.ZIP_DEFLATED) as dest:
            for info in old.infolist():dest.writestr(info,updates.pop(info.filename,old.read(info.filename)))
            for k,v in updates.items():dest.writestr(k,v)
    return {'file':name,'new_tabs':record,'original_worksheets':'all original worksheet XML parts retained byte-for-byte','source':'artifact-tool-authored new_sheets'}

receipt=[]
for name in ["Additional_file_2_Supplementary_Table_S2.xlsx","Additional_file_4_Source_Data.xlsx"]:receipt.append(append_sheets(name))
for name in ["Additional_file_18_Supplementary_Table_S23.xlsx","Additional_file_19_Supplementary_Table_S24.xlsx"]:shutil.copy2(Q/name,U/name)
(B/"QA/workbooks/merge_receipt.json").write_text(json.dumps(receipt,indent=2),encoding="utf-8")
print("V11 SHEETS MERGED")
