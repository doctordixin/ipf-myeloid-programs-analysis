from pathlib import Path
import json,hashlib,gzip,shutil
import numpy as np,pandas as pd
R=Path(__file__).resolve().parents[1];B=R/'outputs/Revision_20261028_v11';E=B/'Reproducibility/Centre_transport_extension';I=E/'inputs';I.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=R/'outputs/Revision_20261026_v10'
manifest=[{'file':str(p.relative_to(R)),'sha256':sha(p)} for p in old.rglob('*') if p.is_file()]
(B/'baseline_v10_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
s=pd.read_csv(R/'data/derived/gse70866_mlm_state_scores.csv');s=s[s.diagnosis.str.lower().eq('ipf')][['sample_id','platform','cohort','gap','time','event']].copy();s.cohort=s.cohort.str.title()
assert len(s)==176 and s.event.sum()==100 and not s.sample_id.duplicated().any()
assert np.isfinite(s[['gap','time','event']]).all().all() and (s.time>0).all()
z=np.load(R/'data/derived/gse70866_gene_expression.npz',allow_pickle=False)
sig=json.loads((R/'data/derived/mlm_six_state_signatures_frozen.json').read_text(encoding='utf-8'))['states']
common=set(z['GPL14550_genes'])&set(z['GPL17077_genes']);used={k:[g for g in v if g in common] for k,v in sig.items()}
assert [len(used[k]) for k in ['MLM0','CCL2hi','MLM1','IL1Bhi','SPP1hi','CXCL10hi']]==[14,19,18,18,18,15]
genes=sorted(set(sum(used.values(),[])));X=np.empty((len(s),len(genes)))
for j,row in enumerate(s.itertuples()):
 p=row.platform;lookup={g:i for i,g in enumerate(z[p+'_genes'])};col=list(z[p+'_samples']).index(row.sample_id);X[j]=z[p+'_expression'][[lookup[g] for g in genes],col]
assert np.isfinite(X).all()
np.savez_compressed(I/'prepared_expression.npz',expression=X,genes=np.array(genes,dtype='U64'))
s.to_csv(I/'clinical.csv',index=False)
(I/'frozen_available_genes.json').write_text(json.dumps(used,indent=2),encoding='utf-8')
processing=[]
for p in (R/'data/raw/GSE70866').glob('*matrix*'):
 with gzip.open(p,'rt',encoding='utf-8') as f:
  for l in f:
   if l.startswith('!Sample_data_processing'):processing.append({'file':p.name,'processing':l.split('\t')[1].strip(),'sha256':sha(p)});break
plan={'status':'locally locked after source QC and prior pooled results, before new held-out fits; not preregistration',
 'primary_focus':'CCL2hi transport beyond GAP, acknowledging prior outcome-based prioritisation',
 'all_models':'GAP only, plus each frozen six-state score or frozen standardized SPP1hi-minus-CXCL10hi contrast separately; report all21 fold-marker comparisons',
 'outer_folds':['Freiburg','Siena','Leuven'],'fit':'unpenalized Cox with training-centre-stratified baseline hazards; continuous GAP and one program; no test-outcome refit',
 'score':'gene mean/sample SD from pooled training patients only; arithmetic mean over frozen available genes; module and balance scaling from training only; same transform applied to test',
 'source_limit':'Original deposited matrices normalized/filtered with all IPF and controls; cannot claim untouched raw-data preprocessing or new independent-study validation',
 'metric':'Harrell concordance within held-out centre; delta versus GAP; no across-centre pooled C due to separate model scales',
 'intervals':'2000 paired patient-bootstrap test samples, fixed trained models, percentile95%; conditional on fitted model/preprocessing; not training/selection uncertainty; pointwise not simultaneous',
 'no_tests':'No new discrimination hypothesis tests, P values, multiplicity claims or cutpoint optimization; all21 pointwise intervals shown',
 'no_absolute_risk':'No absolute risk/calibration/Brier/DCA because stratified training has no held-out-centre baseline hazard and assay/reference is not deployable',
 'seed':20261028,'no_gene_change':True,'source_processing':processing,'inputs':{p.name:sha(p) for p in I.iterdir() if p.is_file()}}
(E/'analysis_plan_locked.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding='utf-8')
print('PREPARED',X.shape,'PLAN LOCKED; no models fit')
