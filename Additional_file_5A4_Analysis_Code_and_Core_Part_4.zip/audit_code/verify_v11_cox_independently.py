"""Independent Efron partial-likelihood checks of trained coefficients (no new hypotheses)."""
from pathlib import Path
import json
import numpy as np,pandas as pd
from scipy.optimize import minimize
R=Path(__file__).resolve().parents[1];E=R/'outputs/Revision_20261028_v11/Reproducibility/Centre_transport_extension';I=E/'inputs';O=E/'results'
c=pd.read_csv(I/'clinical.csv');z=np.load(I/'prepared_expression.npz',allow_pickle=False);X=z['expression'];genes=z['genes'].tolist();sig=json.loads((I/'frozen_available_genes.json').read_text(encoding='utf-8'));par=json.loads((O/'training_transform_parameters.json').read_text(encoding='utf-8'));fits=pd.read_csv(O/'training_coefficients.csv');rows=[]
for centre in ['Freiburg','Siena','Leuven']:
 tr=c.cohort.ne(centre).to_numpy();p=par[centre];Z=(X-np.array(p['gene_mean']))/np.array(p['gene_sd']);s={}
 for state,gs in sig.items():
  raw=Z[:,[genes.index(g) for g in gs]].mean(1);s[state]=(raw-p['modules'][state]['mean'])/p['modules'][state]['sd']
 a=s['SPP1hi']-s['CXCL10hi'];s['SPP1hi_minus_CXCL10hi']=(a-p['balance']['mean'])/p['balance']['sd']
 for marker in s:
  A=np.column_stack([c.gap,s[marker]])[tr];A-=A.mean(0);t=c.time.to_numpy()[tr];e=c.event.to_numpy()[tr];g=c.cohort.to_numpy()[tr]
  def objective(b):
   eta=A@b;v=0.;grad=np.zeros(2)
   for group in np.unique(g):
    mask=g==group
    for time in np.unique(t[mask&(e==1)]):
     events=mask&(t==time)&(e==1);risk=mask&(t>=time);m=int(events.sum());shift=eta[risk].max();w=np.exp(eta-shift);S=w[risk].sum();D=w[events].sum();S1=(w[risk,None]*A[risk]).sum(0);D1=(w[events,None]*A[events]).sum(0)
     v+=eta[events].sum();grad+=A[events].sum(0)
     for l in range(m):
      den=S-l/m*D;v-=np.log(den)+shift;grad-=(S1-l/m*D1)/den
   return -v,-grad
  original=fits[(fits.heldout_centre==centre)&(fits.marker==marker)].iloc[0];b=np.array([original.gap_beta,original.program_beta]);res=minimize(objective,np.zeros(2),method='BFGS',jac=True,options={'gtol':1e-7});diff=float(np.max(np.abs(res.x-b)));grad=float(np.max(np.abs(objective(b)[1])));assert diff<.001 and grad<.01,(centre,marker,diff,grad)
  rows.append(dict(heldout_centre=centre,marker=marker,max_coefficient_difference=diff,original_gradient_max=grad,optimizer_success=bool(res.success)))
pd.DataFrame(rows).to_csv(O/'independent_Efron_coefficient_check.csv',index=False)
print('INDEPENDENT_EFRON_CHECK',max(x['max_coefficient_difference'] for x in rows),max(x['original_gradient_max'] for x in rows))
