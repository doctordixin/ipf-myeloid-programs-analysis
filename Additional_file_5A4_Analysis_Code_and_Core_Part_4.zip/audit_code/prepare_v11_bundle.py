from pathlib import Path
import shutil,json,hashlib
import pandas as pd,numpy as np
R=Path(__file__).resolve().parents[1];B=R/'outputs/Revision_20261028_v11';U=B/'01_Upload_Files';Q=B/'QA';A=B/'02_Author_Review';OLD=R/'outputs/Revision_20261026_v10'
for p in [Q,A]:p.mkdir(exist_ok=True)
assert not U.exists();shutil.copytree(OLD/'01_Upload_Files',U)
E=B/'Reproducibility/Same_core_extension';I=E/'inputs';I.mkdir(parents=True,exist_ok=True)
S=R/'outputs/GSE286182_same_core_analysis_20261028'
for p in S.iterdir():
 if p.is_file():shutil.copy2(p,I/p.name)
shutil.copy2(R/'work/replay_v11_same_core_primary.py',E/'replay_primary.py')
shutil.copytree(R/'outputs/GSE286182_Complete_Admission_and_Exploratory_20261028/Code',E/'original_extraction_and_analysis')
shutil.copy2(R/'outputs/GSE286182_Complete_Admission_and_Exploratory_20261028/完整核查与探索性结果说明.txt',A/'GSE286182既有完整结果说明.txt')
shutil.copytree(R/'outputs/BAL_mortality_rescreen_20261028',A/'BAL_resource_audit',ignore=shutil.ignore_patterns('sources','audit_code'))
def tab(sheet,df,source):
 df=df.astype(object).where(pd.notnull(df),None);return {'sheet':sheet,'values':[list(df.columns)]+df.values.tolist(),'source':source}
C=B/'Reproducibility/Centre_transport_extension/results'
metrics=pd.read_csv(C/'heldout_concordance.csv');diag=pd.read_csv(C/'score_transport_diagnostics.csv')
definitions=pd.DataFrame([
 ['Scope','Retrospective centre-held-out transport sensitivity on author-processed expression; not an independent-study validation'],
 ['Normalization','Source investigators quantile-normalized all IPF/controls before deposition. New gene/module parameters were estimated only in training centres. Original within-centre scores were not overwritten.'],
 ['Model','Train on two centres: centre-stratified Cox, continuous GAP alone or GAP plus one fixed program; predict third-centre linear predictor without outcome fitting.'],
 ['Intervals','2000 paired held-out-patient bootstrap draws, fixed trained models; pointwise95% intervals; exclude training/selection uncertainty and are not multiplicity-adjusted'],
 ['Coverage','Original canonical marker lists unchanged; available common genes: MLM0 14, CCL2hi19, MLM1 18, IL1Bhi18, SPP1hi18, CXCL10hi15'],
 ['No absolute risk','No held-out-centre baseline hazard, clinical calibration, Brier score, cutpoint or clinical utility claim'],
 ['Interpretation','All21 centre-program comparisons retained; CCL2hi was prioritized after prior pooled outcome screening. No new mortality patients or deaths.'],
 ],columns=['field','definition'])
formal23=[tab('S23_Heldout_C',metrics,'Centre_transport_extension/results/heldout_concordance.csv'),tab('S23_Score_Diagnostics',diag,'Centre_transport_extension/results/score_transport_diagnostics.csv'),tab('S23_Definitions',definitions,'Centre_transport_extension/analysis_plan_locked.json')]
formal24=[]
for sheet,file in [('S24_Primary','primary_results.csv'),('S24_All54_Flow','all54_core_scores_flow_depth_composition.csv'),('S24_Sensitivities','all_deterministic_sensitivities.csv'),('S24_Donor_Deletion','leave_one_donor_out_all.csv'),('S24_Gene_Deletion','leave_one_gene_out_all.csv'),('S24_Sampling_Summary','sampling_processing_summary.csv'),('S24_AllSampling','all_sampling_coefficients.csv'),('S24_Gene_QC','locked_gene_variance_diagnostics.csv')]:formal24.append(tab(sheet,pd.read_csv(S/file),'Same_core_extension/inputs/'+file))
flow=pd.DataFrame([
 ['GSE70866 centre transport','Existing mortality source','176 IPF /100 deaths','Freiburg62/45; Siena50/31; Leuven64/24','3 train2/test1 folds; the same176 patients','No new recruitment; original joint source normalization retained','Table S23'],
 ['GSE286182 inVivo','Matched tissue-block qualification','19 donors /54 blocks','9 IPF/24 blocks;10 controls/30 blocks','IPF >=50 MacAlveolar and fibroblasts:9 donors21 blocks; within-donor7/19','At least2 eligible blocks and varying microCT; two donors excluded only from within-donor analysis','Table S24'],
 ],columns=['resource','role','available','grouping','analysis','restriction','output'])
payload={'flow':[tab('V11_Flow',flow,'Original source metadata, RNA admission and centre transport gate')], 'source':formal23[:2]+formal24[:7], 'formal23':formal23,'formal24':formal24}
(Q/'workbook_payload.json').write_text(json.dumps(payload,ensure_ascii=False,allow_nan=False),encoding='utf-8')
print('COPIED ORIGINAL UPLOADS; prepared workbook payload')
