"""Check the reporting index only; no biological validation is implied."""
from pathlib import Path
import csv,hashlib,json
p=Path(__file__).resolve().parent
m=json.loads((p/'reporting_manifest.json').read_text(encoding='utf8'))
f=p/'source_analysis_roles.csv'
assert hashlib.sha256(f.read_bytes()).hexdigest()==m['sha256_csv']
with f.open(encoding='utf8',newline='') as h: rows=list(csv.reader(h))
assert len(rows)==m['source_rows']+1 and all(len(r)==6 for r in rows)
assert m['new_association_tests'] is False
print('PASS: 19 source/analysis-role rows; no new association tests')
