v12 reporting revision

No study results or existing analysis scripts were changed. All original v11 archive entries remain byte-identical. The new reporting index matches the complete original Table 1 and the submitted Supplementary Table S25. Rows are sources/analysis roles, not independent additive cohorts.

Run from any working directory:
python Reporting_revision_v12/verify_reporting_index.py

Existing prepared-input replays remain:
python portable_replay.py --output fresh_replay_output
python Centre_transport_extension/replay.py
python Same_core_extension/replay_primary.py

Install the declared requirements for each module in your own environment. The main replay requires a new output directory. The latter two modules write their own replay/result folders. Preserve an original copy before running them. Numerical replay does not establish independent clinical validation or a complete reconstruction of every raw-data preprocessing stage.

The v12 author report records the completed consistency, frozen-output comparison and rendering checks. Original AI-use, ethics, funding and author declarations remain unchanged.
