"""Patient-unit exploratory validation; frozen plan precedes scoring. No raw downloads."""
from pathlib import Path
import hashlib, itertools, json, platform, sys
import numpy as np
import pandas as pd
import scipy
from scipy import stats

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'outputs/validation_qc_20261022'
OUT = ROOT / 'outputs/patient_region_analysis_20261022'
PLAN_HASH = 'fffd28cff1567ef152cf2d8b8668f301e756acb53cabae029e44b40d38e6526b'
SIGNATURE = ROOT / 'data/derived/mlm_six_state_signatures_frozen.json'
MANUSCRIPT = ROOT/'manuscript/Manuscript.docx'
BASE_MANUSCRIPT = '3b154777cb704d4fe24f971fd76cfe14d0d11bb9ebb15b250d02f44dd127db96'
STATES = json.loads(SIGNATURE.read_text(encoding='utf-8'))['states']
ENDPOINTS = list(STATES) + ['SPP1_CXCL10_balance']
MAC = ['Macrophages', 'Proliferating Macrophages']
NORMAL = 'Normal Alveolar and Other'
REGIONS = ['Diseased', NORMAL]
INPUTS = [SIGNATURE, OUT/'analysis_plan_locked.txt', Path(__file__).resolve()]
CALIBRATIONS = {}
CHECKS = []

def sha(path):
    return hashlib.file_digest(open(path, 'rb'), 'sha256').hexdigest()

def load(name):
    p = SRC/name
    INPUTS.append(p)
    return pd.read_csv(p)

def save(df, name):
    df.to_csv(OUT/name, index=False, encoding='utf-8-sig', float_format='%.12g')

def bh(p):
    p = np.asarray(p, dtype=float)
    q = np.full(len(p), np.nan)
    ix = np.flatnonzero(np.isfinite(p))
    order = ix[np.argsort(p[ix])]
    if len(order):
        q[order] = np.minimum(1, np.minimum.accumulate((p[order]*len(order)/np.arange(1,len(order)+1))[::-1])[::-1])
    return q

def scores(x, reference, key):
    """Fixed scaling reused on sensitivity subsets; directory missing != zero."""
    cal = {}
    z = pd.DataFrame(index=x.index)
    for state, genes in STATES.items():
        gs = [g for g in genes if g in x.columns]
        mu, sd = reference[gs].mean(), reference[gs].std(ddof=1)
        assert reference[gs].notna().all().all()
        def raw(d):
            return ((d[gs]-mu)/sd.replace(0, np.inf)).mean(axis=1)
        r = raw(reference)
        rm, rs = float(r.mean()), float(r.std(ddof=1))
        assert rs > 0
        z[state] = (raw(x)-rm)/rs
        cal[state] = dict(available=gs, missing=[g for g in genes if g not in gs],
                          gene_mean=mu.to_dict(), gene_sd=sd.to_dict(),
                          zero_sd=sd[sd==0].index.tolist(), module_mean=rm, module_sd=rs)
    rz = pd.DataFrame(index=reference.index)
    for state in STATES:
        c = cal[state]
        rz[state] = (((reference[c['available']]-pd.Series(c['gene_mean']))/
                     pd.Series(c['gene_sd']).replace(0,np.inf)).mean(axis=1)-c['module_mean'])/c['module_sd']
    br = rz.SPP1hi-rz.CXCL10hi
    bm, bs = float(br.mean()), float(br.std(ddof=1))
    z[ENDPOINTS[-1]] = (z.SPP1hi-z.CXCL10hi-bm)/bs
    cal['balance'] = dict(mean=bm, sd=bs)
    CALIBRATIONS[key] = cal
    CHECKS.append(dict(check='reference_center_and_scale', measurement=key,
                       max_abs_mean=float(rz.mean().abs().max()),
                       max_abs_sd_error=float((rz.std(ddof=1)-1).abs().max())))
    return z

def welch(a,b):
    a,b = np.asarray(a,float),np.asarray(b,float)
    n,m = len(a),len(b)
    if min(n,m)<2:
        return dict(n_ipf=n,n_control=m,delta=np.nan,ci_low=np.nan,ci_high=np.nan,p=np.nan,p_permutation=np.nan)
    va,vb = a.var(ddof=1)/n,b.var(ddof=1)/m
    se=np.sqrt(va+vb); df=(va+vb)**2/(va**2/(n-1)+vb**2/(m-1))
    delta=a.mean()-b.mean(); margin=stats.t.ppf(.975,df)*se
    perm=stats.permutation_test((a,b),lambda x,y: np.mean(x)-np.mean(y),
                                n_resamples=10000, alternative='two-sided', rng=np.random.default_rng(20261022))
    pooled=np.sqrt(((n-1)*a.var(ddof=1)+(m-1)*b.var(ddof=1))/(n+m-2))
    return dict(n_ipf=n,n_control=m,mean_ipf=a.mean(),mean_control=b.mean(),delta=delta,
                ci_low=delta-margin,ci_high=delta+margin,p=float(stats.ttest_ind(a,b,equal_var=False).pvalue),
                p_permutation=float(perm.pvalue),hedges_g=delta/pooled*(1-3/(4*(n+m-2)-1)),
                shapiro_ipf_p=float(stats.shapiro(a).pvalue) if n>=3 else np.nan,
                shapiro_control_p=float(stats.shapiro(b).pvalue) if m>=3 else np.nan,
                variance_ratio=max(a.var(ddof=1),b.var(ddof=1))/max(min(a.var(ddof=1),b.var(ddof=1)),1e-20))

def group_test(d, family, columns=ENDPOINTS, min_n=2):
    rows=[]
    for e in columns:
        r=welch(d.loc[d.diagnosis=='IPF',e],d.loc[d.diagnosis=='Control',e])
        r['status']='exploratory_test' if min(r['n_ipf'],r['n_control'])>=min_n else 'descriptive_only_below_minimum'
        if r['status'].startswith('descriptive_only'):
            for field in ['p','p_permutation','ci_low','ci_high']:
                r[field]=np.nan
        rows.append(dict(family=family,endpoint=e,**r))
    o=pd.DataFrame(rows); o['q_BH']=bh(o.p); o['q_permutation_BH']=bh(o.p_permutation)
    return o

def ols(d, family, include_source):
    x=pd.DataFrame({'intercept':1., 'IPF':(d.diagnosis=='IPF').astype(float),
                    'log2_mean_umi':np.log2(d.total_umi/d.n_cells)})
    x['log2_mean_umi']-=x['log2_mean_umi'].mean()
    if include_source:
        x=pd.concat([x,pd.get_dummies(d.source,prefix='source',drop_first=True,dtype=float)],axis=1)
    X=x.to_numpy(float); rank=np.linalg.matrix_rank(X); n,k=X.shape
    if rank<k or n-k<3:
        return pd.DataFrame([dict(family=family,status='not_estimable',n=n,rank=rank,k=k)])
    inv=np.linalg.inv(X.T@X); hat=np.einsum('ij,jk,ik->i',X,inv,X)
    rows=[]; residual_rows=[]
    for e in ENDPOINTS:
        y=d[e].to_numpy(); beta=inv@X.T@y; residual=y-X@beta
        cov=inv@X.T@np.diag((residual/(1-hat))**2)@X@inv
        se=np.sqrt(cov[1,1]); margin=stats.t.ppf(.975,n-k)*se
        rows.append(dict(family=family,endpoint=e,status='exploratory_HC3_t',n=n,k=k,
                         delta=beta[1],ci_low=beta[1]-margin,ci_high=beta[1]+margin,
                         p=2*stats.t.sf(abs(beta[1]/se),n-k),max_leverage=max(hat),
                         design_condition_number=np.linalg.cond(X),residual_shapiro_p=stats.shapiro(residual).pvalue,
                         residual_depth_spearman=stats.spearmanr(np.abs(residual),x.log2_mean_umi).statistic))
        for i,donor in enumerate(d.donor):
            residual_rows.append(dict(family=family,endpoint=e,donor=donor,residual=residual[i],
                                      fitted=(X@beta)[i],leverage=hat[i]))
    save(pd.DataFrame(residual_rows),f'diagnostics_{family}.csv')
    o=pd.DataFrame(rows); o['q_BH']=bh(o.p)
    return o

def single_cell():
    inv=load('single_cell_donor_celltype_inventory.csv')
    gen=load('single_cell_gene_detection_by_donor_celltype.csv')
    inv=inv[inv.diagnosis.isin(['IPF','Control'])].copy()
    assert inv.groupby('donor').diagnosis.nunique().max()==1
    save(inv.drop_duplicates('donor').groupby(['diagnosis','source']).size().rename('n_donors').reset_index(),
         'single_cell_donor_source_balance.csv')
    donor=inv.groupby(['donor','diagnosis','source'],as_index=False).agg(all_cells=('n_cells','sum'),all_umi=('total_umi','sum'))
    for name,types in [('macrophages',MAC),('monocytes',['Monocytes'])]:
        counts=inv[inv.celltype.isin(types)].groupby('donor').n_cells.sum()
        donor[name+'_cells']=donor.donor.map(counts).fillna(0)
        donor[name+'_fraction']=donor[name+'_cells']/donor.all_cells
    donor['macrophages_myeloid_fraction']=donor.macrophages_cells/(donor.macrophages_cells+donor.monocytes_cells)
    donor['monocytes_myeloid_fraction']=1-donor.macrophages_myeloid_fraction
    save(donor,'single_cell_donor_composition.csv')
    composition=group_test(donor,'composition_all_cells',['macrophages_fraction','monocytes_fraction'])
    composition=pd.concat([composition,group_test(donor[donor.source=='Vanderbilt'],'composition_Vanderbilt',
                                                  ['macrophages_fraction','monocytes_fraction'])],ignore_index=True)
    save(composition,'single_cell_composition_tests.csv')
    tests=[]; adjusted=[]; inventories=[]; allvalues=[]
    for name,types in [('macrophages',MAC),('monocytes',['Monocytes'])]:
        meta=inv[inv.celltype.isin(types)].groupby(['donor','diagnosis','source'],as_index=False).agg(n_cells=('n_cells','sum'),total_umi=('total_umi','sum'))
        g=gen[gen.donor.isin(meta.donor)&gen.celltype.isin(types)&gen.directory_present].groupby(['donor','gene']).umi_sum.sum().unstack('gene')
        g=g.reindex(meta.donor).fillna(0); g.index=meta.index
        assert (g.sum(axis=1)<=meta.total_umi).all()
        keep=meta.n_cells>=50
        for pseudo in [1,.1]:
            x=np.log2(g.div(meta.total_umi,axis=0)*1e6+pseudo)
            z=scores(x,x[keep],f'sc_{name}_pseudocount_{pseudo}')
            d=pd.concat([meta,z],axis=1)
            d['compartment']=name; d['pseudocount']=pseudo
            allvalues.append(d)
            for threshold in ([50,20,100] if pseudo==1 else [50]):
                q=d[d.n_cells>=threshold]
                fam=f'{name}_min{threshold}_pseudocount{pseudo}'
                inventories.append(dict(family=fam,n_ipf=(q.diagnosis=='IPF').sum(),n_control=(q.diagnosis=='Control').sum(),
                                        excluded_donors=';'.join(d.loc[d.n_cells<threshold,'donor'])))
                if min(q.groupby('diagnosis').size())>=5:
                    tests.append(group_test(q,fam))
            if pseudo==1:
                q=d[keep]
                tests.append(group_test(q[q.source=='Vanderbilt'],name+'_Vanderbilt_only',min_n=5 if name=='monocytes' else 2))
                adjusted.extend([ols(q,name+'_depth',False),ols(q,name+'_depth_source',True)])
                corr=[]
                for e in ENDPOINTS:
                    for v in ['n_cells','mean_umi','fraction']:
                        w=q.n_cells if v=='n_cells' else (q.total_umi/q.n_cells if v=='mean_umi' else q.donor.map(donor.set_index('donor')[name+'_fraction']))
                        rho,p=stats.spearmanr(q[e],w)
                        corr.append(dict(endpoint=e,variable=v,rho=rho,p_descriptive=p,n=len(q)))
                save(pd.DataFrame(corr),f'{name}_depth_composition_correlations.csv')
                if name=='macrophages':
                    ordinary=inv[inv.celltype=='Macrophages'].set_index('donor').reindex(meta.donor)
                    gg=gen[(gen.celltype=='Macrophages')&gen.donor.isin(meta.donor)&gen.directory_present].pivot(index='donor',columns='gene',values='umi_sum').reindex(meta.donor).fillna(0)
                    xx=np.log2(gg.div(ordinary.total_umi,axis=0)*1e6+1)
                    # Apply primary union calibration, do not refit on ordinary cells.
                    xx.index=meta.index
                    zz=apply_calibration(xx,CALIBRATIONS['sc_macrophages_pseudocount_1'])
                    dd=pd.concat([meta.copy(),zz],axis=1); dd['n_cells']=ordinary.n_cells.to_numpy(); dd['total_umi']=ordinary.total_umi.to_numpy()
                    dd=dd[dd.n_cells>=50]
                    tests.append(group_test(dd,'ordinary_macrophages_min50_fixed_union_scale'))
                    save(dd,'ordinary_macrophages_donor_scores.csv')
    save(pd.concat(tests,ignore_index=True),'single_cell_program_tests.csv')
    save(pd.concat(adjusted,ignore_index=True),'single_cell_adjusted_tests.csv')
    save(pd.DataFrame(inventories),'single_cell_threshold_inventory.csv')
    save(pd.concat(allvalues,ignore_index=True),'single_cell_donor_program_scores.csv')

def apply_calibration(x,cal):
    z=pd.DataFrame(index=x.index)
    for state in STATES:
        c=cal[state]
        z[state]=(((x[c['available']]-pd.Series(c['gene_mean']))/pd.Series(c['gene_sd']).replace(0,np.inf)).mean(axis=1)-c['module_mean'])/c['module_sd']
    z[ENDPOINTS[-1]]=(z.SPP1hi-z.CXCL10hi-cal['balance']['mean'])/cal['balance']['sd']
    return z

def paired_test(d,family):
    rows=[]
    for e in ENDPOINTS:
        v=d[e].to_numpy(); n=len(v); delta=np.mean(v)
        permutations=np.array(list(itertools.product([-1,1],repeat=n)))
        p=float(np.mean(np.abs((permutations*v).mean(axis=1))>=abs(delta)-1e-12))
        margin=stats.t.ppf(.975,n-1)*stats.sem(v) if n>1 else np.nan
        rows.append(dict(family=family,endpoint=e,n_donors=n,delta=delta,ci_low=delta-margin,ci_high=delta+margin,
                         p=p,n_positive=int((v>0).sum()),n_negative=int((v<0).sum()),
                         min_donor_delta=v.min(),max_donor_delta=v.max(),
                         leave_one_out_min=min(np.delete(v,i).mean() for i in range(n)) if n>1 else np.nan,
                         leave_one_out_max=max(np.delete(v,i).mean() for i in range(n)) if n>1 else np.nan))
    o=pd.DataFrame(rows); o['q_BH']=bh(o.p)
    return o

def spatial():
    spot=load('spatial_spot_qc.csv')
    gen=load('spatial_gene_detection_by_pathology.csv')
    keys=['sample','donor','condition','annotation']
    meta=spot.dropna(subset=['annotation']).groupby(keys,as_index=False).agg(n_spots=('barcode','size'),total_umi=('n_umi','sum'),
                         mean_umi=('n_umi','mean'),median_umi=('n_umi','median'),mean_genes=('n_genes','mean'),
                         mean_pct_mt=('pct_mt','mean'),low_RIN_block=('low_RIN_block','max'))
    assert gen.groupby(keys).n_spots.nunique().max()==1
    check=meta.merge(gen.groupby(keys,as_index=False).n_spots.first(),on=keys,suffixes=('_qc','_gene'))
    assert (check.n_spots_qc==check.n_spots_gene).all()
    save(meta,'spatial_all_region_inventory.csv')
    g=gen[gen.directory_present].pivot(index=keys,columns='gene',values='umi_sum').reindex(pd.MultiIndex.from_frame(meta[keys]))
    assert not g.isna().any().any(); g.index=meta.index
    assert (g.sum(axis=1)<=meta.total_umi).all()
    paired_samples=meta[(meta.condition=='IPF')&meta.annotation.isin(REGIONS)&(meta.n_spots>=50)].groupby('sample').annotation.nunique()
    paired_samples=paired_samples[paired_samples==2].index
    ref=(meta.condition=='IPF')&meta['sample'].isin(paired_samples)&meta.annotation.isin(REGIONS)&(meta.n_spots>=50)
    tests=[]; deltas=[]; inventory=[]; allscores=[]; slice_deltas=[]
    for pseudo in [1,.1]:
        x=np.log2(g.div(meta.total_umi,axis=0)*1e6+pseudo)
        z=scores(x,x[ref],f'spatial_pseudocount_{pseudo}')
        d=pd.concat([meta,z],axis=1); d['pseudocount']=pseudo; allscores.append(d)
        for threshold in ([50,20,100] if pseudo==1 else [50]):
            for low in ([False,True] if threshold==50 and pseudo==1 else [False]):
                q=d[(d.condition=='IPF')&d.annotation.isin(REGIONS)&(d.n_spots>=threshold)].copy()
                if low:
                    q=q[~q.low_RIN_block]
                eligible_regions=q.copy()
                for method in (['matched_sections','all_regions'] if threshold==50 and pseudo==1 else ['matched_sections']):
                    q=eligible_regions.copy()
                    fam=f'{method}_min{threshold}_pseudocount{pseudo}'+('_exclude_lowRIN' if low else '')
                    if method=='matched_sections':
                        valid=q.groupby('sample').annotation.nunique(); valid=valid[valid==2].index
                        q=q[q['sample'].isin(valid)]
                        a=q[q.annotation=='Diseased'].set_index(['donor','sample'])
                        b=q[q.annotation==NORMAL].set_index(['donor','sample'])
                        dd=a[ENDPOINTS+['mean_umi','mean_genes']]-b[ENDPOINTS+['mean_umi','mean_genes']]
                        dd['log2_depth_ratio']=np.log2(a.mean_umi/b.mean_umi)
                        dd=dd.reset_index(); dd['family']=fam; slice_deltas.append(dd)
                        v=dd.groupby('donor',as_index=False)[ENDPOINTS+['log2_depth_ratio']].mean()
                    else:
                        a=q.groupby(['donor','annotation'])[ENDPOINTS].mean()
                        v=(a.xs('Diseased',level='annotation')-a.xs(NORMAL,level='annotation')).dropna().reset_index()
                    v['family']=fam; deltas.append(v)
                    tests.append(paired_test(v,fam))
                    inventory.append(dict(family=fam,n_donors=len(v),n_sections=q['sample'].nunique(),
                                          n_region_units=len(q),n_spots=int(q.n_spots.sum()),
                                          lowRIN_section_included=bool(q.low_RIN_block.any())))
    save(pd.concat(allscores,ignore_index=True),'spatial_region_program_scores.csv')
    save(pd.concat(tests,ignore_index=True),'spatial_region_tests.csv')
    save(pd.concat(deltas,ignore_index=True),'spatial_donor_region_differences.csv')
    save(pd.concat(slice_deltas,ignore_index=True),'spatial_matched_slice_differences.csv')
    save(pd.DataFrame(inventory),'spatial_analysis_inventory.csv')
    audit=pd.DataFrame(inventory).set_index('family')
    assert audit.loc['all_regions_min50_pseudocount1','n_sections']==12
    assert audit.loc['all_regions_min50_pseudocount1_exclude_lowRIN','n_sections']==11
    assert audit.loc['matched_sections_min50_pseudocount1','n_sections']==8
    assert audit.loc['all_regions_min50_pseudocount1','lowRIN_section_included']
    assert not audit.loc['all_regions_min50_pseudocount1_exclude_lowRIN','lowRIN_section_included']

def main():
    OUT.mkdir(exist_ok=True)
    assert sha(OUT/'analysis_plan_locked.txt')==PLAN_HASH, 'Frozen plan changed'
    assert sha(MANUSCRIPT)==BASE_MANUSCRIPT, 'Manuscript differs from known baseline'
    print('Plan hash and manuscript baseline verified; beginning analyses.',flush=True)
    single_cell(); print('Single-cell patient summaries complete.',flush=True)
    spatial(); print('Spatial patient-region summaries complete.',flush=True)
    (OUT/'score_calibrations.json').write_text(json.dumps(CALIBRATIONS,indent=2,ensure_ascii=False),encoding='utf-8')
    (OUT/'internal_checks.json').write_text(json.dumps(CHECKS,indent=2),encoding='utf-8')
    assert all(v['max_abs_mean']<1e-10 and v['max_abs_sd_error']<1e-10 for v in CHECKS)
    assert sha(MANUSCRIPT)==BASE_MANUSCRIPT
    env=dict(python=sys.version,platform=platform.platform(),numpy=np.__version__,pandas=pd.__version__,scipy=scipy.__version__,
             random_seed=20261022,manuscript_sha256=sha(MANUSCRIPT),manuscript_unchanged=True,
             new_data_download_bytes=0,plan_sha256=PLAN_HASH)
    (OUT/'analysis_environment.json').write_text(json.dumps(env,indent=2,ensure_ascii=False),encoding='utf-8')
    manifest=dict(inputs=[dict(path=str(p.relative_to(ROOT)),bytes=p.stat().st_size,sha256=sha(p)) for p in INPUTS],
                  outputs=[dict(path=str(p.relative_to(ROOT)),bytes=p.stat().st_size,sha256=sha(p)) for p in OUT.iterdir() if p.is_file() and p.name!='analysis_manifest.json'])
    (OUT/'analysis_manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf-8')
    print('Analysis complete; no manuscript edits and no new data downloads.',flush=True)

if __name__=='__main__':
    main()
