"""Bounded, local-only follow-up; no manuscript changes or downloads."""
from pathlib import Path
import gzip,hashlib,itertools,json,sys,time
import h5py,numpy as np,pandas as pd,scipy
from scipy import sparse,stats
from analyze_patient_regions_20261022 import apply_calibration,bh,welch,paired_test,ENDPOINTS,STATES,MANUSCRIPT,BASE_MANUSCRIPT

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs/subtype_depth_audit_20261022'
QC=ROOT/'outputs/validation_qc_20261022'
PREV=ROOT/'outputs/patient_region_analysis_20261022'
PLAN_HASH='acda482420e2ac6c993201bb94ef5f583f6ddb06585fb554f6d0f7b708bc132b'
CAL=json.loads((PREV/'score_calibrations.json').read_text(encoding='utf-8'))
PLAN=json.loads((QC/'download_plan.json').read_text())
FILES={r['name']:Path(r['path']) for r in PLAN}
MARKERS=['FABP4','INHBA','FCN1','VCAN','S100A8','S100A9','TREM2','GPNMB']
GENES=sorted({g for v in STATES.values() for g in v}|set(MARKERS))
GOI=['SPP1hi','CCL2hi']
assert not (set(MARKERS)&{g for v in STATES.values() for g in v})
INPUTS=[Path(__file__).resolve(),OUT/'analysis_plan_locked.txt',PREV/'score_calibrations.json',QC/'download_plan.json']
CHECKS=[]

def sha(p):
    return hashlib.file_digest(open(p,'rb'),'sha256').hexdigest()

def save(d,name):
    d.to_csv(OUT/name,index=False,encoding='utf-8-sig',float_format='%.12g')

def read(p,**kwargs):
    INPUTS.append(p);return pd.read_csv(p,**kwargs)

def hc3(d,pcs,model):
    x=pd.DataFrame({'intercept':1.,'IPF':(d.diagnosis=='IPF').astype(float),
                    'depth':np.log2(d.total_umi/d.n_cells)})
    x.depth-=x.depth.mean()
    x=pd.concat([x,pd.get_dummies(d.source,drop_first=True,dtype=float),d[pcs]],axis=1)
    X=x.to_numpy(float);n,k=X.shape
    assert np.linalg.matrix_rank(X)==k and n-k>=3
    inv=np.linalg.inv(X.T@X);h=np.einsum('ij,jk,ik->i',X,inv,X)
    rows=[]
    for e in GOI:
        y=d[e].to_numpy();b=inv@X.T@y;r=y-X@b
        cov=inv@X.T@np.diag((r/(1-h))**2)@X@inv
        se=np.sqrt(cov[1,1]);m=stats.t.ppf(.975,n-k)*se
        rows.append(dict(model=model,endpoint=e,n=n,df=n-k,delta=b[1],se_HC3=se,
                         ci_low=b[1]-m,ci_high=b[1]+m,p=2*stats.t.sf(abs(b[1]/se),n-k),
                         max_leverage=max(h),condition_number=np.linalg.cond(X),
                         residual_shapiro_p=stats.shapiro(r).pvalue))
    return pd.DataFrame(rows)

def extract_clusters():
    qc=read(QC/'single_cell_cell_qc.csv')
    prior=read(PREV/'single_cell_donor_program_scores.csv')
    donor=prior[(prior.compartment=='macrophages')&(prior.pseudocount==1)&(prior.n_cells>=50)].copy().set_index('donor')
    sub=qc[qc.Sample_Name.isin(donor.index)&qc.celltype.isin(['Macrophages','Proliferating Macrophages'])].copy()
    sub['cluster']=sub.seurat_clusters.astype(int)
    sub['key']=sub.Sample_Name+'|'+sub.cluster.astype(str)
    codes,groups=pd.factorize(sub.key,sort=True);sub['group_code']=codes
    gm=sub.groupby('group_code').agg(donor=('Sample_Name','first'),diagnosis=('Diagnosis','first'),
                source=('Sample_Source','first'),cluster=('cluster','first'),n_cells=('barcode','size'),
                total_umi=('recomputed_umi','sum'),mean_genes=('recomputed_genes','mean'),mean_mt=('recomputed_pct_mt','mean'))
    ngrp=len(gm)
    save(gm.reset_index(),'cluster_donor_inventory.csv')
    counts=sub.groupby(['Sample_Name','cluster']).size().unstack(fill_value=0).reindex(donor.index)
    fractions=counts.div(counts.sum(axis=1),axis=0)
    check=counts.sum(axis=1).eq(donor.n_cells)
    assert check.all()
    donor['max_cluster_fraction']=fractions.max(axis=1)
    H=np.sqrt(fractions.to_numpy());H-=H.mean(axis=0)
    U,S,V=np.linalg.svd(H,full_matrices=False)
    for i in range(2):donor['PC'+str(i+1)]=U[:,i]*S[i]
    save(pd.DataFrame({'component':np.arange(1,len(S)+1),'variance_fraction':S*S/np.sum(S*S)}),'composition_PCA_variance.csv')
    save(pd.DataFrame(V[:2].T,index=counts.columns,columns=['PC1_loading','PC2_loading']).reset_index(),'composition_PCA_loadings.csv')
    save(donor.reset_index(),'donor_composition_PC_scores.csv')
    save(fractions.reset_index(),'donor_cluster_fractions.csv')
    comp=[]
    for c in fractions:
        a=fractions.loc[donor.diagnosis=='IPF',c];b=fractions.loc[donor.diagnosis=='Control',c]
        comp.append(dict(cluster=int(c),**welch(a,b)))
    comp=pd.DataFrame(comp);comp['q_BH15']=bh(comp.p);save(comp,'cluster_composition_tests.csv')
    composition_models=[hc3(donor,[],'depth_source'),hc3(donor,['PC1'],'depth_source_PC1'),
                        hc3(donor,['PC1','PC2'],'depth_source_PC1_PC2')]
    # Single streaming pass; no expansion of the 1GB gzipped count matrix on disk.
    barcode_path=FILES['GSE135893_barcodes.tsv.gz'];genes_path=FILES['GSE135893_genes.tsv.gz'];mtx=FILES['GSE135893_matrix.mtx.gz']
    INPUTS.extend([barcode_path,genes_path,mtx])
    barcodes=gzip.open(barcode_path,'rt').read().splitlines();names=gzip.open(genes_path,'rt').read().splitlines()
    cell_group=sub.set_index('barcode').group_code.reindex(barcodes).fillna(-1).to_numpy(int)
    gene_lookup={g.upper():i for i,g in enumerate(names)}
    target_lookup=np.full(len(names),-1,int)
    for i,g in enumerate(GENES):
        if g.upper() in gene_lookup:target_lookup[gene_lookup[g.upper()]]=i
    sums=np.zeros((len(GENES),ngrp),np.int64);allumi=np.zeros(ngrp,np.int64)
    scanned=0;started=time.time()
    with gzip.open(mtx,'rt',encoding='ascii') as f:
        assert f.readline().lower().startswith('%%matrixmarket matrix coordinate')
        line=f.readline()
        while line.startswith('%'):line=f.readline()
        nr,nc,nnz=map(int,line.split());assert (nr,nc)==(len(names),len(barcodes))
        for chunk in pd.read_csv(f,sep=r'\s+',header=None,names=['g','c','v'],chunksize=1_000_000,
                                 dtype={'g':np.int64,'c':np.int64,'v':np.int64}):
            g=chunk.g.to_numpy()-1;c=chunk.c.to_numpy()-1;v=chunk.v.to_numpy()
            group=cell_group[c];keep=group>=0
            allumi+=np.bincount(group[keep],weights=v[keep],minlength=ngrp).astype(np.int64)
            t=target_lookup[g];keep&=t>=0
            sums+=np.bincount(t[keep]*ngrp+group[keep],weights=v[keep],minlength=len(GENES)*ngrp).reshape(len(GENES),ngrp).astype(np.int64)
            scanned+=len(chunk)
            if scanned%30_000_000==0:print('SC entries',scanned,'seconds',round(time.time()-started),flush=True)
        assert scanned==nnz
    assert np.array_equal(allumi,gm.total_umi.to_numpy())
    CHECKS.append(dict(check='streamed_cluster_UMI_matches_author_QC',passed=True,n_groups=ngrp))
    x=pd.DataFrame(sums.T,index=gm.index,columns=GENES)
    log=np.log2(x.div(gm.total_umi,axis=0)*1e6+1)
    z=apply_calibration(log,CAL['sc_macrophages_pseudocount_1'])
    values=pd.concat([gm,z,log[MARKERS].add_prefix('marker_logCPM_')],axis=1)
    save(values.reset_index(),'cluster_donor_program_and_marker_scores.csv')
    np.savez_compressed(OUT/'cluster_counts_small.npz',counts=sums,genes=np.array(GENES),group_code=gm.index.to_numpy())
    # Rebuild prior donor sums exactly; this guards gene/barcode/group mapping.
    full=x.assign(donor=gm.donor).groupby('donor').sum()
    logfull=np.log2(full.div(donor.total_umi,axis=0)*1e6+1)
    rebuilt=apply_calibration(logfull,CAL['sc_macrophages_pseudocount_1'])
    error=float(np.max(np.abs(rebuilt.loc[donor.index,ENDPOINTS].to_numpy()-donor[ENDPOINTS].to_numpy())))
    assert error<1e-8
    CHECKS.append(dict(check='new_extraction_reproduces_previous_donor_scores',passed=True,max_error=error))
    tests=[];support=[]
    for threshold in [20,50]:
        q=values[values.n_cells>=threshold]
        for c in counts.columns:
            d=q[q.cluster==c]
            support.append(dict(threshold=threshold,cluster=int(c),n_ipf=(d.diagnosis=='IPF').sum(),n_control=(d.diagnosis=='Control').sum()))
            for source in ['all','Vanderbilt']:
                dd=d if source=='all' else d[d.source==source]
                if min((dd.diagnosis=='IPF').sum(),(dd.diagnosis=='Control').sum())<3:continue
                for e in GOI:
                    tests.append(dict(model=f'within_cluster_{int(c)}_min{threshold}_{source}',cluster=int(c),threshold=threshold,
                                      source_subset=source,endpoint=e,**welch(dd.loc[dd.diagnosis=='IPF',e],dd.loc[dd.diagnosis=='Control',e])))
    result=pd.concat(composition_models+[pd.DataFrame(tests)],ignore_index=True)
    result['q_global_new_program_tests']=bh(result.p)
    save(result,'subtype_adjustment_and_within_cluster_tests.csv')
    save(pd.DataFrame(support),'within_cluster_group_support.csv')
    common=[r['cluster'] for r in support if r['threshold']==20 and min(r['n_ipf'],r['n_control'])>=3]
    complete=counts[common].ge(20).all(axis=1)
    (OUT/'common_support.json').write_text(json.dumps(dict(common_clusters=common,
        complete_donors=counts.index[complete].tolist(),n_complete=int(complete.sum()),
        no_imputation=True,interpretation='Complete same-mixture standardization not identifiable if support is absent.'),indent=2),encoding='utf-8')
    print('SC subtype analysis complete.',flush=True)

def summarize_spatial(d,case):
    results=[];donors=[];inventories=[]
    for exclude in [False,True]:
        q=d[(d.n_spots>=50)&d.annotation.isin(['Diseased','Normal Alveolar and Other'])].copy()
        if exclude:q=q[~q.low_RIN_block]
        base=q.copy()
        for method in ['matched_sections','all_regions']:
            q=base.copy();family=case+'__'+method+('__exclude_lowRIN' if exclude else '')
            if method=='matched_sections':
                vv=q.groupby('sample').annotation.nunique();q=q[q['sample'].isin(vv[vv==2].index)]
                a=q[q.annotation=='Diseased'].set_index(['donor','sample'])
                b=q[q.annotation=='Normal Alveolar and Other'].set_index(['donor','sample'])
                delta=(a[ENDPOINTS]-b[ENDPOINTS]).reset_index().groupby('donor',as_index=False)[ENDPOINTS].mean()
            else:
                a=q.groupby(['donor','annotation'])[ENDPOINTS].mean()
                delta=(a.xs('Diseased',level='annotation')-a.xs('Normal Alveolar and Other',level='annotation')).dropna().reset_index()
            if len(delta)<2:continue
            results.append(paired_test(delta,family));delta['family']=family;donors.append(delta)
            inventories.append(dict(family=family,n_donors=len(delta),n_sections=q['sample'].nunique(),n_region_units=len(q),
                                    n_spots=q.n_spots.sum(),lowRIN_section_included=bool(q.low_RIN_block.any())))
    return results,donors,inventories

def spatial():
    spot=read(QC/'spatial_spot_qc.csv');spot=spot[spot.condition=='IPF']
    items=[]
    cal=CAL['spatial_pseudocount_1'];glist=sorted({g for s in STATES for g in cal[s]['available']})
    SEEDS=list(range(20261022,20261027))
    rngs={(depth,seed):np.random.default_rng(seed) for depth in [1000,500] for seed in SEEDS}
    for sample,m in spot.groupby('sample',sort=True):
        path=FILES[sample+'__filtered_feature_bc_matrix.h5'];INPUTS.append(path)
        with h5py.File(path,'r') as f:
            g=f['matrix'];names=[v.decode().upper() for v in g['features/name'][:]]
            ids=[v.decode().split('.')[0].upper() for v in g['features/id'][:]]
            bc=[v.decode() for v in g['barcodes'][:]]
            matrix=sparse.csc_matrix((g['data'][:],g['indices'][:],g['indptr'][:]),shape=tuple(g['shape'][:]))
        tokens={}
        for j,(name,gid) in enumerate(zip(names,ids)):
            tokens.setdefault(name,set()).add(j);tokens.setdefault(gid,set()).add(j)
        rows=[]
        for gene in glist:
            hit=tokens.get(gene.upper(),set());assert len(hit)==1,(sample,gene)
            rows.append(next(iter(hit)))
        assert len(rows)==len(set(rows)), 'Hypergeometric categories must not overlap'
        counts=matrix[rows,:].toarray().T.astype(np.int64)
        total=np.asarray(matrix.sum(axis=0)).ravel().astype(np.int64)
        m=m.set_index('barcode').loc[bc].copy();assert np.array_equal(total,m.n_umi.to_numpy())
        assert np.all(counts.sum(axis=1)<=total)
        cases=[('raw',np.ones(len(m),bool),counts,total)]
        for depth in [1000,500]:
            eligible=total>=depth
            cases.append((f'eligible_{depth}',eligible,counts[eligible],total[eligible]))
            # ponytail: only frozen target categories + remainder; no full transcriptome draw or extra libraries.
            colors=np.column_stack([counts[eligible],total[eligible]-counts[eligible].sum(axis=1)])
            for seed in SEEDS:
                rng=rngs[(depth,seed)]
                thinned=np.array([rng.multivariate_hypergeometric(row,depth)[:-1] for row in colors],dtype=np.int64)
                assert np.all(thinned.sum(axis=1)<=depth)
                assert np.all(thinned<=counts[eligible])
                cases.append((f'thin_{depth}_seed{seed}',eligible,thinned,np.full(eligible.sum(),depth,np.int64)))
        for case,mask,c,denom in cases:
            mm=m.iloc[np.flatnonzero(mask)]
            for annotation in sorted(mm.annotation.dropna().unique()):
                flag=mm.annotation.eq(annotation).to_numpy();n=int(flag.sum())
                sums=c[flag].sum(axis=0);lib=int(denom[flag].sum())
                row=dict(case=case,sample=sample,donor=m.donor.iloc[0],annotation=annotation,n_spots=n,total_umi=lib,
                         low_RIN_block=bool(m.low_RIN_block.iloc[0]))
                log=pd.DataFrame([np.log2(sums/lib*1e6+1)],columns=glist)
                row.update(apply_calibration(log,cal).iloc[0].to_dict());items.append(row)
        del matrix,counts,cases
        print('Spatial depth complete:',sample,flush=True)
    d=pd.DataFrame(items);save(d,'spatial_depth_region_scores.csv')
    results=[];donors=[];inventories=[]
    for case,q in d.groupby('case',sort=True):
        r,v,i=summarize_spatial(q,case);results+=r;donors+=v;inventories+=i
    # All blocks, rather than selecting a suspicious block based on its effect.
    raw=d[d['case']=='raw']
    influence=[]
    for sample in sorted(raw['sample'].unique()):
        r,v,i=summarize_spatial(raw[raw['sample']!=sample],'leave_block_'+sample)
        results+=r;donors+=v;inventories+=i
        s=pd.concat(r);s=s[s.family.str.endswith('__all_regions')].copy()
        s['removed_sample']=sample;influence.append(s)
    r=pd.concat(results,ignore_index=True);r['q_global_all_new_spatial_tests']=bh(r.p)
    save(r,'spatial_depth_and_block_tests.csv')
    save(pd.concat(donors,ignore_index=True),'spatial_depth_donor_differences.csv')
    save(pd.DataFrame(inventories),'spatial_depth_analysis_inventory.csv')
    save(pd.concat(influence,ignore_index=True),'spatial_leave_each_block_effects.csv')
    # Verify independent extraction reproduces prior results before assessing the thinning.
    previous=read(PREV/'spatial_region_tests.csv')
    a=r[r.family=='raw__matched_sections'].set_index('endpoint')
    b=previous[previous.family=='matched_sections_min50_pseudocount1'].set_index('endpoint')
    assert np.allclose(a.delta,b.delta,atol=1e-9)
    a=r[r.family=='raw__all_regions'].set_index('endpoint')
    b=previous[previous.family=='all_regions_min50_pseudocount1'].set_index('endpoint')
    assert np.allclose(a.delta,b.delta,atol=1e-9)
    CHECKS.append(dict(check='H5_reextraction_reproduces_prior_paired_and_all_region_effects',passed=True))
    # Five seed repetitions describe Monte Carlo variation; never average their P values.
    t=r[r.family.str.startswith('thin_')].copy()
    t['depth']=t.family.str.extract(r'thin_(\d+)').astype(int)
    t['method']=np.where(t.family.str.contains('__matched_sections'),'matched_sections','all_regions')
    t['exclude_lowRIN']=t.family.str.endswith('__exclude_lowRIN')
    agg=t.groupby(['depth','method','exclude_lowRIN','endpoint']).agg(seed_count=('delta','size'),
        delta_mean=('delta','mean'),delta_min=('delta','min'),delta_max=('delta','max'),
        min_exact_p=('p','min'),max_exact_p=('p','max'),min_n_donors=('n_donors','min')).reset_index()
    save(agg,'spatial_thinning_seed_summary.csv')
    assert agg.seed_count.eq(5).all()

def main():
    assert sha(OUT/'analysis_plan_locked.txt')==PLAN_HASH
    assert sha(MANUSCRIPT)==BASE_MANUSCRIPT
    print('Frozen follow-up plan and unchanged manuscript verified.',flush=True)
    extract_clusters();spatial()
    assert sha(MANUSCRIPT)==BASE_MANUSCRIPT
    env=dict(python=sys.version,numpy=np.__version__,pandas=pd.__version__,scipy=scipy.__version__,h5py=h5py.__version__,
             manuscript_unchanged=True,manuscript_sha256=BASE_MANUSCRIPT,new_research_download_bytes=0,plan_sha256=PLAN_HASH)
    (OUT/'environment.json').write_text(json.dumps(env,indent=2,ensure_ascii=False),encoding='utf-8')
    (OUT/'checks.json').write_text(json.dumps(CHECKS,indent=2),encoding='utf-8')
    manifest=dict(inputs=[dict(path=str(p.relative_to(ROOT)),sha256=sha(p),bytes=p.stat().st_size) for p in dict.fromkeys(INPUTS)],
                  outputs=[dict(path=str(p.relative_to(ROOT)),sha256=sha(p),bytes=p.stat().st_size) for p in OUT.iterdir() if p.is_file() and p.name!='manifest.json'])
    (OUT/'manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf-8')
    print('Complete: local-only, manuscript unchanged.',flush=True)

if __name__=='__main__':main()
