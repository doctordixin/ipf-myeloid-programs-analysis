"""Locked GSE252465 donor program analysis, using verified RNA counts only.

Internal statistical diagnostic plots are not manuscript figures. No manuscript edits.
"""
import argparse,hashlib,json,sys,time
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy import stats
import scipy,statsmodels,statsmodels.api as sm
from bal_patient_core import STATES,BALANCE,ENDPOINTS,bh,logcpm,calibrate,compare,mean_effect
from check_bal_counts_and_donors import load_vector
from check_bal_rds_gate import ROOT,digest
from lock_bal_patient_plan import OUT,GATE

SKILL=ROOT/'vendor/statistical_diagnostics'
sys.path.insert(0,str(SKILL))
from assumption_checks import check_normality,check_homogeneity_of_variance,detect_outliers,check_regression_diagnostics

def save(name,value):(OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
def load(name):return json.loads((OUT/name).read_text(encoding='utf-8'))

def locked():
    plan=load('locked_analysis_plan.json');lock=load('plan_lock.json')
    assert digest(OUT/'locked_analysis_plan.json')==lock['plan_sha256']
    assert digest(OUT/'patient_qc_before_scoring.csv')==lock['patient_qc_sha256']
    assert digest(ROOT/plan['signature_file'])==plan['source']['frozen_signature_sha256']
    return plan,json.loads((ROOT/plan['signature_file']).read_text())['states']

def diagnostics(scores,qc):
    directory=OUT/'internal_diagnostics';directory.mkdir(exist_ok=True);rows=[];flags=[]
    for endpoint in ENDPOINTS:
        for disease in ('Control','IPF'):
            ids=qc.index[qc['Disease'].eq(disease)];y=scores.loc[ids,endpoint].to_numpy()
            normal=check_normality(y,name=f'{endpoint}: {disease}',plot=True)
            plt.gcf().savefig(directory/f'{endpoint}_{disease}_distribution.png',dpi=100);plt.close('all')
            outlier=detect_outliers(y,plot=False)
            rows.append({'endpoint':endpoint,'group':disease,'n':len(y),'shapiro_W':float(normal['statistic']),
              'shapiro_p':float(normal['p_value']),'IQR_flags_not_excluded':int(outlier['n_outliers'])})
            for index in outlier['outlier_indices']:flags.append({'endpoint':endpoint,'donor':ids[index],
              'group':disease,'score':float(y[index]),'action':'retain; no evidence of data error'})
        tmp=pd.DataFrame({'score':scores.loc[qc.index,endpoint],'Disease':qc['Disease']})
        variance=check_homogeneity_of_variance(tmp,'score','Disease',plot=False)
        rows[-1].update(levene_statistic=float(variance['statistic']),levene_p=float(variance['p_value']))
    pd.DataFrame(rows).to_csv(OUT/'distribution_assumptions_before_testing.csv',index=False)
    pd.DataFrame(flags,columns=['endpoint','donor','group','score','action']).to_csv(OUT/'outlier_flags_retained.csv',index=False)
    # One point per donor; no stars, p values or inferential cell counts.
    fig,axes=plt.subplots(2,4,figsize=(12,6.2),layout='constrained');rng=np.random.default_rng(20261023)
    for ax,endpoint in zip(axes.flat,ENDPOINTS):
        for xpos,disease,colour in ((0,'Control','#3976a8'),(1,'IPF','#b25c37')):
            ids=qc.index[qc['Disease'].eq(disease)];y=scores.loc[ids,endpoint]
            ax.scatter(xpos+rng.uniform(-.075,.075,len(y)),y,c=colour,s=25,alpha=.9)
            ax.plot([xpos-.15,xpos+.15],[y.mean()]*2,c='black',lw=1)
        ax.axhline(0,c='.8',lw=.6);ax.set_xticks([0,1],['Control (5)','IPF (11)']);ax.set_xlim(-.5,1.5)
        ax.set_title(endpoint.replace('_minus_',' minus\n'),fontsize=10);ax.set_ylabel('Main-reference score (SD)',fontsize=8)
        ax.spines[['top','right']].set_visible(False)
    axes.flat[-1].set_visible(False);fig.suptitle('Internal diagnostic: one point per same-source donor; no outcome-based exclusions',fontsize=11)
    fig.savefig(directory/'main_patient_scores.png',dpi=150);plt.close(fig)

def prepare():
    plan,signatures=locked();assert digest(ROOT/plan['source']['approved_input_copy'])==plan['source']['sha256']
    meta=pd.read_csv(GATE/'cell_metadata.tsv',sep='\t',dtype={'subcluster':str})
    descriptor=json.loads((GATE/'matrix_descriptors.json').read_text())['RNA.counts']
    inventory={r['path']:r for r in json.loads((GATE/'array_inventory.json').read_text())}
    for key in ('i','x'):
        item=descriptor[key];assert digest(ROOT/item['path'])==inventory[item['path']]['sha256']
    i,p,x=(load_vector(descriptor[key]) for key in ('i','p','x'))
    assert descriptor['cells']==meta['object_cell_id'].tolist()
    qc=pd.read_csv(OUT/'patient_qc_before_scoring.csv').set_index('pnt_in_paper')
    donors=qc.index.tolist();donor_number={name:k for k,name in enumerate(donors)}
    genes=sorted(set(g for module in signatures.values() for g in module)&set(descriptor['features']))
    feature_number={g:k for k,g in enumerate(descriptor['features'])};target_number={g:k for k,g in enumerate(genes)}
    lookup=np.array([target_number.get(g,-1) for g in descriptor['features']],dtype=np.int32)
    mask=meta['subcluster'].isin(plan['macrophage_labels']).to_numpy();indices=np.flatnonzero(mask)
    cell_counts=np.zeros((len(genes),len(indices)),dtype=np.int32)
    bulk=np.zeros((descriptor['shape'][0],len(donors)),dtype=np.int64)
    cell_donor=meta.loc[mask,'pnt_in_paper'].map(donor_number).to_numpy(dtype=np.int32)
    cell_umi=meta.loc[mask,'nCount_RNA'].to_numpy(dtype=np.int64)
    for col,original in enumerate(indices):
        left,right=int(p[original]),int(p[original+1]);rows=np.asarray(i[left:right],dtype=np.int32);vals=np.asarray(x[left:right],dtype=np.int64)
        if vals.sum()!=cell_umi[col]:raise ValueError('cached count sum no longer matches object')
        bulk[rows,cell_donor[col]]+=vals
        selected=lookup[rows];keep=selected>=0;cell_counts[selected[keep],col]=vals[keep]
    assert np.array_equal(bulk.sum(0),qc['macrophage_total_umi'].to_numpy())
    target_rows=[feature_number[g] for g in genes];target=bulk[target_rows]
    np.savez_compressed(OUT/'macrophage_pseudobulk_counts.npz',counts=bulk,features=np.array(descriptor['features']),donors=np.array(donors))
    np.savez_compressed(OUT/'signature_cell_counts_for_depth_sensitivity.npz',counts=cell_counts,genes=np.array(genes),
      donor_index=cell_donor,cell_total_umi=cell_umi,donors=np.array(donors))
    expression=pd.DataFrame(logcpm(target,bulk.sum(0)),index=genes,columns=donors)
    expression.to_csv(OUT/'signature_logCPM_full_RNA_denominator.csv',index_label='gene')
    scores,calibration=calibrate(expression,signatures,plan['main_donors'])
    # Check equivalence with the manuscript's existing frozen score definition.
    from analyze_external_bal_disease_state import score_modules
    reference,_=score_modules(expression[plan['main_donors']],signatures)
    np.testing.assert_allclose(scores.loc[plan['main_donors'],ENDPOINTS],reference,atol=1e-12)
    qc.join(scores).to_csv(OUT/'patient_scores_primary_reference.csv',index_label='donor')
    save('primary_score_calibration.json',calibration)
    used=[]
    for state in STATES:
        used.append({'state':state,'frozen_genes':20,'used_genes':len(calibration['modules'][state]['genes']),
          'used_gene_names':';'.join(calibration['modules'][state]['genes']),
          'omitted_genes':';'.join(g for g in signatures[state] if g not in calibration['modules'][state]['genes'])})
    pd.DataFrame(used).to_csv(OUT/'actual_scoring_gene_coverage.csv',index=False)
    diagnostics(scores,qc.loc[plan['main_donors']])
    save('execution_status.json',{'stage':'prepared_and_diagnostics_saved_no_group_tests_yet',
      'plan_sha256':load('plan_lock.json')['plan_sha256'],'patient_analysis_started':True,
      'source_sha256':plan['source']['sha256'],'main_donors':plan['main_donors'],
      'versions':{'python':sys.version,'numpy':np.__version__,'pandas':pd.__version__,'scipy':scipy.__version__,
        'statsmodels':statsmodels.__version__,'matplotlib':matplotlib.__version__}})
    print('Prepared verified donor pseudobulk, full-library scores, frozen calibration and diagnostics. No main group tests run yet.',flush=True)

def regression_sensitivities(scores,qc):
    output=[];diagnostics_rows=[];case=qc['Disease'].eq('IPF').astype(float)
    models={'age_adjusted':{'IPF':case,'age_centred':qc['Age']-qc['Age'].mean()},
      'age_sex_adjusted':{'IPF':case,'age_centred':qc['Age']-qc['Age'].mean(),'male':qc['Gender'].eq('male').astype(float)},
      'depth_cellcount_adjusted':{'IPF':case,'log10_median_UMI':np.log10(qc['median_umi_per_macrophage']),
        'log10_macrophages':np.log10(qc['macrophages'])}}
    for name,columns in models.items():
        design=sm.add_constant(pd.DataFrame(columns,index=qc.index)).astype(float)
        assert np.linalg.matrix_rank(design)==design.shape[1]
        local=[]
        for endpoint in ENDPOINTS:
            model=sm.OLS(scores.loc[qc.index,endpoint],design).fit();robust=model.get_robustcov_results(cov_type='HC3',use_t=True)
            index=design.columns.get_loc('IPF');ci=robust.conf_int()[index]
            local.append({'analysis':name,'endpoint':endpoint,'n':len(qc),'IPF_coefficient':float(robust.params[index]),
              'HC3_CI_low':float(ci[0]),'HC3_CI_high':float(ci[1]),'HC3_t_p':float(robust.pvalues[index]),
              'residual_df':float(robust.df_resid),'max_leverage':float(model.get_influence().hat_matrix_diag.max()),
              'design_condition_number':float(model.condition_number)})
            # Diagnostic tests do not select or replace the prespecified model.
            diag=check_regression_diagnostics(model,plot=False)
            diagnostics_rows.append({'analysis':name,'endpoint':endpoint,'diagnostics':repr(diag)})
        local=pd.DataFrame(local);local['q_BH_7_exploratory']=bh(local['HC3_t_p'].to_numpy());output.append(local)
    pd.concat(output,ignore_index=True).to_csv(OUT/'covariate_sensitivity_HC3.csv',index=False)
    pd.DataFrame(diagnostics_rows).to_csv(OUT/'regression_diagnostics.csv',index=False)

def analyse():
    plan,signatures=locked();status=load('execution_status.json')
    assert status['stage']=='prepared_and_diagnostics_saved_no_group_tests_yet'
    print('Starting seven locked donor-level endpoints and all prespecified sensitivities',flush=True)
    scored=pd.read_csv(OUT/'patient_scores_primary_reference.csv').set_index('donor')
    qc=pd.read_csv(OUT/'patient_qc_before_scoring.csv').set_index('pnt_in_paper')
    scores=scored[ENDPOINTS];main=plan['main_donors'];mainqc=qc.loc[main];case=mainqc['Disease'].eq('IPF').to_numpy()
    rng=np.random.default_rng(plan['random_seed']);primary=compare(scores,mainqc,'main_same_source_11_vs_5',rng)
    primary.to_csv(OUT/'primary_seven_endpoint_results.csv',index=False)
    sensitivities=[];thresholds=[]
    for threshold in plan['threshold_sensitivities']:
        selected=mainqc[mainqc['macrophages']>=threshold]
        result=compare(scores,selected,f'minimum_{threshold}_macrophages',rng)
        result['same_donors_as_primary']=selected.index.tolist()==main
        sensitivities.append(result);thresholds.append({'minimum_macrophages':threshold,'included':selected.index.tolist(),
          'excluded':[name for name in main if name not in selected.index],'independent_evidence':False})
    for name,selected in [('pooled_controls_source_sensitivity',qc),
      ('external_only_source_confounded',qc[qc['Disease'].eq('IPF')|qc['source'].eq('Kevin_COPD')])]:
        sensitivities.append(compare(scores,selected,name,rng))
    save('threshold_sensitivity_inclusion.json',thresholds)
    cell=np.load(OUT/'signature_cell_counts_for_depth_sensitivity.npz');genes=cell['genes'].tolist();donors=cell['donors'].tolist()
    raw=cell['counts'];cell_donor=cell['donor_index'];cell_umi=cell['cell_total_umi'];positions={d:j for j,d in enumerate(donors)}
    normalized_cells=np.log1p(raw.astype(float)*10000/cell_umi[None,:]);average=np.column_stack([normalized_cells[:,cell_donor==j].mean(axis=1) for j in range(len(donors))])
    average=pd.DataFrame(average,index=genes,columns=donors);alternative,_=calibrate(average,signatures,main)
    alternative.to_csv(OUT/'patient_scores_mean_cell_logCP10K.csv',index_label='donor')
    sensitivities.append(compare(alternative,mainqc,'equal_cell_mean_logCP10K_normalization',rng))
    pd.concat(sensitivities,ignore_index=True).to_csv(OUT/'all_fixed_sensitivity_comparisons.csv',index=False)
    regression_sensitivities(scores,mainqc)
    expression=pd.read_csv(OUT/'signature_logCPM_full_RNA_denominator.csv',index_col=0)
    primary_direction=np.sign(primary['mean_difference'].to_numpy());base_effect=primary['mean_difference'].to_numpy()
    influence=[]
    for omitted in main:
        keep=[d for d in main if d!=omitted];effect=mean_effect(scores.loc[keep,ENDPOINTS],qc.loc[keep,'Disease'].eq('IPF'))
        for j,endpoint in enumerate(ENDPOINTS):influence.append({'omitted_donor':omitted,'endpoint':endpoint,
          'mean_difference_fixed_main_reference':float(effect[j]),'direction_matches_main':bool(np.sign(effect[j])==primary_direction[j])})
    pd.DataFrame(influence).to_csv(OUT/'leave_one_donor_out.csv',index=False)
    gene_influence=[];calibration=load('primary_score_calibration.json')
    for state in STATES:
        for omitted in calibration['modules'][state]['genes']:
            changed,_=calibrate(expression,signatures,main,omit=(state,omitted))
            for endpoint in [state]+([BALANCE] if state in ('SPP1hi','CXCL10hi') else []):
                j=ENDPOINTS.index(endpoint);effect=float(mean_effect(changed.loc[main,[endpoint]],case)[0])
                gene_influence.append({'state_gene_omitted':state,'omitted_gene':omitted,'endpoint':endpoint,
                  'mean_difference':effect,'direction_matches_main':bool(np.sign(effect)==primary_direction[j])})
    pd.DataFrame(gene_influence).to_csv(OUT/'leave_one_gene_out.csv',index=False)
    repeated=[];main_positions=[positions[d] for d in main]
    signature_bulk=np.column_stack([raw[:,cell_donor==j].sum(axis=1,dtype=np.int64) for j in main_positions])
    library=mainqc['macrophage_total_umi'].to_numpy(dtype=np.int64)
    for kind in ('equal_500_macrophages','equal_pseudobulk_UMI'):
        for repeat in range(100):
            sampled=np.zeros_like(signature_bulk);totals=np.zeros(len(main),dtype=np.int64)
            for j,position in enumerate(main_positions):
                if kind=='equal_500_macrophages':
                    selected=rng.choice(np.flatnonzero(cell_donor==position),size=500,replace=False)
                    sampled[:,j]=raw[:,selected].sum(axis=1,dtype=np.int64);totals[j]=cell_umi[selected].sum()
                else:
                    colours=np.r_[signature_bulk[:,j],library[j]-signature_bulk[:,j].sum()].astype(np.int64)
                    draw=rng.multivariate_hypergeometric(colours,plan['depth_sensitivities']['equal_pseudobulk_UMI_target'])
                    sampled[:,j]=draw[:-1];totals[j]=draw.sum()
                    assert totals[j]==plan['depth_sensitivities']['equal_pseudobulk_UMI_target']
            expr=pd.DataFrame(logcpm(sampled,totals),index=genes,columns=main);changed,_=calibrate(expr,signatures,main)
            effect=mean_effect(changed[ENDPOINTS],case)
            for j,endpoint in enumerate(ENDPOINTS):repeated.append({'sensitivity':kind,'repeat':repeat,'endpoint':endpoint,
              'mean_difference':float(effect[j]),'direction_matches_main':bool(np.sign(effect[j])==primary_direction[j]),
              'min_full_library_UMI':int(totals.min()),'max_full_library_UMI':int(totals.max())})
    repeated=pd.DataFrame(repeated);repeated.to_csv(OUT/'depth_resampling_all_repeats.csv',index=False)
    repeated.groupby(['sensitivity','endpoint']).agg(repeats=('repeat','size'),median_effect=('mean_difference','median'),
      min_effect=('mean_difference','min'),max_effect=('mean_difference','max'),
      direction_agreement=('direction_matches_main','mean')).to_csv(OUT/'depth_resampling_summary.csv')
    # Baseline imbalance is descriptive, not a licence for causal interpretation.
    baseline=qc.groupby(['source','Disease']).agg(n=('Age','size'),mean_age=('Age','mean'),median_age=('Age','median'),
      min_age=('Age','min'),max_age=('Age','max'),male=('Gender',lambda x:int(x.eq('male').sum())),
      median_macrophages=('macrophages','median'),median_UMI_per_macrophage=('median_umi_per_macrophage','median'))
    baseline.to_csv(OUT/'baseline_by_source_and_disease.csv')
    status.update(stage='all_locked_analyses_complete',primary_tests=7,all_null_results_retained=True,manuscript_edits=False)
    save('execution_status.json',status)
    print(primary[['endpoint','mean_difference','permutation_p','q_BH_7']].to_string(index=False),flush=True)
    print('All prespecified sensitivity and diagnostic outputs saved; no manuscript files edited.',flush=True)

if __name__=='__main__':
    cli=argparse.ArgumentParser();cli.add_argument('stage',choices=['prepare','analyse']);args=cli.parse_args()
    prepare() if args.stage=='prepare' else analyse()
