"""Independent numerical checks; no imports from legacy statistical functions."""
import gzip
import hashlib
import itertools
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import norm
from statsmodels.stats.multitest import multipletests
from statsmodels.stats.meta_analysis import combine_effects

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'outputs/legacy_bal_fullrna_correction_20261023_run2'
STATES = ['MLM0','CCL2hi','MLM1','IL1Bhi','SPP1hi','CXCL10hi']
BALANCE = 'SPP1hi_minus_CXCL10hi'


def independently_score(expression, signatures):
    result = {}
    for name in STATES:
        present = [g.upper() for g in signatures[name] if g.upper() in expression.index]
        selected = expression.loc[present]
        selected = selected.loc[selected.std(axis=1, ddof=1) > 0]
        z = selected.sub(selected.mean(axis=1), axis=0).div(selected.std(axis=1, ddof=1), axis=0)
        mean = z.mean(axis=0)
        result[name] = (mean-mean.mean())/mean.std(ddof=1)
    result = pd.DataFrame(result)
    diff = result['SPP1hi']-result['CXCL10hi']
    result[BALANCE] = (diff-diff.mean())/diff.std(ddof=1)
    return result


def effect(values, labels):
    a, b = values[labels], values[~labels]
    df = len(a)+len(b)-2
    sd = np.sqrt(((len(a)-1)*a.var(ddof=1)+(len(b)-1)*b.var(ddof=1))/df)
    g = (1-3/(4*df-1))*(a.mean()-b.mean())/sd
    se = np.sqrt(1/len(a)+1/len(b)+g*g/(2*df))
    return g, se


def main():
    checks = {}
    signatures = json.loads((ROOT/'data/derived/mlm_six_state_signatures_frozen.json').read_text(encoding='utf-8'))['states']
    path = ROOT/'data/raw/external_bal/GSE166036_count.tsv.gz'
    with gzip.open(path, 'rt') as handle:
        names = handle.readline().strip().split('\t')
    raw = pd.read_csv(path, sep='\t', header=None, skiprows=1, names=['gene_id']+names)
    libraries = pd.read_csv(OUT/'sample_library_sizes.csv').set_index('matrix_sample')
    # Python integer summation is independent of the analysis pandas aggregation.
    direct = np.array([sum(int(x) for x in raw[s]) for s in libraries.index], dtype=np.int64)
    np.testing.assert_array_equal(direct, libraries['full_RNA_library'].to_numpy())
    assert len(raw) == 30727
    target = pd.read_csv(OUT/'unchanged_target_counts.csv').set_index('gene')
    independent_log = pd.DataFrame(np.log2(target.to_numpy()/direct[None,:]*1e6+.5), index=target.index, columns=target.columns)
    saved_log = pd.read_csv(OUT/'corrected_target_logCPM.csv').set_index('gene')
    np.testing.assert_allclose(saved_log, independent_log, rtol=0, atol=1e-13)
    independent_scores = independently_score(independent_log, signatures)
    scores = pd.read_csv(OUT/'corrected_patient_scores.csv')
    saved_scores = scores[scores['dataset'].eq('GSE166036')].set_index('matrix_sample')
    score_error = float(np.max(np.abs(independent_scores.to_numpy()-saved_scores.loc[independent_scores.index, independent_scores.columns].to_numpy())))
    assert score_error < 1e-12
    checks['independent_full_library_integer_sum'] = True
    checks['independent_module_scoring_max_abs_error'] = score_error
    effects = pd.read_csv(OUT/'corrected_cohort_effects.csv')
    all_p = {}
    for dataset, group in scores.groupby('dataset', sort=False):
        labels = group['analysis_group'].eq('IPF').to_numpy()
        values = group[STATES+[BALANCE]].to_numpy()
        # Enumerate controls (the smaller arm), all allocations exactly once.
        selection = np.array(list(itertools.combinations(range(len(group)), int((~labels).sum()))))
        sums0 = values[selection].sum(axis=1)
        differences = (values.sum(axis=0)-sums0)/labels.sum()-sums0/(~labels).sum()
        observed = values[labels].mean(axis=0)-values[~labels].mean(axis=0)
        p = (np.abs(differences) >= np.abs(observed)[None,:]-1e-12).mean(axis=0)
        all_p[dataset] = p.tolist()
        rows = effects[effects['dataset'].eq(dataset)].set_index('marker').loc[STATES+[BALANCE]]
        np.testing.assert_allclose(p, rows['permutation_p'], rtol=0, atol=1e-14)
        np.testing.assert_allclose(multipletests(p, method='fdr_bh')[1], rows['q_within_cohort'], rtol=0, atol=1e-14)
        assert (rows['permutations']==math.comb(len(group),int((~labels).sum()))).all()
        for j, marker in enumerate(STATES+[BALANCE]):
            g, se = effect(values[:,j], labels)
            np.testing.assert_allclose([g,se,g-1.96*se,g+1.96*se], rows.loc[marker,['hedges_g','se','ci_low','ci_high']].to_numpy(dtype=float), rtol=0, atol=1e-12)
    checks['all_14_exact_permutation_p_BH_g_and_CI'] = True
    checks['permutation_allocations'] = {'GSE166036':495,'GSE79544':245157}
    checks['independent_p_values'] = all_p
    pooled = pd.read_csv(OUT/'corrected_descriptive_meta.csv').set_index('marker')
    pooled_p = []
    for marker in STATES+[BALANCE]:
        part = effects[effects['marker'].eq(marker)]
        g = part['hedges_g'].to_numpy()
        var = part['se'].to_numpy()**2
        model = combine_effects(g, var, method_re='chi2')
        fixed = float(model.mean_effect_fe)
        se = float(model.sd_eff_w_fe)
        p = 2*norm.sf(abs(fixed/se))
        pooled_p.append(p)
        row = pooled.loc[marker]
        np.testing.assert_allclose([fixed,fixed-1.96*se,fixed+1.96*se,p], row[['fixed_hedges_g','fixed_ci_low','fixed_ci_high','fixed_p']].to_numpy(dtype=float), rtol=0, atol=1e-12)
        tau = max(0,float(model.tau2))
        weight = 1/(var+tau)
        re = np.dot(g,weight)/weight.sum()
        re_se = np.sqrt(1/weight.sum())
        i2 = max(0,(float(model.q)-1)/float(model.q)*100) if model.q>0 else 0
        np.testing.assert_allclose([tau,re,re-1.96*re_se,re+1.96*re_se,i2], row[['tau2_dl','random_hedges_g','random_ci_low_normal','random_ci_high_normal','i2_percent']].to_numpy(dtype=float), rtol=0, atol=1e-11)
    np.testing.assert_allclose(multipletests(pooled_p, method='fdr_bh')[1], pooled.loc[STATES+[BALANCE],'fixed_q'], rtol=0, atol=1e-13)
    checks['independent_statsmodels_fixed_meta_and_DL_random_meta'] = True
    loo = pd.read_csv(OUT/'corrected_gene_LOO.csv')
    for row in loo[loo['dataset'].eq('GSE166036')].itertuples():
        omitted = {k:[g for g in genes if not(k==row.marker and g.upper()==row.omitted_gene)] for k,genes in signatures.items()}
        score = independently_score(independent_log,omitted)[row.marker].to_numpy()
        labels = saved_scores.loc[independent_log.columns,'analysis_group'].eq('IPF').to_numpy()
        g,_ = effect(score,labels)
        assert abs(g-row.loo_hedges_g)<1e-12
    checks['independent_GSE166036_gene_LOO'] = True
    protected = json.loads((OUT/'protected_file_hashes_before.json').read_text(encoding='utf-8'))
    assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==digest for p,digest in protected.items())
    checks['all_protected_originals_unchanged'] = len(protected)
    checks['scope'] = 'Independent numerical implementation, same agent/session; not independent human review or full manuscript audit.'
    checks['status'] = 'PASS'
    destination = OUT/'independent_numerical_verification.json'
    with destination.open('x',encoding='utf-8') as handle:
        json.dump(checks,handle,ensure_ascii=False,indent=2)
    print(json.dumps(checks,ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()
