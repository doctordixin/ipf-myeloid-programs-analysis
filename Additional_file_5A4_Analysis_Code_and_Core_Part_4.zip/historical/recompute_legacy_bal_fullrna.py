"""Authorized, isolated denominator correction. Never call legacy main or plotting.

Only the GSE166036 normalization denominator changes. All historical methods and
GSE79544 inputs are retained. Outputs go to a new directory, created exclusively.
"""
import gzip
import json
import platform
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
import scipy

import analyze_external_bal_disease_state as old

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'outputs/legacy_bal_fullrna_correction_20261023_run2'
ENDPOINTS = old.STATE_ORDER + [old.BALANCE]


def save_json(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')


def protected_files():
    submission = json.loads((ROOT / 'outputs/manuscript_revision_plan_20261023/original_file_manifest.json').read_text(encoding='utf-8'))['files']
    paths = [Path(x['path']) for x in submission]
    paths += list((ROOT / 'data/derived').glob('phase5*'))
    paths += list((ROOT / 'data/raw/external_bal').glob('*'))
    paths += [ROOT / 'work/analyze_external_bal_disease_state.py', old.SIGNATURE_FILE,
              ROOT / 'outputs/bal_patient_analysis_20261023/locked_analysis_plan.json']
    return {str(p): old.sha256(p) for p in paths if p.is_file()}


def analyze_expression(expression, metadata, signatures):
    """Same historical estimators, tests, coverage and gene-LOO; accept logCPM."""
    scores, used = old.score_modules(expression, signatures)
    meta = metadata.set_index('matrix_sample').loc[scores.index]
    meta.index.name = 'matrix_sample'
    labels = meta['analysis_group'].eq('IPF').astype(int).to_numpy()
    scored = meta.reset_index()[['matrix_sample', 'geo_accession', 'title', 'analysis_group']].copy()
    scored.insert(0, 'dataset', 'GSE166036')
    for marker in ENDPOINTS:
        scored[marker] = scores[marker].to_numpy()
    effects = []
    for marker in ENDPOINTS:
        values = scores[marker].to_numpy(dtype=float)
        p, permutations = old.exact_permutation_p(values, labels)
        effects.append({'dataset': 'GSE166036', 'marker': marker, 'n_ipf': int(labels.sum()),
                        'n_control': int((1-labels).sum()), **old.hedges_g(values, labels),
                        'permutation_p': p, 'permutations': permutations})
    effects = pd.DataFrame(effects)
    effects['q_within_cohort'] = old.bh_fdr(effects['permutation_p'].tolist())
    coverage = pd.DataFrame([{'dataset': 'GSE166036', 'marker': marker,
                             'requested_genes': len(signatures[marker]), 'used_genes': len(used[marker]),
                             'genes_used': ';'.join(used[marker]),
                             'coverage_fraction': len(used[marker])/len(signatures[marker])}
                            for marker in old.STATE_ORDER])
    loo = []
    for marker in old.STATE_ORDER:
        full_g = effects.set_index('marker').loc[marker, 'hedges_g']
        for gene in used[marker]:
            subset, _ = old.score_modules(expression, signatures, omit=(marker, gene))
            g = old.hedges_g(subset[marker].to_numpy(), labels)['hedges_g']
            loo.append({'dataset': 'GSE166036', 'marker': marker, 'omitted_gene': gene,
                        'full_hedges_g': full_g, 'loo_hedges_g': g,
                        'same_direction': bool(np.sign(g) == np.sign(full_g))})
    return scored, effects, coverage, pd.DataFrame(loo)


def compare(before, after, keys, numeric, effect_field, q_field):
    merged = before.merge(after, on=keys, suffixes=('_old', '_corrected'), validate='one_to_one')
    assert len(merged) == len(before) == len(after)
    for field in numeric:
        merged[field + '_change'] = merged[field + '_corrected'] - merged[field + '_old']
    merged['direction_changed'] = np.sign(merged[effect_field+'_old']) != np.sign(merged[effect_field+'_corrected'])
    merged['old_FDR_lt_0_05'] = merged[q_field+'_old'] < .05
    merged['corrected_FDR_lt_0_05'] = merged[q_field+'_corrected'] < .05
    merged['FDR_status_changed'] = merged['old_FDR_lt_0_05'] != merged['corrected_FDR_lt_0_05']
    return merged


def main():
    OUT.mkdir(exist_ok=False)
    protection = protected_files()
    save_json('protected_file_hashes_before.json', protection)
    save_json('locked_correction_plan.json', {
        'locked_UTC': datetime.now(timezone.utc).isoformat(),
        'authorization': 'User explicitly requested full RNA denominator correction and comparison; no manuscript edits or overwrites.',
        'only_change': 'GSE166036 library size is sum of all rows of original RNA matrix before marker mapping/selection.',
        'sample_counts': {'GSE166036': {'IPF': 8, 'Control': 4}, 'GSE79544': {'IPF': 16, 'Control': 7}},
        'unchanged_methods': ['frozen signature and cached Entrez mapping', 'log2(CPM+0.5)',
                              'within-cohort gene z(ddof=1), module mean, module z(ddof=1)',
                              'z(SPP1hi-CXCL10hi)', 'Hedges g with historical approximate variance/normal 95% CI',
                              'absolute mean-difference exact label permutations, tolerance 1e-12',
                              '7-endpoint BH within cohort', 'six module gene-LOO',
                              'inverse-variance fixed and DL random effects descriptive pooling; fixed 7-endpoint BH'],
        'GSE79544': 'Reproduce scores from full matrix; retain original unaffected effects and LOO; independently check statistics.',
        'limitations': ['post-hoc computational repair, not preregistration', 'small unpaired observational cohorts',
                        'exchangeability conditional on null is not guaranteed by enumeration',
                        'normal CI and two-study heterogeneity estimates are approximate; not prognostic validation'],
        'environment': {'python': sys.version, 'platform': platform.platform(),
                        'numpy': np.__version__, 'pandas': pd.__version__, 'scipy': scipy.__version__}})
    signatures = json.loads(old.SIGNATURE_FILE.read_text(encoding='utf-8'))['states']
    signatures = {state: [str(g).upper() for g in signatures[state]] for state in old.STATE_ORDER}
    raw = old.RAW / 'GSE166036_count.tsv.gz'
    with gzip.open(raw, 'rt', encoding='utf-8') as handle:
        samples = handle.readline().rstrip('\n').split('\t')
    counts = pd.read_csv(raw, sep='\t', compression='gzip', header=None, skiprows=1, names=['gene_id']+samples)
    counts['gene_id'] = counts['gene_id'].astype(str)
    matrix = counts[samples].to_numpy(dtype=float)
    assert np.isfinite(matrix).all() and (matrix >= 0).all()
    assert np.array_equal(matrix, np.floor(matrix)), 'Unexpected noninteger original counts'
    assert counts['gene_id'].is_unique and len(samples) == len(set(samples))
    # Critical repair: denominator is determined BEFORE marker mapping/filtering.
    full_library = counts[samples].sum(axis=0)
    target_symbols = {g for genes in signatures.values() for g in genes if not g.startswith('ENSG')}
    mapping = pd.read_csv(old.DERIVED / 'phase5_target_gene_entrez_mapping.csv', dtype={'entrezgene': 'string'})
    assert target_symbols.issubset(set(mapping['query']))
    mapping = mapping[mapping['query'].isin(target_symbols) & mapping['entrezgene'].notna()].copy()
    mapping['gene_id'] = mapping['entrezgene'].str.replace(r'\.0$', '', regex=True)
    mapping.to_csv(OUT / 'frozen_mapping_used.csv', index=False)
    target = mapping.merge(counts, on='gene_id', how='inner').groupby('query')[samples].sum()
    metadata = old.parse_soft_samples(old.RAW / 'GSE166036_family.soft.gz', 'GSE166036')
    metadata = metadata[metadata['compartment'].eq('BAL') & metadata['group'].isin(['IPF', 'Normal'])].copy()
    order = [s for s in samples if s in set(metadata['matrix_sample'])]
    metadata = metadata.set_index('matrix_sample').loc[order].reset_index()
    metadata['analysis_group'] = metadata['group'].replace({'Normal': 'Control'})
    target = target[order]
    full_library = full_library[order]
    assert (full_library > 0).all() and metadata['analysis_group'].value_counts().to_dict() == {'IPF': 8, 'Control': 4}
    pd.DataFrame({'full_RNA_library': full_library, 'target_gene_library': target.sum(),
                  'target_fraction': target.sum()/full_library}).to_csv(OUT / 'sample_library_sizes.csv', index_label='matrix_sample')
    expression = np.log2(target.astype(float).divide(full_library, axis=1)*1e6 + .5)
    expression.to_csv(OUT / 'corrected_target_logCPM.csv', index_label='gene')
    target.to_csv(OUT / 'unchanged_target_counts.csv', index_label='gene')
    fixed_scores, fixed_effects, fixed_coverage, fixed_loo = analyze_expression(expression, metadata, signatures)
    old_scores = pd.read_csv(old.DERIVED / 'phase5_external_bal_scores.csv')
    old_effects = pd.read_csv(old.DERIVED / 'phase5_external_bal_effects.csv')
    old_coverage = pd.read_csv(old.DERIVED / 'phase5_external_bal_signature_coverage.csv')
    old_loo = pd.read_csv(old.DERIVED / 'phase5_external_bal_leave_one_gene_out.csv')
    old_meta = pd.read_csv(old.DERIVED / 'phase5_external_bal_meta.csv')
    replay_scores, _ = old.score_modules(old.log_cpm(target), signatures)
    baseline = old_scores[old_scores['dataset'].eq('GSE166036')].set_index('matrix_sample').loc[order, ENDPOINTS]
    replay_error = float(np.abs(replay_scores[ENDPOINTS].to_numpy()-baseline.to_numpy()).max())
    assert replay_error < 1e-12
    counts795, metadata795 = old.read_gse79544()
    replay795, _ = old.score_modules(old.log_cpm(counts795), signatures)
    baseline795 = old_scores[old_scores['dataset'].eq('GSE79544')].set_index('matrix_sample').loc[replay795.index, ENDPOINTS]
    error795 = float(np.abs(replay795[ENDPOINTS].to_numpy()-baseline795.to_numpy()).max())
    assert error795 < 1e-12
    coverage166 = old_coverage[old_coverage['dataset'].eq('GSE166036')].reset_index(drop=True)
    pd.testing.assert_frame_equal(fixed_coverage, coverage166, check_exact=False, atol=1e-12)
    scores = pd.concat([fixed_scores, old_scores[old_scores['dataset'].eq('GSE79544')]], ignore_index=True)
    effects = pd.concat([fixed_effects, old_effects[old_effects['dataset'].eq('GSE79544')]], ignore_index=True)
    coverage = pd.concat([fixed_coverage, old_coverage[old_coverage['dataset'].eq('GSE79544')]], ignore_index=True)
    loo = pd.concat([fixed_loo, old_loo[old_loo['dataset'].eq('GSE79544')]], ignore_index=True)
    pooled = old.meta_analyze(effects)
    score_comparison = old_scores.merge(scores, on=['dataset','matrix_sample','geo_accession','title','analysis_group'], suffixes=('_old','_corrected'), validate='one_to_one')
    for marker in ENDPOINTS:
        score_comparison[marker+'_change'] = score_comparison[marker+'_corrected'] - score_comparison[marker+'_old']
    comparison = compare(old_effects, effects, ['dataset','marker'], ['hedges_g','ci_low','ci_high','permutation_p','q_within_cohort'], 'hedges_g', 'q_within_cohort')
    pooled_comparison = compare(old_meta, pooled, ['marker'], ['fixed_hedges_g','fixed_ci_low','fixed_ci_high','fixed_p','fixed_q','random_hedges_g','tau2_dl','i2_percent'], 'fixed_hedges_g', 'fixed_q')
    for filename, frame in [('corrected_patient_scores.csv', scores), ('corrected_cohort_effects.csv', effects),
                            ('corrected_gene_coverage.csv', coverage), ('corrected_gene_LOO.csv', loo),
                            ('corrected_descriptive_meta.csv', pooled), ('patient_score_old_new.csv', score_comparison),
                            ('cohort_effect_old_new.csv', comparison), ('pooled_effect_old_new.csv', pooled_comparison)]:
        frame.to_csv(OUT / filename, index=False)
    loo_compare = old_loo.merge(loo, on=['dataset','marker','omitted_gene'], suffixes=('_old','_corrected'), validate='one_to_one')
    loo_compare['LOO_direction_changed_old_to_corrected'] = np.sign(loo_compare['loo_hedges_g_old']) != np.sign(loo_compare['loo_hedges_g_corrected'])
    loo_compare.to_csv(OUT / 'gene_LOO_old_new.csv', index=False)
    loo.groupby(['dataset','marker']).agg(omissions=('omitted_gene','size'), same_direction_fraction=('same_direction','mean'),
                                        min_LOO_g=('loo_hedges_g','min'), max_LOO_g=('loo_hedges_g','max')).to_csv(OUT / 'gene_LOO_summary.csv')
    # Descriptives and assumption diagnostics only; never choose a different test from their p-values.
    sys.path.insert(0, str(ROOT/'vendor/statistical_diagnostics'))
    from assumption_checks import check_normality, check_homogeneity_of_variance
    descriptives, diagnostics = [], []
    for dataset, group in scores.groupby('dataset', sort=False):
        for marker in ENDPOINTS:
            for label, part in group.groupby('analysis_group'):
                values = part[marker].to_numpy()
                normality = check_normality(values, plot=False)
                q1, q3 = np.quantile(values, [.25,.75])
                descriptives.append({'dataset': dataset,'marker':marker,'group':label,'n':len(values),
                                     'mean':values.mean(),'sd':values.std(ddof=1),'median':np.median(values),
                                     'min':values.min(),'max':values.max(),'missing':int(np.isnan(values).sum()),
                                     'IQR_flag_count_not_excluded':int(((values < q1-1.5*(q3-q1)) | (values > q3+1.5*(q3-q1))).sum()),
                                     'Shapiro_W':float(normality['statistic']),'Shapiro_p':float(normality['p_value'])})
            diag = check_homogeneity_of_variance(group, marker, 'analysis_group', plot=False)
            diagnostics.append({'dataset':dataset,'marker':marker, **{k: v for k,v in diag.items() if isinstance(v,(str,int,float))}})
    pd.DataFrame(descriptives).to_csv(OUT / 'group_descriptives_diagnostics.csv', index=False)
    save_json('variance_diagnostics.json', diagnostics)
    after = {p: old.sha256(Path(p)) for p in protection}
    assert after == protection, 'Protected inputs changed'
    save_json('execution_audit.json', {'status':'complete_pending_independent_verification',
              'original_submission_and_legacy_files_unchanged':True, 'protected_files':len(protection),
              'legacy166_score_replay_max_error':replay_error,'GSE79544_score_replay_max_error':error795,
              'GSE79544_full_matrix_rows':len(counts795),'GSE166036_full_matrix_rows':len(counts),
              'GSE166036_target_rows':len(target),'finished_UTC':datetime.now(timezone.utc).isoformat()})
    print(comparison[['dataset','marker','hedges_g_old','hedges_g_corrected','q_within_cohort_old','q_within_cohort_corrected','direction_changed','FDR_status_changed']].to_string(index=False), flush=True)
    print(pooled_comparison[['marker','fixed_hedges_g_old','fixed_hedges_g_corrected','fixed_q_old','fixed_q_corrected','direction_changed','FDR_status_changed']].to_string(index=False), flush=True)


if __name__ == '__main__':
    main()
