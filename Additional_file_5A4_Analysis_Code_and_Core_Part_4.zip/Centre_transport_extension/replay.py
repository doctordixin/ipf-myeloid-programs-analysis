"""Portable centre-held-out transport sensitivity using supplied processed expression."""
from pathlib import Path
import json,hashlib,platform
import numpy as np,pandas as pd
from lifelines import CoxPHFitter
from lifelines.utils import concordance_index
import lifelines
E=Path(__file__).resolve().parent;I=E/'inputs';O=E/'results';O.mkdir(exist_ok=True)
plan=json.loads((E/'analysis_plan_locked.json').read_text(encoding='utf-8'))
for name,digest in plan['inputs'].items():assert hashlib.sha256((I/name).read_bytes()).hexdigest()==digest
c=pd.read_csv(I/'clinical.csv');z=np.load(I/'prepared_expression.npz',allow_pickle=False);X=z['expression'];genes=z['genes'].tolist();sig=json.loads((I/'frozen_available_genes.json').read_text(encoding='utf-8'));states=list(sig);markers=states+['SPP1hi_minus_CXCL10hi'];rng=np.random.default_rng(plan['seed'])
def cindex(t,e,r):return float(concordance_index(t,-r,e))
def brute(t,e,r):
 good=total=0.
 for a in range(len(t)):
  for b in range(a+1,len(t)):
   if t[a]==t[b]:
    if e[a]==e[b]:continue
    early=a if e[a] else b;late=b if e[a] else a
   elif t[a]<t[b]:
    if not e[a]:continue
    early,late=a,b
   else:
    if not e[b]:continue
    early,late=b,a
   total+=1;good+=1 if r[early]>r[late] else .5 if r[early]==r[late] else 0
 return good/total
rows=[];pred=[];coeff=[];gates=[];params={};checks=[]
for centre in plan['outer_folds']:
 test=c.cohort.eq(centre).to_numpy();train=~test;mu=X[train].mean(0);sd=X[train].std(0,ddof=1);assert (sd>0).all();Z=(X-mu)/sd
 scores=np.zeros((len(c),7));p={'gene_mean':mu.tolist(),'gene_sd':sd.tolist(),'genes':genes,'modules':{}}
 for k,state in enumerate(states):
  ids=[genes.index(g) for g in sig[state]];a=Z[:,ids].mean(1);m=a[train].mean();d=a[train].std(ddof=1);assert d>0;scores[:,k]=(a-m)/d;p['modules'][state]={'mean':m,'sd':d,'genes':sig[state]}
 a=scores[:,states.index('SPP1hi')]-scores[:,states.index('CXCL10hi')];m=a[train].mean();d=a[train].std(ddof=1);scores[:,6]=(a-m)/d;p['balance']={'mean':m,'sd':d};params[centre]=p
 # Training preprocessing must not depend on any held-out value.
 perturb=X.copy();perturb[test]+=1234;assert np.array_equal(perturb[train].mean(0),mu)
 base=CoxPHFitter().fit(c.loc[train,['gap','time','event','cohort']],duration_col='time',event_col='event',strata='cohort',formula='gap');gb=float(base.params_['gap']);test_c=c.loc[test].reset_index(drop=True);t=test_c.time.to_numpy();ev=test_c.event.to_numpy();risk0=gb*test_c.gap.to_numpy();C0=cindex(t,ev,risk0);assert abs(C0-brute(t,ev,risk0))<1e-12
 risks=[];fits=[]
 for k,marker in enumerate(markers):
  frame=c[['gap','time','event','cohort']].copy();frame['program']=scores[:,k]
  fit=CoxPHFitter().fit(frame.loc[train],duration_col='time',event_col='event',strata='cohort',formula='gap + program');bg=float(fit.params_['gap']);bp=float(fit.params_['program']);risk=bg*test_c.gap.to_numpy()+bp*scores[test,k];risks.append(risk);fits.append((bg,bp))
  coeff.append(dict(heldout_centre=centre,marker=marker,training_n=int(train.sum()),training_events=int(c.loc[train,'event'].sum()),gap_beta=bg,program_beta=bp,training_program_hr=float(np.exp(bp)),fit_status='converged'))
  assert abs(cindex(t,ev,risk)-brute(t,ev,risk))<1e-12
  gates.append(dict(heldout_centre=centre,marker=marker,gene_count=len(sig[marker]) if marker in sig else None,test_score_mean=float(scores[test,k].mean()),test_score_sd=float(scores[test,k].std(ddof=1)),training_score_mean=float(scores[train,k].mean()),training_score_sd=float(scores[train,k].std(ddof=1)),training_only_transform=True))
 risks=np.array(risks);boot=[]
 for b in range(2000):
  ix=rng.integers(0,len(t),len(t))
  try:
   cb=cindex(t[ix],ev[ix],risk0[ix]);cv=np.array([cindex(t[ix],ev[ix],r[ix]) for r in risks]);boot.append(np.r_[cb,cv,cv-cb])
  except ZeroDivisionError:continue
 boot=np.array(boot);assert len(boot)>=1900
 for k,marker in enumerate(markers):
  ci=cindex(t,ev,risks[k]);lo,hi=np.quantile(boot[:,1+k],[.025,.975]);dl,dh=np.quantile(boot[:,8+k],[.025,.975]);bl,bh=np.quantile(boot[:,0],[.025,.975])
  rows.append(dict(heldout_centre=centre,marker=marker,training_n=int(train.sum()),training_deaths=int(c.loc[train,'event'].sum()),test_n=int(test.sum()),test_deaths=int(ev.sum()),C_GAP=C0,C_GAP_low=bl,C_GAP_high=bh,C_GAP_plus_program=ci,C_plus_low=lo,C_plus_high=hi,delta_C=ci-C0,delta_low=dl,delta_high=dh,bootstrap_valid=len(boot),interval_type='pointwise95_test_patient_bootstrap_fixed_model',evidence_role='posthoc_processed_matrix_centre_transport_not_independent_validation'))
  for j,r in test_c.iterrows():pred.append(dict(heldout_centre=centre,sample_id=r.sample_id,marker=marker,time=r.time,event=r.event,GAP=r.gap,program_score=scores[test,k][j],risk_GAP=risk0[j],risk_GAP_plus_program=risks[k,j]))
 print('COMPLETED',centre,'test n',int(test.sum()),'events',int(ev.sum()),flush=True)
pd.DataFrame(rows).to_csv(O/'heldout_concordance.csv',index=False);pd.DataFrame(pred).to_csv(O/'heldout_predictions.csv',index=False);pd.DataFrame(coeff).to_csv(O/'training_coefficients.csv',index=False);pd.DataFrame(gates).to_csv(O/'score_transport_diagnostics.csv',index=False)
(O/'training_transform_parameters.json').write_text(json.dumps(params,indent=2),encoding='utf-8')
(O/'execution_receipt.json').write_text(json.dumps({'all21_models':'converged','heldout_comparable_pairs':'lifelines C index independently verified by pair enumeration for all24 risks','training_only_transform_check':True,'bootstrap':2000,'platform':platform.python_version(),'numpy':np.__version__,'pandas':pd.__version__,'lifelines':lifelines.__version__,'source_preprocessing_independent':False,'new_independent_BAL_cohort':False},indent=2),encoding='utf-8')
print(pd.DataFrame(rows).query("marker=='CCL2hi'")[['heldout_centre','C_GAP','C_GAP_plus_program','delta_C','delta_low','delta_high']].to_string(index=False))
